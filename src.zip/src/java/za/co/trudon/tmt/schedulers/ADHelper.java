/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.schedulers;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.inject.Inject;
import org.apache.log4j.Priority;
import za.co.trudon.cap.webservice.TrudonEmployee;
import za.co.trudon.tmt.dal.ResourceDAO;
import za.co.trudon.tmt.dal.User;
import za.co.trudon.tmt.dal.UserDAL;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.webservicemanager.CapServiceManager;


/**
 *
 * @author MaremaM
 */
@Stateless(name = "adHelper")
public class ADHelper{
 
    @Inject
    CapServiceManager capServiceManager;

    public CapServiceManager getCapServiceManager() {
        return capServiceManager;
    }

    public void setCapServiceManager(CapServiceManager capServiceManager) {
        this.capServiceManager = capServiceManager;
    }
    
    public ADHelper(){
        
    }
    
    @PostConstruct
    public void init() {
        this.validateUser();
    }
    
    public void validateUser(){
        try{
        ResourceDAO resourceDAO = new ResourceDAO();
        List<TrudonEmployee> employees = capServiceManager.getAllTrudonEmployeesByDepartment("");
        List<User> users = new ArrayList<>();
        employees.forEach((employee) -> {
            Resource resource = resourceDAO.getResourceForUsername(employee.getUserId());
            if (resource == null) {
                User user = new User();
                user.setDepartment(employee.getUserDepartment());
                user.setFullName(employee.getUserName());
                user.setUserName(employee.getUserId());
                user.setTitle(employee.getUserTitle());
                users.add(user);
            }
        });
               
        if(!users.isEmpty())
        {
            UserDAL userDAL = new UserDAL();
            int[] result = userDAL.addUser(users);
            org.apache.log4j.Logger.getLogger(ADHelper.class.getName()).log(Priority.INFO,"Users added: " + result ); 
        }
        }catch (Exception exception){
            //do nothing for now. Just print and continue.
            exception.printStackTrace();
        }
    }
}
