package za.co.trudon.tmt.servlet;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import za.co.trudon.tmt.properties.AutoRefreshPropertiesReader;

/**
 * This class provides functionality to handle an uploaded file. This class uses code provided by Apache
 * 
* @author geert.zijlmans
 * 
*/
public class FileUploader extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private String subId;

    /**
     * Default constructor.
     */
    public FileUploader() {
// TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
        doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            boolean completed = false;
            // Check that we have a file upload request
            boolean isMultipart = ServletFileUpload.isMultipartContent(request);
            if (isMultipart) {
                // Create a factory for disk-based file items
                FileItemFactory factory = new DiskFileItemFactory();

                // Create a new file upload handler
                ServletFileUpload upload = new ServletFileUpload(factory);

                // Parse the request
                List items = upload.parseRequest(request);

                // Process the uploaded items
                Iterator iter = items.iterator();
                while (iter.hasNext()) {
                    FileItem item = (FileItem) iter.next();

                    if (item.isFormField()) {
                        processFormField(item);
                    } else {
                        processUploadedFile(item);
                    }
                }
                completed = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processFormField(FileItem item) {
        String name = item.getFieldName();
        String value = item.getString();
    }

    private boolean processUploadedFile(FileItem item) throws Exception {
        boolean done = false;
        String fileName = item.getName();
        long sizeInBytes = item.getSize();
        final String fileRepository = AutoRefreshPropertiesReader.getInstance().getString("profile.images.folder");
        boolean writeToFile = true;
        if (sizeInBytes > (500 * 1024 * 1024)) {
            writeToFile = false;
        }
        // Process a file upload
        if (writeToFile) {
            File uploadedFile = null;

            uploadedFile = new File(fileRepository + fileName);

            if (!uploadedFile.exists()) {
                try {
                    uploadedFile.createNewFile();
                    done = true;
                } catch (Exception e) {
                    int yy = 0;
                }
            }
            item.write(uploadedFile);
        }
        return done;
    }

}
