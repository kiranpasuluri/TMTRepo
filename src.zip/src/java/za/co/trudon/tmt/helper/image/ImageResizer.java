package za.co.trudon.tmt.helper.image;

import java.io.File;
import java.io.IOException;
import java.net.URL;

/**
 *
 * @author Tebogo Ramekosi
 */
public class ImageResizer {
    public void resizeImage(String imgName, String folderName) {
        String imgLocation = folderName+imgName;
        if (imgLocation == null)
            throw new IllegalArgumentException("One argument required: path-to-image");

        try {
            Image img = null;
            if (imgLocation.startsWith("http")) {
                //read the image from a URL
                img = ImageLoader.fromUrl(new URL(imgLocation));
            }
            else {
                File f = new File(imgLocation);
                if (!f.exists() || !f.isFile())
                    throw new IllegalArgumentException("Invalid path to image");
                else {
                    //read the image from a file
                    img = ImageLoader.fromFile(f);
                }
            }

            //crop it
            /*
            Image cropped = img.crop(200, 200, 500, 350);
            cropped.writeToJPG(new File("cropped.jpg"), 0.95f);
            cropped.dispose();
            */
            //resize
            Image resized = img.getResizedToWidth(100);
            //save it with varying softness and quality
            softenAndSave(resized, 0.95f, 0f,folderName,imgName,100);
            
            Image resized2 = img.getResizedToWidth(50);
            //save it with varying softness and quality
            softenAndSave(resized2, 0.95f, 0f,folderName,imgName,50);
            
            ///////Save File Reference to DB//////////
            //   MediaDal mediaDal = new MediaDal();
            //   mediaDal.insertMediaReference(Integer.parseInt(folder), "m_"+imgName);
            /*
            softenAndSave(resized, 0.95f, 0.1f, folderName);
            softenAndSave(resized, 0.95f, 0.2f, folderName);
            softenAndSave(resized, 0.95f, 0.3f, folderName);
            softenAndSave(resized, 0.8f, 0.08f, folderName);
            softenAndSave(resized, 0.6f, 0.08f, folderName);
            softenAndSave(resized, 0.4f, 0.08f, folderName);
             */
            resized.dispose();
            
            //write a 0.95 quality JPG without using Sun's JPG codec
            /*
            resized.writeToFile(new File(folderName+"400_"+imgName));
            */
            
            //resize it to a square with different settings for edge cropping
            /*
            squareIt(img, 400, 0.0, 0.95f, 0.08f, folderName);
            squareIt(img, 400, 0.1, 0.95f, 0.08f, folderName);
            squareIt(img, 400, 0.2, 0.95f, 0.08f, folderName);

            //small thumbs
            squareIt(img, 50, 0.0, 0.95f, 0.08f, folderName);
            squareIt(img, 50, 0.1, 0.95f, 0.08f, folderName);
            squareIt(img, 50, 0.1, 0.5f, 0.08f, folderName);
            */
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }

    private static void softenAndSave(Image img, float quality, float soften,String folderName,String fileName,int size) throws IOException {
        String prefix = "m_";
        if(size<100){
            prefix = "t_";
        }
        img.soften(soften).writeToJPG(new File(folderName+prefix+fileName+".jpg"), quality);
    }

    private static void squareIt(Image img, int width, double cropEdges, float quality, float soften,String folderName) throws IOException {
        Image square = img.getResizedToSquare(width, cropEdges).soften(soften);
        square.writeToJPG(new File(folderName+"square--w"+ width +"--e"+ cropEdges +"--q"+ quality +".jpg"), quality);
        square.dispose();
    }

}
