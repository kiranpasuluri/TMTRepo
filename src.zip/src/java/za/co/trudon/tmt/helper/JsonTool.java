/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.helper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 *
 * @author ic
 */
public class JsonTool {
    public static String toJSONString(Object object){
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("yyy-MM-dd'T'HH:mm:ss.SSS'Z'");//ISO8601 UTC
        Gson gson = gsonBuilder.create();
        return gson.toJson(object);
    }
}
