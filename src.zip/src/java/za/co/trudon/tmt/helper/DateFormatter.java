/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.helper;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author makanae
 */
public class DateFormatter {

  private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
  private static SimpleDateFormat hdf = new SimpleDateFormat("yyyy/MM/dd");
  private static SimpleDateFormat tsdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
  private static SimpleDateFormat odf = new SimpleDateFormat("dd/MMM/yy");
  private static Calendar calendar = null;

  public static Date getDate(String date) {
    Date recDate = null;

    try {

      if (date != null) {
        recDate = sdf.parse(date.trim());
      } else {
        recDate = new Date();
      }
    } catch (ParseException pe) {
    }
    return recDate;
  }

  public static Date getHtmlDate(String date) {
    Date recDate = null;

    try {

      if (date != null) {
        recDate = hdf.parse(date.trim());
      } else {
        recDate = new Date();
      }
    } catch (ParseException pe) {
    }
    return recDate;
  }

  public static Date getTimeStamp(String date) {
    Date recDate = null;

    try {

      if (date != null) {
        recDate = tsdf.parse(date.trim());
      } else {
        recDate = new Date();
      }
    } catch (ParseException pe) {
    }
    return recDate;
  }

  public static String getStringDate(Date date) {
    String sdate = null;

    if (date != null) {
      sdate = sdf.format(date);
    }

    return sdate;
  }

  public static String getHtmlString(Date date) {
    String sdate = null;

    if (date != null) {
      sdate = hdf.format(date);
    }

    return sdate;
  }

  public static String getTimeString(Date date) {
    String sdate = null;

    if (date != null) {
      sdate = tsdf.format(date);
    }

    return sdate;
  }

  public static Date getOracleDate(String date) {
    Date recDate = null;

    try {

      if (date != null) {
        recDate = odf.parse(date.trim());
      } else {
        recDate = new Date();
      }
    } catch (ParseException pe) {
    }
    return recDate;
  }
}
