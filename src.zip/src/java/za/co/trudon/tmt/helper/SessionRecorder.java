/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.helper;


import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.http.HttpSessionEvent;

public class SessionRecorder implements HttpSessionListener {

  private static List<HttpSession> activeSessions = new ArrayList<HttpSession>();

  @Override
  public void sessionCreated(HttpSessionEvent se) {
    activeSessions.add(se.getSession());
  }
  
  @Override
  public void sessionDestroyed(HttpSessionEvent se) {
    if(activeSessions.size() > 0){
      activeSessions.remove(se.getSession());
    }
  }

  public static List<HttpSession> getActiveSessions() {
    return activeSessions;
  }

}
