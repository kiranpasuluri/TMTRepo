/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.helper;

import java.io.File;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Locale;
import java.util.TimeZone;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author KarsasN
 */
public class Helper {

  private static final Logger log = Logger.getLogger(Helper.class.getName());

  public static String getHostName() throws UnknownHostException {
    return InetAddress.getLocalHost().getHostName();
  }

  public static boolean StringHasValue(String s) {

    if (s == null) {
      return false;
    }
    if (s.equalsIgnoreCase("")) {
      return false;
    }
    if (s.equalsIgnoreCase("null")) {
      return false;
    }
    if (s.length() <= 0) {
      return false;
    }

    return true;
  }

  public static boolean IntHasValue(int i) {

    if (i == 0) {
      return false;
    }
    if (i == -1) {
      return false;
    }

    return true;
  }
  SimpleDateFormat MMdd_comma_year = new SimpleDateFormat("MM dd, yyyy");

  public static String formatDateStringTo_YYYY_MMMM_dd(String dateString) throws Exception {

    if (!StringHasValue(dateString)) {
      return dateString;
    }

    Date thedate = null;
    try {
      thedate = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).parse(dateString);
    } catch (ParseException e) {
      //Ignore
    }

    try {
      thedate = new SimpleDateFormat("dd-MMM-yy", Locale.ENGLISH).parse(dateString);
    } catch (ParseException e) {
      //Ignore
    }

    try {
      thedate = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).parse(dateString);
    } catch (ParseException e) {
      //Ignore
    }

    try {
      thedate = new SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).parse(dateString);
    } catch (ParseException e) {
      //Ignore
    }

    DateFormat df = new SimpleDateFormat("yyyy/MMMM/dd");
    return df.format(thedate);
  }

  public static void writeStringToFile(String input, String fileName) throws Exception {
    //File file = new File("c:/newfile.txt");
    File file = new File(fileName);
    FileOutputStream fop = new FileOutputStream(file);

    // if file doesn't exists, then create it
    if (!file.exists()) {
      file.createNewFile();
    }

    // get the content in bytes
    byte[] contentInBytes = input.getBytes();

    fop.write(contentInBytes);
    fop.flush();
    fop.close();
  }

  public static String formatOfficialName(String designationInput, String titleInput, String firstName,
          String surnameInput, String surnamePrefixInput, String officialTitleInput) {
    String formattedName = "";

    if (StringHasValue(designationInput)) {
      formattedName += designationInput + ' ';
    }
    if (StringHasValue(titleInput)) {
      formattedName += titleInput + ' ';
    }
    if (StringHasValue(firstName)) {
      formattedName += firstName + ' ';
    }
    if (StringHasValue(surnamePrefixInput)) {
      formattedName += surnamePrefixInput + ' ';
    }
    if (StringHasValue(surnameInput)) {
      formattedName += surnameInput;
    }
    if (StringHasValue(officialTitleInput)) {
      formattedName += '(' + officialTitleInput + ')';
    }

    return formattedName;
  }

  public static Date stringToDate(String input) {

    if (!StringHasValue(input)) {
      return null;
    }

    Date startDate;

    try {
      SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
      df.setTimeZone(TimeZone.getTimeZone("GMT"));
      startDate = df.parse(input);
      return startDate;
    } catch (ParseException e) {
      //Do Nothing, Try next Step
    }

    try {
      SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");
      df.setTimeZone(TimeZone.getTimeZone("GMT"));
      startDate = df.parse(input);
      return startDate;
    } catch (ParseException e) {
      //Do Nothing, Try next Step
    }

    try {
      SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yy");
      df.setTimeZone(TimeZone.getTimeZone("GMT"));
      startDate = df.parse(input);
      return startDate;
    } catch (ParseException e) {
      //Do Nothing, Try next Step
    }

    try {
      SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
      df.setTimeZone(TimeZone.getTimeZone("GMT"));
      startDate = df.parse(input);
      return startDate;
    } catch (ParseException e) {
      //Do Nothing, Try next Step
    }

    try {
      SimpleDateFormat df = new SimpleDateFormat("dd/MMM/yy");
      df.setTimeZone(TimeZone.getTimeZone("GMT"));
      startDate = df.parse(input);
      return startDate;
    } catch (ParseException e) {
      e.printStackTrace();
      //Do Nothing, Try next Step
    }

    return null;
  }

  public static String readProcedureName(HttpServletRequest request) {
    String procedureName;
    try {
      String pathInfo = request.getPathInfo().substring(1);
      int dotPos = pathInfo.indexOf(".");
      procedureName = (dotPos < 0) ? pathInfo : pathInfo.substring(dotPos + 1);
    } catch (Exception e) {
      procedureName = "";
    }

    return procedureName;
  }

  public static Hashtable<String, String> getQueryInputParameters(String query) {
    String[] params = query.split("&");
    Hashtable<String, String> inputParameters = new Hashtable<String, String>();
    for (String param : params) {
      String name = param.split("=")[0];
      String value = param.split("=")[1];
      inputParameters.put(name, value);
    }
    return inputParameters;
  }
  
  public static long getDifferenceInMonths(Date startDate, Date endDate) {
    GregorianCalendar sDate = new GregorianCalendar();
    GregorianCalendar eDate = new GregorianCalendar();
    sDate.setTime(startDate);
    eDate.setTime(endDate);
    
    int m1 = sDate.get(Calendar.YEAR) * 12 + sDate.get(Calendar.MONTH);
    int m2 = eDate.get(Calendar.YEAR) * 12 + eDate.get(Calendar.MONTH);
    return m2 - m1;
    
  }
  
  public static long getDayDifference(Date inputStartDate, Date inputEndDate) {
    final GregorianCalendar startDate = new GregorianCalendar();
    startDate.setTime(inputStartDate);
    final GregorianCalendar endDate = new GregorianCalendar();
    endDate.setTime(inputEndDate);

    int MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
    long endInstant = endDate.getTimeInMillis();
    int presumedDays = (int) ((endInstant - startDate.getTimeInMillis()) / MILLIS_IN_DAY);
    GregorianCalendar cursor = (GregorianCalendar) startDate.clone();
    cursor.add(GregorianCalendar.DAY_OF_YEAR, presumedDays);
    long instant = cursor.getTimeInMillis();
    if (instant == endInstant) {
      return presumedDays;
    }
    final int step = instant < endInstant ? 1 : -1;
    do {
      cursor.add(GregorianCalendar.DAY_OF_MONTH, step);
      presumedDays += step;
    } while (cursor.getTimeInMillis() != endInstant);
    return presumedDays;
  }
}
