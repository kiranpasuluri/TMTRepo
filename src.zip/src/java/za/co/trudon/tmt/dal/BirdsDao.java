/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.co.trudon.tmt.data.type.response.CapUser;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.UserSuggestionResponseWrapper;
import za.co.trudon.tmt.helper.ConnectionManager;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.Resource;

/**
 *
 * @author ramekosit
 */
public class BirdsDao implements Serializable {

  private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(BirdsDao.class);
  public static final String CONNECTION_NAME = "CDM";
  public static final String ASPREPORTS_CONNECTION_NAME = "AspReportsDbPool";
  public static final String CH_CONNECTION_NAME = "CH";

  public BirdsDao() {
  }

  public void recordUserLoginActivity(String username) throws Exception {
    Connection conn = null;
    Statement stmt = null;
    try {
      conn = ConnectionManager.getConnection(ASPREPORTS_CONNECTION_NAME);
      stmt = conn.createStatement();
      
      stmt = conn.createStatement();
      stmt.executeQuery("INSERT INTO trv_user_login_activity VALUES((SELECT employee_id FROM users WHERE LOWER(user_code) = '"+username+"'),SYSDATE)");

    } catch (Exception e) {
      //nothing to do
    } finally {
      if (stmt != null) stmt.close();
      if (conn != null) conn.close();
    }
  }
  
  public UserSuggestionResponseWrapper getUserAutoComplete(String searchString,String searchType) throws Exception {
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    List<CapUser> list = new ArrayList<CapUser>();
    UserSuggestionResponseWrapper userList;
    try {
      conn = ConnectionManager.getConnection(CH_CONNECTION_NAME);
      stmt = conn.createStatement();
      if(searchType.equals("")){
        rs = stmt.executeQuery(" SELECT * FROM ch_cap_user WHERE LOWER(username) LIKE '%" + searchString.toLowerCase() +"%'");
      }else if(searchType.equalsIgnoreCase("manager")){
          rs = stmt.executeQuery(" SELECT * FROM ch_cap_user a, ch_cap_user_role b  WHERE LOWER(a.username) LIKE '%" + searchString.toLowerCase() +"%' AND b.role_id=62 AND lower(a.user_id)=lower(b.user_id)");
      }else if(searchType.equalsIgnoreCase("owner")){
          rs = stmt.executeQuery(" SELECT * FROM ch_cap_user a, ch_cap_user_role b  WHERE LOWER(a.username) LIKE '%" + searchString.toLowerCase() +"%' AND b.role_id=44 AND lower(a.user_id)=lower(b.user_id)");
      }else if(searchType.equalsIgnoreCase("resource")){
          rs = stmt.executeQuery(" SELECT * FROM ch_cap_user a, ch_cap_user_role b  WHERE LOWER(a.username) LIKE '%" + searchString.toLowerCase() +"%' AND lower(a.user_id)=lower(b.user_id)");
      }
      CapUser user = null;
      while (rs.next()) {
        user = new CapUser();
        user.setValue(rs.getString("username"));
        user.setData(rs.getString("user_id"));
        user.setEmail(rs.getString("email"));
        list.add(user);
      }
      userList = new UserSuggestionResponseWrapper();
      userList.setSuggestions(list);
      return userList;

    } catch (Exception e) {
//      log.log(Level.SEVERE, "[BirdsDao][getUserAutoComplete] ", e);
      log.error("Error occured ", e);
      e.printStackTrace();
    } finally {
      if (rs != null) rs.close();
      if (stmt != null) stmt.close();
      if (conn != null) conn.close();
    }
    return null;
  }
  
    public List<CapUser> getProjectManagers() throws Exception {
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    List<CapUser> list = new ArrayList<CapUser>();
    try {
      conn = ConnectionManager.getConnection(CH_CONNECTION_NAME);
      stmt = conn.createStatement();

      rs = stmt.executeQuery("SELECT * FROM ch_cap_user a, ch_cap_user_role b WHERE b.role_id=62 AND LOWER(a.user_id)=LOWER(b.user_id)");

      CapUser user = null;
      
      while (rs.next()) {
        user = new CapUser();
        user.setValue(rs.getString("username"));
        user.setData(rs.getString("user_id"));
        user.setEmail(rs.getString("email"));
        list.add(user);
      }
      return list;

    } catch (Exception e) {
      log.error("Error occured ", e);
      e.printStackTrace();
    } finally {
      if (rs != null) rs.close();
      if (stmt != null) stmt.close();
      if (conn != null) conn.close();
    }
    return null;
  }
  
  public List<CapUser> getBusinessOwners() throws Exception {
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    List<CapUser> list = new ArrayList<CapUser>();
    try {
      conn = ConnectionManager.getConnection(CH_CONNECTION_NAME);
      stmt = conn.createStatement();

      rs = stmt.executeQuery("SELECT p.* FROM CH_CAP_USER p, CH_CAP_USER_ROLE u WHERE LOWER(p.USER_ID) = LOWER(u.USER_ID) AND u.ROLE_ID = 61 AND DEPARTMENT LIKE '%Operations%'");

      CapUser user = null;
      
      while (rs.next()) {
        user = new CapUser();
        user.setValue(rs.getString("username"));
        user.setData(rs.getString("user_id"));
        user.setEmail(rs.getString("email"));
        list.add(user);
      }
      return list;

    } catch (Exception e) {
      log.error("Error occured ", e);
      e.printStackTrace();
    } finally {
      if (rs != null) rs.close();
      if (stmt != null) stmt.close();
      if (conn != null) conn.close();
    }
    return null;
  }
  
  public Project saveProject(Project project) throws Exception {
      Connection conn = null;
      Statement stmt = null;
      Statement stmtSeq = null;
      ResultSet rsSeq = null;
      int newProjectId = 0;
     
      try {
      conn = ConnectionManager.getConnection(CH_CONNECTION_NAME);
      stmt = conn.createStatement();
      
      stmtSeq = conn.createStatement();
      rsSeq = stmtSeq.executeQuery("SELECT PROJECT_SEQ.nextval as project_seq FROM DUAL");
      if(rsSeq.next()){
         newProjectId = rsSeq.getInt("project_seq");
      }
      try{rsSeq.close();}catch(Exception ex){}
      try{stmtSeq.close();}catch(Exception ex){}
      
      String ExecuteString = "INSERT INTO ch_project (ID,NAME,DESCRIPTION,CREATED_BY,CREATED_DATE,EXPECTED_DATE,REVENUE_IMPACT,USAGE_IMPACT,PROJECT_OWNER,PROJECT_MANAGER, BUSINESS_OWNER,START_DATE,PILLAR,PARENT,CAPEX,OPEX,STATUS) "
              + "VALUES ("+newProjectId+",'"+project.getName()+"','"+project.getDescription()+"','"+project.getCreatedBy().toUpperCase()+"',SYSDATE,TO_DATE('"+project.getExpectedDate()+"','DD-MM-YYYY')"
              + ","+project.getRevenueImpact()+","+project.getUsageImpact()+",'"+project.getProjectOwner().getUserName().toUpperCase()+"','"+project.getProjectManager().getUserName().toUpperCase()+ "', '" + project.getBusinessOwner().getUserName().toUpperCase() +"',SYSDATE,"+ project.getProject_pillar_id() +","+ project.getParent() +","+ project.getCapex() +","+ project.getOpex() +","+ project.getStatus() +")";
      log.debug(ExecuteString);

      stmt.executeQuery(ExecuteString);
     
     
      
      if (project.getParent() > 0){
           ProjectTask projectTask = new ProjectTask();
           projectTask.setDescription(project.getDescription());
           projectTask.setCreatedby(project.getCreatedBy());
           projectTask.setPriority(project.getPriority());
           
            if (project.getUpdatedBy() != null){
               projectTask.setUpdateBy(new Resource(project.getUpdatedBy(), "", ""));
           }else{
               projectTask.setUpdateBy(new Resource(project.getCreatedBy(), "", ""));
           }
            
           projectTask.setProjectId(project.getParent());
           projectTask.setStatus(project.getStatus());
           projectTask.setUpdatedDate(/*project.getUpdatedDate()*/new Date());
           projectTask.setSeverity(1);
      
           TaskDAO projectDao = new TaskDAO();
           projectDao.addTask(projectTask);
      }
      
    } catch (Exception e) {
//      log.log(Level.SEVERE, "[BirdsDao][saveProject] ", e);
       log.error("Error occured ", e);
      return null;
    } finally {
      if (stmt != null) stmt.close();
      if (conn != null) conn.close();
      
    }
    project.setId(newProjectId);
    return project;
  }
  
  public Project updateProject(Project project) throws Exception {
      Connection conn = null;
      Statement stmt = null;
      Statement subtmt = null;
      String setExpectedDate = "";
      
      
      
      if(project.getExpectedDate()!=null && !project.getExpectedDate().equals("")){
          setExpectedDate = ",EXPECTED_DATE=TO_DATE('"+project.getExpectedDate()+"','DD-MM-YYYY')";
      }
      
      try {
      conn = ConnectionManager.getConnection(CH_CONNECTION_NAME);
      stmt = conn.createStatement();
      
      stmt.executeUpdate("UPDATE ch_project SET NAME='"+project.getName()+"',DESCRIPTION='"+project.getDescription()+"',REVENUE_IMPACT="+project.getRevenueImpact()+",PRIORITY="+project.getPriority()
              + ",USAGE_IMPACT="+project.getUsageImpact()+",PROJECT_OWNER='"+project.getProjectOwner().getUserName().toUpperCase()+"',PROJECT_MANAGER='"+project.getProjectManager().getUserName().toUpperCase()+ "', BUSINESS_OWNER = '" + project.getBusinessOwner().getUserName().toUpperCase()+"',UPDATED_BY='"+project.getCreatedBy().toUpperCase()+"',UPDATE_DATE=SYSDATE"+setExpectedDate+  ",PARENT="+  project.getParent() + ",CAPEX="+ project.getCapex() +",OPEX="+ project.getOpex()+",STATUS="+ project.getStatus() +" WHERE ID="+project.getId());

        subtmt = conn.createStatement();
        subtmt.executeUpdate("UPDATE ch_project set EXPECTED_DATE=TO_DATE('"+project.getExpectedDate()+"','DD-MM-YYYY') where PARENT="+  project.getId());
        
       /* if (project.getParent() > 0){
           ProjectTask projectTask = new ProjectTask();
           projectTask.setDescription(project.getDescription());
           projectTask.setCreatedby(project.getCreatedBy());
           projectTask.setPriority(project.getPriority());
           
           projectTask.setProjectId(project.getParent());
           projectTask.setStatus(project.getStatus());
           projectTask.setUpdatedDate(project.getUpdatedDate());
           projectTask.setMajorTask(1);
      
           ProjectDAO projectDao = new ProjectDAO();
           projectDao.addTaskToProject(projectTask);
      } */
        
    } catch (Exception e) {
//      log.log(Level.SEVERE, "[BirdsDao][saveProject] ", e);
      log.error("Error occured ", e);
      return null;
    } finally {
      if (stmt != null) stmt.close();
      if (subtmt != null) subtmt.close();
      if (conn != null) conn.close();
    }
    return project;
  }
  
  public boolean saveProjectAttachment(int projectId,String fileName,String createdBy) throws Exception {
      Connection conn = null;
      Statement stmt = null;
      boolean results = false;
      
      try {
      conn = ConnectionManager.getConnection(CH_CONNECTION_NAME);
      stmt = conn.createStatement();
      
      stmt.executeQuery(" INSERT INTO ch_project_attachment (PROJECT_ID,FILENAME,CREATED_BY,CREATED_DATE) "
              + "VALUES ("+projectId+",'"+fileName+"','"+createdBy.toUpperCase()+"',SYSDATE)");
    } catch (Exception e) {
//      log.log(Level.SEVERE, "[BirdsDao][saveProjectAttachment] ", e);
      log.error("Error occured ", e);
      return results;
    } finally {
      if (stmt != null) stmt.close();
      if (conn != null) conn.close();
      
    }
      results = true;
    return results;
  }
  
}