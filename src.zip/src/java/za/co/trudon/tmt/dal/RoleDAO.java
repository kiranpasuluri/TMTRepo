/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.Role;

/**
 *
 * @author MaremaM
 */
public class RoleDAO {
    private static final Logger LOGGER = Logger.getLogger(RoleDAO.class);

    public RoleDAO() {
    }
    
    public Role getRole(String username) {
        Role role = null;
        Connection conn = null;
        PreparedStatement st=null;
        ResultSet rs=null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT r.* FROM CH_PROJECT_ROLE r, CH_CAP_USER_ROLE ur WHERE r.ROLE_ID = ur.ROLE_ID AND LOWER(USER_ID) = ?");
            st.setString(1, username.toLowerCase());
            rs = st.executeQuery();
            
            while(rs.next()){
                role = new Role(rs.getInt("role_id"), rs.getString("role_name"));
            }
            
        }catch(Exception ex){
            LOGGER.error("Unable to get role: ", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return role;
    }
}
