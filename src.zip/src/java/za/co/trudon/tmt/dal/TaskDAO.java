/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.DailyTaskUpdate;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.TaskComment;
import za.co.trudon.tmt.mappers.TaskMapper;
import za.co.trudon.tmt.sql.TaskSQL;

/**
 *
 * @author MangenaS
 */
public class TaskDAO {
    
    private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(TaskDAO.class);
    
    public TaskDAO(){
    }
    
    //Get user tasks
    public List<Project> getUserAssignedTasks(String user_id){
        List<Project> projects = new ArrayList<Project>();
        Connection conn = null;
        PreparedStatement st=null,st2=null;
        ResultSet rs=null,rs2=null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(TaskSQL.GetUserAssignedTasks.toString());
            st.setString(1, user_id);
            rs = st.executeQuery();
            projects = TaskMapper.mapAssignedUserTask(rs);
            
        }catch(Exception ex){
            Logger.getLogger(TaskDAO.class.getName()).log(Level.SEVERE, "Unable to get tasks assigned to the user: "+user_id+"\nError: "+ex.getMessage());
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return projects;
    }
    
    public boolean closeUserAssignedTask(int taskId,String comment){
        boolean result = false;
        PreparedStatement st=null;
        Connection conn = null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(TaskSQL.CloseAssignedTasks.toString());
            st.setString(1, comment);
            st.setInt(2, taskId);
            st.executeUpdate();
            st.close();
            
            result = true;
        }catch(Exception ex){
            Logger.getLogger(TaskDAO.class.getName()).log(Level.SEVERE, "Unable to close task. ID:"+taskId+"\nError"+ex.getMessage());
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return result;
    }
    
    //assign time estimate for a task
    public boolean assignTaskEstimate(int taskId,String estimate){
        boolean result=false;
        Connection con=null;
        PreparedStatement st=null;
        
        try{
          con = DBConnectionManager.getConnection("CH");
          st = con.prepareStatement(TaskSQL.AssignTaskEstimate.toString());
          st.setString(1, estimate);
          st.setInt(2,taskId);
          st.executeUpdate();
          
          result=true;
        }catch(Exception ex){
            Logger.getLogger(TaskDAO.class.getName()).log(Level.SEVERE, "Unable to assign estimate to task. ID:"+taskId+"\nError"+ex.getMessage());
        }finally{
            try{
                if(st!=null)st.close();
                if(con!=null)con.close();
            }catch(Exception ex){}
        }
        return result;
    }
    
        public ProjectTask getProjectTask(int taskId){
        ProjectTask task = null;
        Connection conn = null;
        PreparedStatement st=null;
        ResultSet rs=null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT p.*, cs.USERNAME AS updateByName, cs.EMAIL as updateEmail, "
                    + "ac.USERNAME AS assignedToName, ac.EMAIL as assignedEmail FROM CH_PROJECT_TASK p LEFT JOIN CH_CAP_USER cs"
                    + " ON LOWER(p.CREATED_BY) = LOWER(cs.USER_ID) LEFT JOIN CH_CAP_USER ac ON LOWER(p.ASSIGNED_TO) = LOWER(ac.USER_ID) WHERE TASK_ID = ?");
            st.setInt(1, taskId);
            rs = st.executeQuery();
            
            while(rs.next()){
                task = new ProjectTask();
                task.setId(rs.getInt("task_id"));
                task.setProjectId(rs.getInt("project_id"));
                task.setName(rs.getString("name"));
                task.setStatus(rs.getInt("status"));
                task.setUpdateBy(new Resource(rs.getString("update_by"), rs.getString("updateByName"), rs.getString("updateEmail")));
                task.setDescription(rs.getString("description"));
                task.setEstimateDays(rs.getDouble("estimate_days"));
                task.setTimeSpent(rs.getDouble("time_spent"));
                task.setEstimateHours(rs.getDouble("estimate_hours"));
                task.setCreatedby(rs.getString("updateByName"));
                task.setCreatedDate(rs.getDate("creation_date"));
                task.setUpdatedDate(rs.getDate("update_date"));
                task.setPriority(rs.getInt("priority"));
                task.setSeverity(rs.getInt("severity"));
                task.setParentId(rs.getInt("parent_id"));
                task.setAssignedTo(new Resource(rs.getString("assigned_To") == null ? "" : rs.getString("assigned_To"), rs.getString("assignedToName") == null ? "" : rs.getString("assignedToName"),rs.getString("assignedEmail") == null ? "" : rs.getString("assignedEmail")));
                
                List<TaskComment> comments = getTaskComments(taskId);
                task.setComments(comments);
            }
            
        }catch(Exception ex){
            Logger.getLogger(TaskDAO.class.getName()).log(Level.SEVERE, "Unable to get task: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return task;
    }
        
        public void updateTask(ProjectTask task){
        Connection con=null;
        PreparedStatement st=null, st1 = null;
        ResultSet rs = null;
        
        try{
          con = DBConnectionManager.getConnection("CH");
          st = con.prepareStatement("update CH_PROJECT_TASK set assigned_to=? where task_id=?");
          st.setString(1, task.getAssignedTo().getUserName());
          st.setInt(2, task.getId());
          st.executeUpdate();
          
          ProjectDAO projectDAO = new ProjectDAO();
          projectDAO.addResourceToProject(task.getProjectId(), task.getAssignedTo().getUserName());
          
          st1 = con.prepareStatement("SELECT SYSTEM_ID FROM CH_USER_SYSTEM WHERE LOWER(USER_ID) = ?");
          st1.setString(1, task.getAssignedTo().getUserName().toLowerCase());
          rs = st1.executeQuery();
          while(rs.next()) {
              projectDAO.insertProjectResourceSystem(task.getProjectId(), task.getAssignedTo().getUserName(), rs.getInt("SYSTEM_ID"));
          }

        }catch(Exception ex){
            Logger.getLogger(TaskDAO.class.getName()).log(Level.SEVERE, "Unable to assign estimate to task. ID: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(st1!=null)st1.close();
                if(con!=null)con.close();
            }catch(Exception ex){}
        }

    }    
    
            //add resource to project
    public boolean updateProjectTask(ProjectTask projectTask){
        PreparedStatement st = null;
        Connection conn = null;

        ResultSet rs = null;

        try{
            
            conn = DBConnectionManager.getConnection("CH");
             
            try{rs.close();}catch(Exception ex){}
            try{st.close();}catch(Exception ex){}

            String updateStatement = "UPDATE CH_PROJECT_TASK SET NAME = ?, DESCRIPTION = ?, UPDATE_BY = ?, UPDATE_DATE = CURRENT_TIMESTAMP, STATUS = ?, " +
                        "ASSIGNED_TO = ?, PRIORITY = ?, SEVERITY = ?, ESTIMATE_DAYS = ?, ESTIMATE_HOURS = ? WHERE TASK_ID = ?";
                st = conn.prepareStatement(updateStatement);       
                st.setString(1, projectTask.getName());
                st.setString(2, projectTask.getDescription());
                st.setString(3, projectTask.getUpdateBy().getUserName());
                st.setInt(4, projectTask.getStatus());
                st.setString(5, projectTask.getAssignedTo().getUserName());
                st.setInt(6, projectTask.getPriority());
                st.setInt(7, projectTask.getSeverity());
                st.setDouble(8, projectTask.getEstimateDays());
                st.setDouble(9, projectTask.getEstimateHours());
                st.setInt(10, projectTask.getId());
                st.executeUpdate();
                
                for(TaskComment taskComment : projectTask.getComments())
                {
                    if(taskComment.getId() <= 0 && taskComment.getComment() != null && (!taskComment.getComment().trim().isEmpty())){
                        saveComment(taskComment);
                    }
                }
                if(st!=null)st.close();
                if(projectTask.getParentId() > 0) {
                    st = conn.prepareStatement("UPDATE CH_PROJECT_TASK SET STATUS = ? WHERE TASK_ID = ?");
                    st.setInt(1, projectTask.getStatus());
                    st.setInt(2, projectTask.getParentId());
                    st.executeUpdate();
                    st.close();
                }

        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            log.error("Error occured ", ex);
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    public void addTask(ProjectTask projectTask) {
        PreparedStatement st = null, st1 = null;
        ResultSet rs = null;
        int seqId = 0;
        Connection conn = null;
                try{
                
                conn = DBConnectionManager.getConnection("CH");
                
               String sqlSeq = "SELECT ch_project_task_seq.NEXTVAL as seq_id FROM dual";
            st1 = conn.prepareStatement(sqlSeq);
            rs = st1.executeQuery();
            if(rs.next()){
               seqId = rs.getInt("seq_id");
            }
            rs.close();
            st1.close();
               
                String insertQuery = "INSERT INTO ch_project_task (TASK_ID, PROJECT_ID, NAME, DESCRIPTION, CREATED_BY, "
                        + "CREATION_DATE, UPDATE_BY, UPDATE_DATE, ESTIMATE_DAYS, ESTIMATE_HOURS, STATUS, ASSIGNED_TO, PARENT_ID, PRIORITY, SEVERITY) "
                        + "VALUES(" + seqId + ", " + projectTask.getProjectId()+ ", '" + projectTask.getName() +"', '" + projectTask.getDescription() + "', '" +
                projectTask.getCreatedby() + "', TO_TIMESTAMP('" + new Timestamp(new java.util.Date().getTime()) + "', 'yyyy-MM-dd HH24:MI:SS.FF'), '" + projectTask.getUpdateBy().getUserName() +"', TO_TIMESTAMP('" +
                new Timestamp(new java.util.Date().getTime()) + "', 'yyyy-MM-dd HH24:MI:SS.FF'), " + projectTask.getEstimateDays()+ ", " + projectTask.getEstimateHours() + ", " + projectTask.getStatus() + ", (select user_id from ch_cap_user where username = '" + projectTask.getAssignedTo().getFullNames() + "')," +
                projectTask.getParentId() + ", " + projectTask.getPriority() + ", " + projectTask.getSeverity() +")";

                st = conn.prepareStatement(insertQuery);
                st.executeUpdate();
                
                if(projectTask.getComments() != null && projectTask.getComments().size()>0){
                    for(TaskComment comment: projectTask.getComments()){
                        if(comment.getTaskId() <= 0)
                            comment.setTaskId(seqId);
                        saveComment(comment);
                    }
                }
                if(st!=null)st.close();
                } catch(Exception exception) {
                    try{
                        if(st!=null)st.close();
                        if(conn!=null)conn.close();
                    }catch(Exception e){}
                    log.error("Error occured ", exception);
                }finally{
                try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
    }
    
    public void saveComment(TaskComment comment){
        PreparedStatement st = null;
        Connection conn = null;
                try{
                
                conn = DBConnectionManager.getConnection("CH");
               
                String insertQuery = "INSERT INTO ch_task_comment (ID, TASK_ID, COMMENTS, CREATION_DATE, USER_ID, PARENT_ID, UPDATE_DATE) "
                        + "VALUES(ch_task_comment_seq.NEXTVAL, "+ comment.getTaskId() + ", utl_raw.cast_to_raw('" + comment.getComment() +"'), CURRENT_TIMESTAMP , '" +
                comment.getUsername() + "', " +comment.getParentId() + ", CURRENT_TIMESTAMP)";

                st = conn.prepareStatement(insertQuery);

                
                st.executeUpdate();
                } catch(Exception exception) {
                    try{
                        if(st!=null)st.close();
                        if(conn!=null)conn.close();
                    }catch(Exception e){}
                    log.error("Error occured ", exception);
                }finally{
                try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
    }
    
        public void updateComment(TaskComment comment){
        PreparedStatement st = null;
        Connection conn = null;
                try{
                
                conn = DBConnectionManager.getConnection("CH");
               
                String updateQuery = "UPDATE ch_task_comment COMMENTS = utl_raw.cast_to_raw('" + comment.getComment() 
                        +"'), UPDATE_DATE = CURRENT_TIMESTAMP, EDITED = 1 WHERE ID = " + comment.getId();

                st = conn.prepareStatement(updateQuery);

                st.executeUpdate();
                } catch(Exception exception) {
                    try{
                        if(st!=null)st.close();
                        if(conn!=null)conn.close();
                    }catch(Exception e){}
                    log.error("Error occured ", exception);
                }finally{
                try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
    }
    
    private Timestamp getCurrentTimestamp(){
        java.util.Date date = new java.util.Date();
        return new Timestamp(date.getTime());
    }

    public List<TaskComment> getTaskComments(int taskId) {
        Connection conn = null;
        PreparedStatement st=null;
        ResultSet rs=null;
        List<TaskComment> comments = new ArrayList<>();
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT tc.ID, tc.TASK_ID, tc.CREATION_DATE, tc.USER_ID, tc.UPDATE_DATE, tc.PARENT_ID, UTL_RAW.CAST_TO_VARCHAR2(COMMENTS) AS COMMENTS, tc.edited, cu.USERNAME AS FULL_NAME FROM CH_TASK_COMMENT tc, CH_CAP_USER cu WHERE TASK_ID = ? AND LOWER(tc.USER_ID) = LOWER(cu.USER_ID)");
            st.setInt(1, taskId);
            rs = st.executeQuery();
            
            while(rs.next()){
                TaskComment comment = new TaskComment();
                comment.setId(rs.getInt("id"));
                comment.setTaskId(rs.getInt("task_id"));
                comment.setCreationDate(rs.getTimestamp("creation_date"));
                comment.setUsername(rs.getString("user_id"));
                comment.setUpdateDate(rs.getTimestamp("update_date"));
                comment.setParentId(rs.getInt("parent_id"));
                comment.setComment(rs.getString("comments"));
                comment.setFullname(rs.getString("full_name"));
                comment.setEdited(rs.getInt("edited") == 1);
                comments.add(comment);
            }
            
        }catch(Exception ex){
            Logger.getLogger(TaskDAO.class.getName()).log(Level.SEVERE, "Unable to get task comments: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return comments;
    }
    
        public boolean deleteTaskComment(int commentId){
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("DELETE FROM CH_TASK_COMMENT WHERE ID="+commentId);
            st.executeUpdate();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to delete comment ".concat(ex.getMessage()));
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
        
    public void dailyTaskUpdate(String username, String comment, DailyTaskUpdate dailyTaskUpdate){
        PreparedStatement st = null;
        Connection conn = null;
                try{
                
                conn = DBConnectionManager.getConnection("CH");
               
                String insertQuery = "INSERT INTO CH_DAILY_TASK_UPDATE(ID, TASK_ID, PROJECT_ID, HOURS_WORKED, UPDATE_DATE) "
                        + "VALUES(CH_DAILY_UPDATE_SEQ.NEXTVAL, "+ dailyTaskUpdate.getTaskId() + ", " + dailyTaskUpdate.getProjectId() +
                        ", " +dailyTaskUpdate.getHoursWorked() + ", TO_DATE('" + dailyTaskUpdate.getUpdateDate() + "', 'YYYY-MM-DD HH24:MI:SS'))";
                System.out.println(insertQuery);
                st = conn.prepareStatement(insertQuery);

                st.executeUpdate();
                
                if(comment != null && (!comment.trim().isEmpty())){
                    
                }
                } catch(Exception exception) {
                    try{
                        if(st!=null)st.close();
                        if(conn!=null)conn.close();
                    }catch(Exception e){}
                    log.error("Error occured on daily task update ", exception);
                }finally{
                try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
                }catch(Exception ex){} 
                }
    }
}
