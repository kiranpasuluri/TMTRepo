/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.Resource;

/**
 *
 * @author ramekosit
 */
public class UserDAL {
    
    private Connection dbConn;
    private DbConnection dbConnection;
    
    public String saveUser(HttpServletRequest request)
    {
        String sql = null;

        try
        {
            //Create DB Connection if doesn't exist
            if(dbConn == null)
                dbConnection = new DbConnection();
                dbConn = dbConnection.openDB();
        }
        catch (Exception ex)
        {
            //Log error if DB can't connect
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
            return("Error: The database is currently offline, please try again later");
        }

        // save request
        try
        {
            //Build SQL string
            sql = "insert into avusa.user "
                + "(name, lastname, telephone, email) "
                + "values('" + request.getParameter("name")
                + "', '" + request.getParameter("lastname")
                + "', '" + request.getParameter("telephone")
                + "', '" + request.getParameter("email") + "')";

            Statement statement = dbConn.createStatement();
            statement.executeUpdate(sql);
            statement.close();
        }
        catch(SQLException se)
        {
            //Log any SQL execute errors
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, se);
        }
        finally
        {
            try
            {
                dbConn.close(); 
                dbConn = null;
            }
            catch(SQLException se)
            {}
        }
        return("success");
    }
    
    public ArrayList<User> getAllUsers(String sortBy, String direction)
    {
        ResultSet resultSet = null;
        ArrayList<User> userData = new ArrayList<User>() {};
        String sql = null;

        try
        {
            //Create DB Connection if doesn't exist
            if(dbConn == null)
                dbConnection = new DbConnection();
                dbConn = dbConnection.openDB();
        }
        catch (Exception ex)
        {
            //Log error if DB can't connect
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, ex);
        }

        // save request
        try
        {
            //Build SQL string
            String sortStr = "";
            if((sortBy != null && !sortBy.equals("")) && (direction != null &&(direction.equals("DESC") || direction.equals("ASC")))) {
                sortStr = "ORDER BY "+sortBy+" "+direction;
            } else {
                sortStr = "ORDER BY name ASC";
            }
            sql = "select * from avusa.user "+sortStr;
                
            Statement statement = dbConn.createStatement();
            resultSet = statement.executeQuery(sql);

//            while(resultSet.next()) {
//                User newUser = new User(resultSet.getString("name"), resultSet.getString("lastname"), resultSet.getString("email"), resultSet.getString("telephone"));
//                userData.add(newUser);
//            }
                
            resultSet.close(); resultSet = null;
            statement.close(); statement = null;
        }
        catch(SQLException se)
        {
            //Log any SQL errors
            Logger.getLogger(DbConnection.class.getName()).log(Level.SEVERE, null, se);
        }
        finally
        {
            try
            {
                dbConn.close(); 
                dbConn = null;
            }
            catch(SQLException se)
            {}
        }
        return userData;
    }
    
     public int[] addUser(List<User> users){
        PreparedStatement st=null;
        int[] result = new int[1];
        Connection conn=null;
        try{           
               //Get resources 
                conn = DBConnectionManager.getConnection("CH");
                st = conn.prepareStatement("INSERT INTO CH_CAP_USER (USER_ID, USERNAME, DEPARTMENT, TITLE) VALUES(?,?,?,?)");
                
                for(User user: users)
                {
                    st.setString(1, user.getUserName());
                    st.setString(2, user.getFullName());
                    st.setString(3, user.getDepartment());
                    st.setString(4, user.getTitle());
                    st.addBatch();
                }
                
                result = st.executeBatch();

                st.close();
                conn.close();
            
        }catch(Exception ex){
                try{
                    if(st!=null)st.close();
                    if(conn!=null)conn.close();
                }catch(Exception e){}
            org.apache.log4j.Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to add users. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(conn!= null){
                    conn.commit();
                    if(st!=null)st.close();
                    conn.close();
                }
                
            }catch(Exception ex){}
        }
        return result;
    }
     
    public User getUser(String username){
        PreparedStatement st=null;
        ResultSet result = null;
        Connection conn=null;
        User user = null;
        try{           
               //Get resources 
                conn = DBConnectionManager.getConnection("CH");
                st = conn.prepareStatement("SELECT FROM CH_CAP_USER WHERE LOWER(USER_ID) = ?");
                st.setString(1, username.toLowerCase());

                result = st.executeQuery();
                if(result!=null){
                    while(result.next()){
                        user = new User();
                        user.setFullName(result.getString("USERNAME"));
                        user.setUserName(result.getString("USER_ID"));
                        user.setTitle(result.getString("TITLE"));
                        user.setDepartment(result.getString("DEPARTMENT"));
                    }
                }
                if(result!=null)result.close();
                st.close();
                conn.close();
            
        }catch(Exception ex){
                try{
                    if(result!=null)result.close();
                    if(st!=null)st.close();
                    if(conn!=null)conn.close();
                }catch(Exception e){}
            org.apache.log4j.Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to add users. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(result!=null)result.close();
                if(st!=null)st.close();
                if(conn!= null){
                    conn.close();
                }
                
            }catch(Exception ex){}
        }
        return user;
    }
}
