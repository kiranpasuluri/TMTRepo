/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.apache.log4j.Logger;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.request.TimesheetSearchParams;
import za.co.trudon.tmt.data.type.response.DailyTaskUpdate;
import za.co.trudon.tmt.data.type.response.MainProject;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.Report;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.TaskComment;
import za.co.trudon.tmt.data.type.response.Timesheet;
import za.co.trudon.tmt.data.type.response.TimesheetDate;
import za.co.trudon.tmt.data.type.response.TimesheetProject;
import za.co.trudon.tmt.data.type.response.TimesheetResource;
import za.co.trudon.tmt.data.type.response.WeeklyTimesheet;

/**
 *
 * @author MangenaS
 */
public class ReportDAO {
    
    private static final Logger LOGGER = Logger.getLogger(ReportDAO.class);
    
    private Connection conn;
    
    public ReportDAO(){
        try{
            conn = DBConnectionManager.getConnection("CH");
        }catch(Exception e){}
    }
    
    public Timesheet getTimesheets(TimesheetSearchParams params) {
        PreparedStatement st= null;
        ResultSet rs = null;
        Timesheet timesheet = new Timesheet();
        String whereClause = "";
        TimesheetProject project = null;
        TimesheetResource resource = null;
        try{
            if(params.getProjectName() != null && !(params.getProjectName().trim().isEmpty())){
                
                whereClause +=  "and p.\"NAME\" = '" + params.getProjectName() + "' ";
            }
            if(params.getResourceName() != null && !(params.getResourceName().trim().isEmpty())){
                whereClause +=  "and lower(t.ASSIGNED_TO) = '" + params.getResourceName().toLowerCase() + "' ";
            }
            
            String sql = "SELECT d.PROJECT_ID, d.TASK_ID, SUM(d.HOURS_WORKED) as HOURS_WORKED, TO_CHAR(d.UPDATE_DATE, 'YYYY/MM/DD') as UPDATE_DATE, t.\"NAME\", c.USERNAME, c.USER_ID, p.\"NAME\" AS PROJECT_NAME FROM CH_DAILY_TASK_UPDATE d, CH_PROJECT p, CH_PROJECT_TASK t, CH_CAP_USER c " +
                        "WHERE p.ID = d.PROJECT_ID and d.TASK_ID = t.TASK_ID and lower(c.USER_ID) = lower(t.ASSIGNED_TO) " +
                        "AND TRUNC(d.UPDATE_DATE) BETWEEN TO_DATE('" + params.getFromDate() + "', 'YYYY/MM/DD') " + 
                        "AND TO_DATE('" + params.getToDate() + "', 'YYYY/MM/DD') " + whereClause + " GROUP BY TO_CHAR(d.UPDATE_DATE, 'YYYY/MM/DD'), d.PROJECT_ID, d.TASK_ID, t.\"NAME\", c.USERNAME, c.USER_ID, p.\"NAME\"";
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                String projectName = rs.getString("PROJECT_NAME");
                
                 if(!timesheet.getProjects().stream().filter(p -> p.getName().equalsIgnoreCase(projectName)).findFirst().isPresent()){
                    project = new TimesheetProject();
                    project.setName(projectName);
                    project.setFinancialYearHours(getHoursForFinacialYear(rs.getInt("PROJECT_ID"), params));
                    timesheet.addProject(project);
                }
                DailyTaskUpdate dailyTaskUpdate = new DailyTaskUpdate();
                dailyTaskUpdate.setHoursWorked(rs.getDouble("HOURS_WORKED"));
                dailyTaskUpdate.setUpdateDate(rs.getString("UPDATE_DATE"));
                dailyTaskUpdate.setProjectId(rs.getInt("PROJECT_ID"));
                String username = rs.getString("USER_ID");
                if(!project.getResources().stream().filter(o -> o.getUsername().equalsIgnoreCase(username)).findFirst().isPresent()){
                    resource = new TimesheetResource();
                    resource.setFullnames(rs.getString("USERNAME"));
                    resource.setUsername(username);
                    resource.addUpdate(dailyTaskUpdate);
                    timesheet.getProjects().get(timesheet.getProjects().indexOf(project)).addResource(resource);
                }
                else{
                    timesheet.getProjects().get(timesheet.getProjects().indexOf(project)).getResources().get(project.getResources().indexOf(resource)).addUpdate(dailyTaskUpdate);
                }
                
            }
            timesheet.setDates(getDatesForRange(params.getFromDate(), params.getToDate()));
        } catch(Exception exception) {
            LOGGER.error("An error occured... ", exception);
        } finally {
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return timesheet;
    }
    
    public Timesheet getMonthlyTimesheet(TimesheetSearchParams params) {
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Timesheet timesheet = null;
        try{
            Calendar cal = new GregorianCalendar(Locale.UK);
            cal.setTime(df.parse(params.getFromDate()));
            params.setToDate(params.getFromDate().substring(0, 8) + cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            
            timesheet = getTimesheets(params);
        } catch (Exception exception){
            LOGGER.error("An error occured... ", exception);
            exception.printStackTrace();
        }
        return timesheet;
    }
    
    public Report getDailyReports(TimesheetSearchParams params){
        PreparedStatement st= null;
        ResultSet rs = null;
        Report report = new Report();
        MainProject mainProject;
        Project project = null;
        ProjectTask task = null;
        
        try{
            String fromDate = params.getFromDate();
            String toDate = params.getToDate();
            String dateRange = "";
            
            if(fromDate != null && (!fromDate.isEmpty())) {
                dateRange = "AND TRUNC(dt.UPDATE_DATE) BETWEEN TO_DATE('" + fromDate + "', 'YYYY/MM/DD') " +
                            "AND TO_DATE('" + toDate + "', 'YYYY/MM/DD') ";
            }
            
            String sql = "SELECT p.\"NAME\" AS PROJECT_NAME, t.TASK_ID, t.\"NAME\" AS TASK_NAME, o.USERNAME AS OWNER, m.USERNAME AS PROJECT_MANAGER, u.USERNAME AS DEVELOPER, p.STATUS, p.PRIORITY, " +
                        "t.ESTIMATE_DAYS * t.ESTIMATE_HOURS AS ESTIMATE, dt.UPDATE_DATE, SUM(dt.HOURS_WORKED) AS TIME_SPENT, utl_raw.cast_to_varchar2(tc.COMMENTS) AS COMMENTS " +
                        "FROM CH_PROJECT p,CH_CAP_USER u, CH_CAP_USER o, CH_CAP_USER m, CH_PROJECT_TASK t " +
                        "LEFT JOIN CH_DAILY_TASK_UPDATE dt ON dt.TASK_ID = t.TASK_ID " +
                        "LEFT JOIN CH_TASK_COMMENT tc ON tc.TASK_ID = t.TASK_ID " +
                        "WHERE p.ID = t.PROJECT_ID AND LOWER(t.ASSIGNED_TO) = LOWER(u.USER_ID) " +
                        "AND LOWER(o.USER_ID) = LOWER(p.PROJECT_OWNER) AND LOWER(m.USER_ID) = LOWER(p.PROJECT_MANAGER) AND p.PARENT = 0 " +
                        dateRange +
                        "GROUP BY p.NAME, t.TASK_ID, t.NAME, o.USERNAME, m.USERNAME, u.USERNAME, p.STATUS, p.PRIORITY, t.ESTIMATE_DAYS, t.ESTIMATE_HOURS, dt.UPDATE_DATE, utl_raw.cast_to_varchar2(tc.COMMENTS)";
        System.out.println(sql);
        st = conn.prepareStatement(sql);
        rs = st.executeQuery();
        
        while(rs.next()) {
            String projectName = rs.getString("PROJECT_NAME");
            if(!report.getMainProjects().stream().filter(p -> p.getName().equalsIgnoreCase(projectName)).findFirst().isPresent()){
           mainProject = new MainProject();
                mainProject.setName(projectName);
                
                report.getMainProjects().add(mainProject);
            }
                
            if(!report.getMainProjects().getProjects().stream().filter(p -> p.getName().equalsIgnoreCase(projectName)).findFirst().isPresent()){
                project = new Project();
                project.setName(projectName);
                project.setProjectOwner(new Resource("", rs.getString("OWNER"), ""));
                project.setProjectManager(new Resource("", rs.getString("PROJECT_MANAGER"), ""));
                project.setStatus(rs.getInt("STATUS"));
                project.setPriority(rs.getInt("PRIORITY"));
                report.getMainProjects().getProjects().indexOf(report.getMainProjects().getProjects().indexOf(project));
                //report.getMainProjects().getProjects().add(project);
            }
            TaskComment comment = new TaskComment();
            comment.setComment(rs.getString("COMMENTS"));
            int task_id = rs.getInt("TASK_ID");
            if(!project.getTasks().stream().filter(o -> o.getId() == task_id).findFirst().isPresent()){
                task = new ProjectTask();
                task.setId(task_id);
                task.setName(rs.getString("TASK_NAME"));
                task.setTimeSpent(rs.getInt("TIME_SPENT"));
                task.setEstimateHours(rs.getDouble("ESTIMATE"));
                task.getComments().add(comment);
                task.setAssignedTo(new Resource("", rs.getString("DEVELOPER"), ""));
                report.getProjects().get(report.getProjects().indexOf(project)).getTasks().add(task);
            }
            else{
                report.getProjects().get(report.getProjects().indexOf(project)).getTasks().get(project.getTasks().indexOf(task)).getComments().add(comment);
            }    
        }
        }catch(Exception exception) {
            LOGGER.error("An error occured... ", exception);
        } finally {
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return report;
    }
    
    private long getHoursForFinacialYear(int projectId, TimesheetSearchParams params){
        long financial = 0;
        PreparedStatement st= null;
        ResultSet rs = null;
        try{
            String sql = "SELECT SUM(HOURS_WORKED) AS HOURS_WORKED FROM CH_DAILY_TASK_UPDATE WHERE TRUNC(UPDATE_DATE) BETWEEN TO_DATE('2017/04/01', 'YYYY/MM/DD') " +
                      "AND TO_DATE('" + params.getToDate() + "', 'YYYY/MM/DD') AND PROJECT_ID = " + projectId;

            if(conn.isClosed())
                conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            while(rs.next()) {
                financial = rs.getLong("HOURS_WORKED");
            }
        } catch(Exception exception) {
            LOGGER.error("An error occured... ", exception);
        } finally {
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
            }catch(Exception ex){}
        }
        return financial;
    }
    
    private List<TimesheetDate> getDatesForRange(String fromDate, String toDate) {
        //toDate = "2018/01/31";
        
        List<TimesheetDate> dates = new ArrayList<>();
        List<WeeklyTimesheet> weeklyTimesheets = new ArrayList<>();
        WeeklyTimesheet weeklyTimesheet = new WeeklyTimesheet();
        boolean cond = true;
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Map<Integer, List<WeeklyTimesheet>> map = new HashMap<>();
        try{
            
            //Format toDate to convert from 2018/1/31 to 2018/01/31
            SimpleDateFormat toDateFormat = new SimpleDateFormat("yyyy/MM/dd");
            Date d = toDateFormat.parse(toDate);
            toDate = toDateFormat.format(d);
            System.out.println("--> Updated toDate " + toDate);
            
            Calendar cal = new GregorianCalendar(Locale.UK);
            cal.setTime(df.parse(fromDate));
            weeklyTimesheet.setDate(df.format(cal.getTime()));
            int weekNumber = cal.get(Calendar.WEEK_OF_YEAR);
            weeklyTimesheet.setDay(new SimpleDateFormat("EEEE").format(cal.getTime()));
            weeklyTimesheets.add(weeklyTimesheet);
            map.put(weekNumber, weeklyTimesheets);
            
            //System.out.println("--> Week Date " + fromDate + " - " + df.format(toDate));
            while(cond){

                cal.add(Calendar.DATE, 1);
                
                System.out.println("--> Week Date " + fromDate + " - " + df.parse(toDate));
                System.out.println("--> Date Compare" + df.format(cal.getTime()));
                
                if(df.format(cal.getTime()).equals(toDate)){
                    cond = false;
                    System.out.println("--> Timesheet Exit "); 
                }
                weekNumber = cal.get(Calendar.WEEK_OF_YEAR);
                WeeklyTimesheet weeklyTimesheet_1 = new WeeklyTimesheet();
                weeklyTimesheet_1.setDate(df.format(cal.getTime())); 
                weeklyTimesheet_1.setDay(new SimpleDateFormat("EEEE").format(cal.getTime()));

                if(map.keySet().contains(weekNumber)){
                    map.get(weekNumber).add(weeklyTimesheet_1);
                } else {
                    List<WeeklyTimesheet> weeklyTimesheets_1 = new ArrayList<>();
                    weeklyTimesheets_1.add(weeklyTimesheet_1);
                    map.put(weekNumber, weeklyTimesheets_1);
                }
            }
            for(Integer key : map.keySet()){
               TimesheetDate timesheetDate = new TimesheetDate();
               timesheetDate.setWeekNumber(key);
               timesheetDate.setWeeklyTimesheets(map.get(key));
               dates.add(timesheetDate);
            }
        } catch(Exception exception){
            LOGGER.error("An error occured... ", exception);
            exception.printStackTrace();
        }
        return dates;
    }
    
    public static void main(String args[]){
        TimesheetSearchParams params = new TimesheetSearchParams();
//        params.setFromDate("2017/02/01");
//        params.setToDate("2017/03/31");
//        System.out.println("results " + new ReportDAO().getTimesheets(params));
//        System.out.println(new ReportDAO().getDatesForRange("2017/11/01", "2017/11/30"));
    }
}
