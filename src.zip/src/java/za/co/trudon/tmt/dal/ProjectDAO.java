/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.Attachment;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.ProjectPillar;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.Role;
import za.co.trudon.tmt.data.type.response.Skill;
import za.co.trudon.tmt.data.type.response.System;
import za.co.trudon.tmt.data.type.response.SystemAttributes;
import za.co.trudon.tmt.mappers.ProjectMapper;
import za.co.trudon.tmt.mappers.ResourceMapper;
import za.co.trudon.tmt.mappers.SystemMapper;
import za.co.trudon.tmt.sql.ProjectSQL;
import za.co.trudon.tmt.sql.ResourceSQL;
import za.co.trudon.tmt.sql.SystemSQL;

/**
 *
 * @author MangenaS
 */
public class ProjectDAO {
    
    private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ProjectDAO.class);
    
    public ProjectDAO(){
    }
    
    
    public  ArrayList<Project>  searchProjects(String name, String projectPriority,String status){
        
         String strCmd = "SELECT ID,NAME,START_DATE,STATUS,END_DATE,CREATED_BY,CREATED_DATE,EXPECTED_DATE,REVENUE_IMPACT,USAGE_IMPACT,PROJECT_OWNER,PROJECT_MANAGER,"
                 + "DESCRIPTION,PRIORITY,UPDATE_DATE,UPDATED_BY,PILLAR,DEACTIVATE,PARENT,CAPEX,OPEX,(select count(1) from CH_PROJECT "
                 + "where PARENT=p.ID)SUBPROJECTS from CH_PROJECT p ";
        int key_wordCounter = 0;
        String key_word;
        if ((!name.equals("null")) && (!name.isEmpty())){
            if(key_wordCounter == 0)
                key_word = "WHERE";
            else
                key_word = " AND";
           strCmd += key_word + " NAME like '%"+ name +"%'";
           key_wordCounter++;
        }
        
        if ((!status.equals("null")) && (!name.isEmpty())){
            if(key_wordCounter == 0)
                key_word = "WHERE";
            else
                key_word = " AND";
            strCmd += key_word + " nvl(STATUS,0) = " + Integer.parseInt(status);
            key_wordCounter++;
        }
        
        int priority = 0;
        if ((!projectPriority.trim().equalsIgnoreCase("null")) && (!projectPriority.isEmpty())){
            if(key_wordCounter == 0)
                key_word = "WHERE";
            else
                key_word = " AND";
           priority = Integer.valueOf(projectPriority);
           strCmd += key_word + " nvl(PRIORITY,0)= "+ priority;
           key_wordCounter++;
        }
               
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<Project> projects = new ArrayList<Project>();
        ResourceDAO resourceDAO=null;
        SystemDAO systemDAO=null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            
            
           strCmd += " order by CREATED_DATE desc,UPDATE_DATE desc";
           st = conn.prepareStatement(strCmd); 
            
            rs = st.executeQuery();
            projects = ProjectMapper.mapProjects(rs);
                    
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
            for(Project project: projects){
              resourceDAO = new ResourceDAO();           
              //Get resources for each project
              ArrayList<Resource> resources = resourceDAO.getProjectResource(project.getId());
              project.setResources(resources);
            }
            
            for(Project project: projects){
               systemDAO = new SystemDAO();
              //Get systems for each project
              ArrayList<System> systems = systemDAO.getProjectSystems(project.getId());
              project.setSystems(systems);
            }
            
            for(Project project: projects){
              ArrayList<ProjectTask> ProjectTasks = getProjectTasks(project.getId());
              project.setTasks(ProjectTasks);
            }
            
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get projects".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projects; 
    }
   
     public ArrayList<Project> getTreeViewProjects(boolean basic){
         
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<Project> projects = new ArrayList<Project>();
        ResourceDAO resourceDAO=null;
        SystemDAO systemDAO=null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT ID, NAME,START_DATE,STATUS,END_DATE,CREATED_BY,CREATED_DATE,EXPECTED_DATE,REVENUE_IMPACT,USAGE_IMPACT,PROJECT_OWNER,PROJECT_MANAGER,DESCRIPTION,PRIORITY,UPDATE_DATE,UPDATED_BY,PILLAR,DEACTIVATE,PARENT,CAPEX,OPEX,(select count(1) from CH_PROJECT where PARENT=p.ID)SUBPROJECTS from CH_PROJECT p where nvl(PARENT,0) = 0 and NVL(DEACTIVATE,0) != 1 and NVL(STATUS,0) != 2 order by CREATED_DATE desc,UPDATE_DATE desc");
            rs = st.executeQuery();
            projects = ProjectMapper.mapProjects(rs);
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
            for(Project project: projects){
              resourceDAO = new ResourceDAO();           
              //Get resources for each project
              ArrayList<Resource> resources = basic?resourceDAO.getResourceMatrix(project.getId()):resourceDAO.getProjectResource(project.getId());
              project.setResources(resources);
            }
            
            for(Project project: projects){
               systemDAO = new SystemDAO();
              //Get systems for each project
              ArrayList<System> systems = basic?systemDAO.getBasicSystems(project.getId()):systemDAO.getProjectSystems(project.getId());
              project.setSystems(systems);
            }
            
            for(Project project: projects){
              ArrayList<ProjectTask> ProjectTasks = getProjectTasks(project.getId());
              project.setTasks(ProjectTasks);
            }
            
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get projects".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projects;
    }
     
     public ArrayList<Project> getTreeViewProjectChildren(int projectId){
         
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<Project> projects = new ArrayList<Project>();
        ResourceDAO resourceDAO=null;
        SystemDAO systemDAO=null;
        Connection conn = null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT ID, NAME,START_DATE,STATUS,END_DATE,CREATED_BY,CREATED_DATE,EXPECTED_DATE,REVENUE_IMPACT,USAGE_IMPACT,PROJECT_OWNER,PROJECT_MANAGER,DESCRIPTION,PRIORITY,UPDATE_DATE,UPDATED_BY,PILLAR,DEACTIVATE,PARENT,CAPEX,OPEX,(select count(1) from CH_PROJECT where PARENT=p.ID)SUBPROJECTS from CH_PROJECT p where PARENT="+ projectId +" and NVL(DEACTIVATE,0) != 1 and NVL(STATUS,0) != 2 order by CREATED_DATE desc,UPDATE_DATE desc");
            rs = st.executeQuery();
            
            projects = ProjectMapper.mapProjects(rs);
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
            for(Project project: projects){
              resourceDAO = new ResourceDAO();           
              //Get resources for each project
              ArrayList<Resource> resources = resourceDAO.getProjectResource(project.getId());
              project.setResources(resources);
            }
            
            for(Project project: projects){
               systemDAO = new SystemDAO();
              //Get systems for each project
              ArrayList<System> systems = systemDAO.getProjectSystems(project.getId());
              project.setSystems(systems);
            }
            
            for(Project project: projects){
             ArrayList<ProjectTask> ProjectTasks = getProjectTasks(project.getId());
              project.setTasks(ProjectTasks);
            }

        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get projects".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projects;
     }
     
    
     public ArrayList<Project> getProjectParents(){
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<Project> projects = new ArrayList<Project>();
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT ID, NAME,START_DATE,STATUS,END_DATE,CREATED_BY,CREATED_DATE,EXPECTED_DATE,REVENUE_IMPACT,USAGE_IMPACT,PROJECT_OWNER,PROJECT_MANAGER,DESCRIPTION,PRIORITY,UPDATE_DATE,UPDATED_BY,PILLAR,DEACTIVATE,PARENT,CAPEX,OPEX,(select count(1) from CH_PROJECT where PARENT=p.ID)SUBPROJECTS from CH_PROJECT p where nvl(PARENT,0) = 0 and NVL(DEACTIVATE,0) != 1 and NVL(STATUS,0) != 2 order by NAME");
            rs = st.executeQuery();
            
            projects = ProjectMapper.mapProjects(rs);
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get projects".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projects;
    }
     
     public ArrayList<Project> getAllProjects(boolean basic){
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<Project> projects = new ArrayList<Project>();
        ResourceDAO resourceDAO=null;
        SystemDAO systemDAO=null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(ProjectSQL.GetAllProjects.toString());
            rs = st.executeQuery();
            
            projects = ProjectMapper.mapProjects(rs);
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
            for(Project project: projects){
              resourceDAO = new ResourceDAO();           
              //Get resources for each project
              ArrayList<Resource> resources = basic?resourceDAO.getResourceMatrix(project.getId()):resourceDAO.getProjectResource(project.getId());
              project.setResources(resources);
            }
            
            for(Project project: projects){
               systemDAO = new SystemDAO();
              //Get systems for each project
              ArrayList<System> systems = basic?systemDAO.getBasicSystems(project.getId()):systemDAO.getProjectSystems(project.getId());
              project.setSystems(systems);
            }
            
            for(Project project: projects){
              ArrayList<ProjectTask> ProjectTasks = getProjectTasks(project.getId());
              project.setTasks(ProjectTasks);
            }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            log.error("Unable to get projects", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projects;
    }
     
    
    public ArrayList<ProjectPillar> getProjectPillars(){
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<ProjectPillar> projectPillars = new ArrayList<ProjectPillar>();
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT id, name, description FROM CH_PROJECT_PILLAR order by name");
            rs = st.executeQuery();
            
            while(rs.next()){
                ProjectPillar projectPillar = new ProjectPillar();
                projectPillar.setId(rs.getInt("id"));
                projectPillar.setName(rs.getString("name"));
                projectPillar.setDescription(rs.getString("description"));
                projectPillars.add(projectPillar);
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
        }catch(Exception ex){
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get project pillars".concat(ex.getMessage()));
            
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projectPillars;
    }
        
    
    //Get project and basic systems
    public ArrayList<Project> getProjectSystemMatrix(){
        ArrayList<Project> projects = new ArrayList<Project>();
        ResultSet rs=null,rs2=null;
        PreparedStatement st=null,st2=null;
        SystemDAO systemDAO=null;      
        Connection conn = null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            //Get All projects
            st = conn.prepareStatement(ProjectSQL.GetProjectMatrix.toString());
            rs = st.executeQuery();
            projects = ProjectMapper.mapProjectMatrix(rs);
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
            //Get System Matrix for each project
            for(Project project: projects){
                int projectId = project.getId();
                systemDAO = new SystemDAO();
                
                project.setSystems(systemDAO.getSystemResourceMatrix(projectId));
            }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex2){}
        }
        finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return projects;
    }
    
   
    //Get project and basic resources
    public ArrayList<Project> getProjectResourceMatrix(){
        ArrayList<Project> projects = new ArrayList<Project>();
        ResultSet rs=null,rs2=null;
        PreparedStatement st=null,st2=null;
        ResourceDAO resourceDAO=null;      
        Connection conn = null;
        
        try{
            conn = DBConnectionManager.getConnection("CH");
            //Get All projects
            st = conn.prepareStatement(ProjectSQL.GetProjectMatrix.toString());
            rs = st.executeQuery();
            projects = ProjectMapper.mapProjectMatrix(rs);
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
            
            //Get Resource  Matrix for each project
            for(Project projectMatrix: projects){
                int projectId = projectMatrix.getId();
                resourceDAO = new ResourceDAO();
                
                //Make call to resource DAO to append resource matrix
                projectMatrix.setResources(resourceDAO.getResourceMatrix(projectId));
            }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex2){}
        }
        finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return projects;
    }
    
    //Get project and tasks assigned to a user
    public ArrayList<Project> getUserProjectTasks(String userId){
        ArrayList<Project> projects = new ArrayList<Project>();
        return projects;
    }
    
    //Get project by ID
    public Project getProject(int projectId){
        PreparedStatement st = null;
        ResultSet rs = null;
        Project project = new Project();
        ArrayList<Resource> resources = new ArrayList<Resource>();
        ArrayList<System> systems = new ArrayList<System>();
        ArrayList<Attachment> attachments = new ArrayList<Attachment>();
        ArrayList<ProjectTask> tasks = new ArrayList<ProjectTask>();
        List<Skill> skills = new ArrayList<>();
        
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT a.*,to_char(expected_date,'DD/MM/YYYY') as date_expected," +
                                       "(SELECT b.username FROM CH_CAP_USER b WHERE upper(a.project_owner) = upper(b.user_id(+)) AND ROWNUM < 2) project_owner_full ," +
                                       "(SELECT b.username FROM CH_CAP_USER b WHERE upper(a.project_manager) = upper(b.user_id(+)) AND ROWNUM < 2) project_manager_full ," +
                                       "(SELECT c.username FROM CH_CAP_USER c WHERE upper(a.business_owner) = upper(c.user_id(+)) AND ROWNUM < 2) business_owner_full" +
                                       " FROM CH_PROJECT a WHERE ID="+projectId);
            rs = st.executeQuery();
            
            while(rs.next()){
                project.setId(rs.getInt("id"));
                project.setName(rs.getString("name"));
                project.setDescription(rs.getString("description"));
                project.setStartDate(rs.getString("start_date"));
                project.setPriority(rs.getInt("priority"));
                project.setStatus(rs.getInt("status"));
                project.setEndDate(rs.getString("end_date"));
                project.setCreatedBy(rs.getString("created_by"));
                project.setCreatedDate(rs.getString("created_date"));
                project.setExpectedDate(rs.getString("date_expected"));
                project.setRevenueImpact(rs.getDouble("revenue_impact"));
                project.setUsageImpact(rs.getInt("usage_impact"));
                project.setProjectOwner(new Resource(rs.getString("project_owner"), rs.getString("project_owner_full"), ""));
                project.setProjectManager(new Resource(rs.getString("project_manager"), rs.getString("project_manager_full"), ""));
                project.setBusinessOwner(new Resource(rs.getString("business_owner"), rs.getString("business_owner_full"), ""));
                project.setParent(rs.getInt("parent"));
                project.setProject_pillar_id(rs.getInt("pillar"));
                project.setDeactivate(rs.getInt("deactivate"));
                project.setCapex(rs.getDouble("capex"));
                project.setOpex(rs.getDouble("opex"));
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
            st = conn.prepareStatement("SELECT a.*,b.role_name,c.title,c.department,c.username,c.email FROM CH_PROJECT_TEAM a,CH_PROJECT_ROLE b,CH_CAP_USER c WHERE a.project_id="+projectId+" AND a.role_id=b.role_id AND a.user_id=c.user_id");
            rs = st.executeQuery();
            
            while(rs.next()){
                Resource resource = new Resource(rs.getString("user_id"), rs.getString("username"), rs.getString("email"));
                resource.setTitle(rs.getString("title"));
                resource.setDepartment(rs.getString("department"));
                Role role = new Role(rs.getInt("role_id"), rs.getString("role_name"));
                resource.setRole(role);
                resource.setSystems(getSystemsForResource(resource.getUserName(), projectId));
                resources.add(resource);
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
            st = conn.prepareStatement("SELECT a.project_id, b.id as sys_id, b.name, b.description, c.* FROM CH_PROJECT_SYSTEM a JOIN CH_SYSTEM b ON a.system_id=b.id left join CH_SYSTEM_ATTRIBUTES c ON a.SYSTEM_ID = c.SYSTEM_ID WHERE a.project_id="+projectId);
            rs = st.executeQuery();
            
            while(rs.next()){
                System system = new System();
                SystemAttributes systemAttributes = new SystemAttributes();
                system.setId(rs.getInt("sys_id"));
                system.setName(rs.getString("name"));
                system.setDescription(rs.getString("DESCRIPTION"));

                systemAttributes.setApiDocumentation(rs.getString("apidocumentation"));
                systemAttributes.setCapex(rs.getDouble("capex"));
                systemAttributes.setDatabaseName(rs.getString("databasename"));
                systemAttributes.setDatabaseServerName(rs.getString("databaseservername"));
                systemAttributes.setHostingSystem(rs.getString("hostingsystem"));
                systemAttributes.setId(rs.getInt("id"));
                systemAttributes.setLanguage(rs.getString("language"));
//                systemAttributes.setLicenseRequired(licenseRequired);
                systemAttributes.setOperatingSystem(rs.getString("operatingsystem"));
                systemAttributes.setOpex(rs.getDouble("opex"));
                systemAttributes.setServerName(rs.getString("servername"));
                systemAttributes.setSystemId(rs.getInt("system_id"));
                systemAttributes.setThirdParty(rs.getString("thirdparty"));

                system.setAttributes(systemAttributes);
                system.setSkills(new SkillDAO().getSkillsForSystem(rs.getInt("sys_id")));
                systems.add(system);
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
            st = conn.prepareStatement("SELECT * FROM CH_PROJECT_ATTACHMENT WHERE project_id="+projectId+" ");
            rs = st.executeQuery();
            
            while(rs.next()){
                Attachment attachment = new Attachment();
                attachment.setProjectId(rs.getInt("project_id"));
                attachment.setFilename(rs.getString("filename"));
                attachment.setCreatedBy(rs.getString("created_by"));
                attachment.setCreatedDate(rs.getString("created_date"));
                attachments.add(attachment);
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
            tasks = getProjectTasks(projectId);
            
            project.setSystems(systems);
            project.setResources(resources);
            project.setAttachments(attachments);
            project.setTasks(tasks);
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get project".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return project;
    }
    
    private ArrayList<System> getSystemsForResource(String username, int projectId) {
        PreparedStatement st = null;
        ResultSet systResultSet = null;
        Connection conn = null;
        ArrayList<System> systems = new ArrayList<System>();
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT s.ID, s.NAME, s.DESCRIPTION FROM CH_DEV.CH_SYSTEM s, CH_DEV.CH_PROJECT_USER_SYSTEM pus WHERE s.ID = pus.SYSTEM_ID AND pus.USER_ID = '" + username + "' AND pus.PROJECT_ID = " + projectId);
            systResultSet = st.executeQuery();
            while(systResultSet.next()){
                System resourceSystem = new System();
                resourceSystem.setId(systResultSet.getInt("ID"));
                resourceSystem.setName(systResultSet.getString("NAME"));
                resourceSystem.setDescription(systResultSet.getString("DESCRIPTION"));
                systems.add(resourceSystem);
            }
            systResultSet.close();
            st.close();
        } catch(Exception exception) {
            try{
                if(systResultSet!=null)systResultSet.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
        } finally {
            try{
                if(systResultSet!=null)systResultSet.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
        }
        return systems;
    }
    
    //Get all systems
    public ArrayList<System> getAllSystems(){
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<System> systems = new ArrayList<System>();
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(SystemSQL.GetAllSystemUnconditionally.toString());
            rs = st.executeQuery();
            
            while(rs.next()){
                System system = new System();
                system.setId(rs.getInt("id"));
                system.setName(rs.getString("name"));
                system.setDescription(rs.getString("DESCRIPTION"));
                systems.add(system);
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to get systems".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return systems;
    }
    
        public ArrayList<Resource> getAllResources(List<Skill> skills){
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<Resource> resources = new ArrayList<Resource>();
        
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            String skillsIds = "";
            int index =0;
            for(Skill skill:skills){
                if(index!=0)
                {
                    skillsIds+=", ";
                }
                skillsIds += String.valueOf(skill.getId());
                index++;
            }
            
            String query = "SELECT cs.*, ur.ROLE_ID, pr.ROLE_NAME FROM CH_CAP_USER cs LEFT JOIN CH_CAP_USER_ROLE ur ON cs.USER_ID = ur.USER_ID LEFT JOIN CH_PROJECT_ROLE pr "
                    + "ON pr.ROLE_ID = ur.ROLE_ID WHERE LOWER(cs.USER_ID) IN (SELECT DISTINCT LOWER(USER_ID) FROM CH_CAP_USER_SKILL_MAP WHERE "
                    + "SKILL_ID IN (0" + ((!skillsIds.isEmpty()) ? ", " + skillsIds : "") + "))";

            st = conn.prepareStatement(ResourceSQL.getAllNewResources.toString());
            rs = st.executeQuery();
            
            while(rs.next()){
                Resource resource = new Resource(rs.getString("user_id"), rs.getString("username"), rs.getString("email"));
                resource.setRole(new Role(rs.getInt("role_id"),rs.getString("role_name")));
                resources.add(resource);
            }

            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            log.error("Unable to get resources ", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return resources;
    }
    
    //Get all resources
    
     public ArrayList<ProjectTask> getProjectTasks(int projectId){
        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<ProjectTask> projectTasks = new ArrayList<ProjectTask>();
        Connection conn = null;
        try{
            
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT p.*,username FROM CH_PROJECT_TASK p LEFT JOIN CH_CAP_USER ON ASSIGNED_TO = USER_ID WHERE project_id="+ projectId +" order by creation_date desc,update_date desc");
            rs = st.executeQuery();
            
            while(rs.next()){
                
                ProjectTask task = new ProjectTask();
                task.setId(rs.getInt("task_id"));
                task.setProjectId(projectId);
                task.setName(rs.getString("name"));
                task.setStatus(rs.getInt("status"));
                task.setUpdateBy(new Resource(rs.getString("update_by"), "", ""));
                task.setDescription(rs.getString("description"));
                task.setEstimateDays(rs.getDouble("estimate_days"));
                task.setEstimateHours(rs.getDouble("estimate_hours"));
                task.setTimeSpent(rs.getDouble("time_spent"));
                task.setCreatedby(rs.getString("created_by"));
                task.setCreatedDate(rs.getDate("creation_date"));
                task.setUpdatedDate(rs.getDate("update_date"));
                task.setPriority(rs.getInt("priority"));
                task.setSeverity(rs.getInt("severity"));
                task.setParentId(rs.getInt("parent_id"));
                task.setAssignedTo(new Resource(rs.getString("ASSIGNED_TO"), rs.getString("username"), ""));
                
                task.setComments(new TaskDAO().getTaskComments(rs.getInt("task_id")));
                projectTasks.add(task);
                
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            log.error("Unable to get Project tasks: ", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return projectTasks;
    }
    
    //add system to project
    public boolean addSystemToProject(int projectId,int systemId){
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("INSERT INTO ch_project_system VALUES("+projectId+","+systemId+")");
            st.executeQuery();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to add System".concat(ex.getMessage()));
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    //add resource to project
    public boolean addResourceToProject(int projectId,String resourceId){
        PreparedStatement st = null, st1 = null;
        ResultSet rs = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            
            st1 = conn.prepareStatement("SELECT * FROM CH_PROJECT_TEAM WHERE PROJECT_ID = ? AND LOWER(USER_ID) = ? AND ROLE_ID = ?");
            st1.setInt(1, projectId);
            st1.setString(2, resourceId.toLowerCase());
            st1.setInt(3, 46);
            rs = st1.executeQuery();
            if(!rs.next()){
                st = conn.prepareStatement("INSERT INTO ch_project_team (project_id, user_id, role_id) VALUES("+projectId+",'"+resourceId+"',46)");
                st.executeUpdate();
                if(st!=null)st.close();
            }
            rs.close();
            st1.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            log.error("Unable to add Resource", ex);
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    

    //remove resource from project
    public boolean removeResourceFromProject(int projectId,String resourceId){
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("DELETE FROM ch_project_team WHERE project_id="+projectId+" AND user_id='"+resourceId+"'");
            st.executeQuery();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to remove Resource".concat(ex.getMessage()));
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    //remove task from project
    public boolean removeTaskFromProject(int projectId,int taskId){
        PreparedStatement st = null, st1 = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            //Delete dependencies first
            st1 = conn.prepareStatement("DELETE FROM CH_TASK_COMMENT WHERE TASK_ID="+taskId);
            st1.executeUpdate();
            st1.close();
            
            st = conn.prepareStatement("DELETE FROM CH_PROJECT_TASK WHERE PROJECT_ID="+projectId+" AND TASK_ID="+taskId);
            st.executeUpdate();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            log.error("Unable to remove Resource", ex);
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    //remove resource from project
    public boolean removeSystemFromProject(int projectId,int systemId){
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("DELETE FROM ch_project_system WHERE project_id="+projectId+" AND system_id="+systemId);
            st.executeQuery();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to remove Resource".concat(ex.getMessage()));
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    public ArrayList<Resource> getProjectResources(int projectId){
        PreparedStatement st = null;
        Connection conn = null;
        ResultSet rs = null;
        ArrayList<Resource> resources = new ArrayList<Resource>();
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT a.*,b.role_name,c.title,c.department,c.username, c.email FROM CH_PROJECT_TEAM a,CH_PROJECT_ROLE b,CH_CAP_USER c WHERE a.project_id="+projectId+" AND a.role_id=b.role_id AND a.user_id=c.user_id");
            rs = st.executeQuery();
            
            while(rs.next()){
                Resource resource = new Resource(rs.getString("user_id"), rs.getString("username"), rs.getString("email"));
                resource.setTitle(rs.getString("title"));
                resource.setDepartment(rs.getString("department"));
                Role role = new Role(rs.getInt("role_id"), rs.getString("role_name"));
                resource.setRole(role);
                resources.add(resource);
            }
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
        }catch(Exception e){
            try{if(rs!=null)rs.close();}catch(Exception ee){}
            try{if(st!=null)st.close();}catch(Exception eee){}
            return null;
        }
        
        return resources;
    }
    
    public boolean updateProjectResourceSystem(int projectId,String resourceId,int systemId){
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("UPDATE ch_project_user_system SET system_id="+systemId+" WHERE LOWER(user_id)='"+resourceId.toLowerCase()+"' AND project_id="+projectId);
            st.executeUpdate();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to update ch_project_user_system : ".concat(ex.getMessage()));
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    public boolean insertProjectResourceSystem(int projectId,String resourceId,int systemId){
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("INSERT INTO ch_project_user_system VALUES("+projectId+",'"+resourceId+"',"+systemId+")");
            st.executeUpdate();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to update ch_project_user_system : ".concat(ex.getMessage()));
            return false;
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        return true;
    }
    
    
    public ArrayList<Resource> getProjectResourceSystem(int projectId){
        ArrayList<Resource> resources = new ArrayList<Resource>();
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT * FROM CH_PROJECT_USER_SYSTEM WHERE PROJECT_ID="+projectId);
            rs = st.executeQuery();
            
            while(rs.next()){
                ArrayList<Integer> resSystems = new ArrayList();
                ArrayList<Integer> resProjects = new ArrayList();
                
                Resource resource = new Resource(rs.getString("user_id"), "", "");             
                resSystems.add(rs.getInt("system_id"));
                resProjects.add(rs.getInt("project_id"));
                resource.setSystemId(resSystems);
                resource.setProjectId(resProjects);
                resources.add(resource);
            }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            org.apache.log4j.Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resources;
    }   
    
    
    public ArrayList<Resource>  getResourceMatrix(){
        ArrayList<Resource> resources = new ArrayList<Resource>();
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select distinct b.USER_ID,b.USERNAME,a.SYSTEM_ID, a.PROJECT_ID from CH_PROJECT_USER_SYSTEM a,CH_CAP_USER b where a.user_id = b.user_id");
            rs = st.executeQuery();
            resources = ResourceMapper.mapResourceMatrix(rs);
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            org.apache.log4j.Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resources;
    }
    
    public ArrayList<Integer> getAllSystemsMatrix(){
        ArrayList<Integer> systems = new ArrayList<Integer>();
        PreparedStatement st=null;
        ResultSet rs = null,rs2=null;
        Connection conn = null;
        try{
            conn =  DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select ID from CH_SYSTEM");
            rs = st.executeQuery();
            systems = SystemMapper.mapSystemIds(rs);

            if(rs!=null)rs.close();
            if(st!=null)st.close(); 
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex2){}
            org.apache.log4j.Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR,"Unable to get all systems. Error: "+ex.getMessage());
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }     
        return systems;
    }
    
    public boolean activateProject(int projectId){
       boolean result = false;
       Connection conn = null;
        PreparedStatement st = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("update CH_PROJECT set DEACTIVATE = 0 where ID="+ projectId);
            st.execute();
            result = true;
        }catch(Exception ex){
            result = false;
            org.apache.log4j.Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }
            catch(Exception ex){
            }
        }
        return result;
    } 
    
    public boolean deactivateProject(int projectId){
       boolean result = false;
       Connection conn = null;
        PreparedStatement st = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("update CH_PROJECT set DEACTIVATE = 1 where ID="+ projectId);
            st.execute();
            result = true;
        }catch(Exception ex){
            result = false;
            org.apache.log4j.Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }
            catch(Exception ex){
            }
        }
        return result;
    } 
        
}
