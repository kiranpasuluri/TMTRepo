/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.ResultWrapper;
import za.co.trudon.tmt.data.type.response.Skill;
import za.co.trudon.tmt.mappers.SkillMapper;
import za.co.trudon.tmt.sql.SkillSQL;

/**
 *
 * @author MangenaS
 */
public class SkillDAO {
    
    private static final Logger LOGGER = Logger.getLogger(SkillDAO.class);
    
    private Connection conn;
    
    public SkillDAO(){
        try{
            conn = DBConnectionManager.getConnection("CH");
        }catch(Exception e){}
    }
    
    public ArrayList<Skill> getSkillsForSystem(int systemId){
        PreparedStatement st=null;
        ResultSet rs = null;
        ArrayList<Skill> skills=null;
        
        try{
            st = conn.prepareStatement("select sl.SKILL_ID,sl.SKILL_NAME from CH_SKILLS_LIST sl, ch_system_skill ss  where ss.system_id="+systemId+" and sl.skill_id=ss.skill_id");
            //st.setInt(1, systemId);
            rs = st.executeQuery();
            skills = SkillMapper.mapSkills(rs);
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(SkillDAO.class.getName()).log(Priority.ERROR,"Unable to get skill. Error: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return skills;
    }
    
    public ArrayList<Skill> getResourceSkills(String username){
        PreparedStatement st=null;
        ResultSet rs = null;
        ArrayList<Skill> skills=null;
        
        try{
            st = conn.prepareStatement("select sl.SKILL_ID,sl.SKILL_NAME from CH_SKILLS_LIST sl, ch_cap_user_skill_map ss  where upper(ss.user_id)=upper(?1) and sl.skill_id=ss.skill_id");
            st.setString(1, username.toUpperCase());
            rs = st.executeQuery();
            skills = SkillMapper.mapSkills(rs);
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(SkillDAO.class.getName()).log(Priority.ERROR,"Unable to get skill. Error: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return skills;
    }
    
        public ArrayList<Skill> getAllSkills(){
        PreparedStatement st=null;
        ResultSet rs = null;
        ArrayList<Skill> skills=null;
        
        try{
            st = conn.prepareStatement("select sl.SKILL_ID,sl.SKILL_NAME from CH_SKILLS_LIST sl");
            rs = st.executeQuery();
            skills = SkillMapper.mapSkills(rs);
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(SkillDAO.class.getName()).log(Priority.ERROR,"Unable to get skill. Error: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return skills;
    }
        
     public void updateSkillsForUser(List<Skill> skills, String username){
        PreparedStatement st=null;
        
        try{
            removeAllResourceSkills(username); //Removing what exists first
            if(conn == null || conn.isClosed())
                conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("INSERT INTO CH_CAP_USER_SKILL_MAP (USER_ID, SKILL_ID) VALUES(?1,?2)");
            
            for(Skill skill: skills) {
                st.setString(1, username);
                st.setInt(2, skill.getId());
                st.addBatch();
            }
            st.executeBatch();   
            
            st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            LOGGER.error("Unable to update skill. Error: ", ex);
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
    }
    
    public void removeResourceSkills(List<Skill> skills, String username) {
        PreparedStatement st=null;
        ResultSet rs = null;
            try{
            st = conn.prepareStatement("DELETE FROM CH_CAP_USER_SKILL_MAP WHERE UPPER(USER_ID) = ?1 AND SKILL_ID = ?2");
            
            for(Skill skill: skills) {
                st.setString(1, username.toUpperCase());
                st.setInt(2, skill.getId());
                st.addBatch();
            }
            st.executeBatch();   
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(SkillDAO.class.getName()).log(Priority.ERROR,"Unable to delete skills. Error: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
    }
    
        public void removeAllResourceSkills(String username) {
        PreparedStatement st=null;
        ResultSet rs = null;
            try{
            st = conn.prepareStatement("DELETE FROM CH_CAP_USER_SKILL_MAP WHERE UPPER(USER_ID) = ?");
            st.setString(1, username.toUpperCase());
            st.executeUpdate();   
            
            if(rs!=null)rs.close();
            if(st!=null)st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(SkillDAO.class.getName()).log(Priority.ERROR,"Unable to delete all skills. Error: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
    }
        
    public void addNewSkill(Skill skill){
        PreparedStatement st=null;
        try{

            st = conn.prepareStatement("INSERT INTO CH_SKILLS_LIST (SKILL_ID,SKILL_NAME) VALUES(CH_SKILLSLIST_SEQ.nextval, ?1)");
            st.setString(1, skill.getName());
            st.executeUpdate();
            
            st.close();
            if(conn!=null)conn.close();
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            LOGGER.error("Unable to add new skill. Error: ", ex);
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
    }    
}
