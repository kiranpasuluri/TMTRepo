/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.CapUser;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.ResourceDetailsMapper;
import za.co.trudon.tmt.data.type.response.Role;
import za.co.trudon.tmt.data.type.response.UserSuggestionResponseWrapper;
import za.co.trudon.tmt.enums.ResourceSearchEnum;
import za.co.trudon.tmt.mappers.ResourceMapper;
import za.co.trudon.tmt.sql.ResourceSQL;
import za.co.trudon.tmt.sql.RoleSQL;

/**
 *
 * @author MangenaS
 */
public class ResourceDAO {
    private static final Logger LOGGER = org.apache.log4j.Logger.getLogger(ResourceDAO.class);
    public ResourceDAO(){
    }
    
    //Get all list of all resources associated with a project id
    public ArrayList<Resource> getProjectResource(int projectId){
        ArrayList<Resource> resources = new ArrayList<Resource>();
        ArrayList<String> resourceIds=null;
        PreparedStatement st=null;
        ResultSet rs=null;
        SystemDAO systemDAO = null;
        Connection conn=null;
        try{           
               //Get resources 
                conn = DBConnectionManager.getConnection("CH");
                st = conn.prepareStatement(ResourceSQL.GetResourceDetails.toString());
                st.setInt(1, projectId);
                rs = st.executeQuery();
                resources = ResourceMapper.mapResource(rs);
                
                //Append skills for each resource
                for(Resource resource:resources){
                   systemDAO = new  SystemDAO();
                   resource.setSystemId(systemDAO.getResourceSystem(resource.getUserName()));
                }
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            
        }catch(Exception ex){
                try{
                    if(rs!=null)rs.close();
                    if(st!=null)st.close();
                    if(conn!=null)conn.close();
                }catch(Exception e){}
            Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resources for project. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resources;
    }
    
    //Return resources without systemIds for a project
    public ArrayList<Resource> getResourceMatrix(int projectId){
        ArrayList<Resource> resources = new ArrayList<Resource>();
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(ResourceSQL.GetResourceMatrix.toString());
            st.setInt(1, projectId);
            rs = st.executeQuery();  
            resources = ResourceMapper.mapResourceMatrix(rs);
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resources;
    }
    
     public ArrayList<Resource> getResourceSystemMatrix(){
        ArrayList<Resource> resources = new ArrayList<Resource>();
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select b.USER_ID,b.USERNAME,a.SYSTEM_ID, a.PROJECT_ID from CH_PROJECT_USER_SYSTEM a inner join CH_CAP_USER b on lower(b.USER_ID) = lower(a.USER_ID)");
            rs = st.executeQuery();  
            resources = ResourceMapper.mapResourceMatrix(rs);
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resources;
    }
    
    //Return all resources and the projects they are involved in
    public ArrayList<Resource> getResourceMatrix(){
        ArrayList<Resource> resources = new ArrayList<Resource>();
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(ResourceSQL.GetResourceProjectMatrix.toString());
            rs = st.executeQuery();  
            resources = ResourceMapper.mapResourceProjectMatrix(rs);
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource matrix. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resources;
    }
    
    public Resource getResourceForUsername(String username) {
        Resource resource = null;
        PreparedStatement st=null;
        ResultSet rs=null;
        Connection conn=null;
        try{           
               //Get resources 
                conn = DBConnectionManager.getConnection("CH");
                st = conn.prepareStatement("SELECT * FROM CH_CAP_USER WHERE upper(USER_ID) = ?");
                st.setString(1, username.toUpperCase());
                rs = st.executeQuery();
               if(rs != null) {
                while(rs.next()) {
                resource = new Resource(rs.getString("user_id"), rs.getString("username"), rs.getString("email"));
                resource.setTitle(rs.getString("title"));
                resource.setDepartment(rs.getString("department"));
                }
            }
                if(rs!=null)rs.close();
                st.close();
                conn.close();
            
        }catch(Exception ex){
                try{
                    if(rs!=null)rs.close();
                    if(st!=null)st.close();
                    if(conn!=null)conn.close();
                }catch(Exception e){}
            Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get resource. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resource;
    }
    
        public ArrayList<Role> getAllProjectRoles(){
        ArrayList<Role> roles = new ArrayList<Role>();
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select * from CH_PROJECT_ROLE");
            rs = st.executeQuery();  
            while(rs.next()) {
               Role role = new Role(rs.getInt("ROLE_ID"), rs.getString("ROLE_NAME"));
               roles.add(role);
            }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            Logger.getLogger(ResourceDAO.class.getName()).log(Priority.ERROR,"Unable to get roles. Error: ".concat(ex.getMessage())); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return roles;
    }
        
    public UserSuggestionResponseWrapper resourceAutocomplete(String query, ResourceSearchEnum resourceSearchEnum) {
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        CapUser user;
        List<CapUser> list = new ArrayList<CapUser>();
        UserSuggestionResponseWrapper userList = null;
        String queryString;
        try{
            conn = DBConnectionManager.getConnection("CH");
            switch(resourceSearchEnum) {
                case DEPARTMENT:
                    queryString = "SELECT DISTINCT DEPARTMENT FROM CH_CAP_USER WHERE LOWER(DEPARTMENT) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);    
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("DEPARTMENT"));
                        user.setData(rs.getString("DEPARTMENT"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                case NAME:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USERNAME) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("USERNAME"));
                        user.setData(rs.getString("USER_ID"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                case PROJECT:
                    queryString = "SELECT * FROM CH_PROJECT WHERE LOWER(NAME) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("NAME"));
                        user.setData(rs.getString("ID"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                case ROLE:
                    queryString = "SELECT * FROM CH_PROJECT_ROLE WHERE LOWER(ROLE_NAME) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("ROLE_NAME"));
                        user.setData(rs.getString("ROLE_ID"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                case SKILL:
                    queryString = "SELECT * FROM CH_SKILLS_LIST WHERE LOWER(SKILL_NAME) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("SKILL_NAME"));
                        user.setData(rs.getString("SKILL_ID"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                case SYSTEM:
                    queryString = "SELECT * FROM CH_SYSTEM WHERE LOWER(NAME) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("NAME"));
                        user.setData(rs.getString("ID"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                case TITLE:
                    queryString = "SELECT DISTINCT TITLE FROM CH_CAP_USER WHERE LOWER(TITLE) LIKE '%" + query.toLowerCase() + "%'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        user = new CapUser();
                        user.setValue(rs.getString("TITLE"));
                        user.setData(rs.getString("TITLE"));
                        list.add(user);
                    }
                    userList = new UserSuggestionResponseWrapper();
                    userList.setSuggestions(list);
                    break;
                default:
                    //Do nothing
                    break;
            }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            LOGGER.error("Unable to get resources. Error: ", ex); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }

        return userList;
    }
    
    public List<Resource> getResources(ResourceSearchEnum resourceSearchEnum, String query) {
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        String queryString;
        Resource resource;
        List<Resource> resources = new ArrayList<>();
        try{
            conn = DBConnectionManager.getConnection("CH");
            switch(resourceSearchEnum) {
                case DEPARTMENT:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(DEPARTMENT) = '" + query.toLowerCase() + "'";
                    st = conn.prepareStatement(queryString);    
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                case NAME:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USERNAME) = '" + query.toLowerCase() + "'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                case PROJECT:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USER_ID) IN (SELECT LOWER(USER_ID) FROM CH_PROJECT_TEAM WHERE PROJECT_ID =(SELECT ID FROM CH_PROJECT WHERE LOWER(NAME) = '" + query.toLowerCase() + "'))";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                case ROLE:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USER_ID) IN (SELECT LOWER(USER_ID) FROM CH_PROJECT_TEAM WHERE ROLE_ID = (SELECT ROLE_ID FROM CH_PROJECT_ROLE WHERE LOWER(ROLE_NAME) = '" + query.toLowerCase() + "'))";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                case SKILL:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USER_ID) IN (SELECT LOWER(USER_ID) FROM CH_CAP_USER_SKILL_MAP WHERE SKILL_ID = (SELECT SKILL_ID FROM CH_SKILLS_LIST WHERE LOWER(SKILL_NAME) = '" + query.toLowerCase() + "'))";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                case SYSTEM:
                    queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USER_ID) IN (SELECT DISTINCT LOWER(USER_ID) FROM CH_PROJECT_USER_SYSTEM WHERE SYSTEM_ID = (SELECT ID FROM CH_SYSTEM WHERE LOWER(NAME) = '" + query.toLowerCase() + "'))";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                case TITLE:
                    queryString = "SELECT * TITLE FROM CH_CAP_USER WHERE LOWER(TITLE) = '" + query.toLowerCase() + "'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resources.add(resource);
                    }
                    break;
                default:
                    //Do nothing
                    break;
            }
             return resources;
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            LOGGER.error("Unable to get resources. Error: ", ex); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return null;
    }

    public Resource getResourceDetails(String username) {
        PreparedStatement st=null;
        ResultSet rs = null;
        Connection conn=null;
        String queryString;
        Resource resource = null;
        try{ 
            conn = DBConnectionManager.getConnection("CH");
        queryString = "SELECT * FROM CH_CAP_USER WHERE LOWER(USER_ID) = '" + username.toLowerCase() + "'";
                    st = conn.prepareStatement(queryString);
                    rs = st.executeQuery();
                    while (rs.next()) {
                        resource = new Resource(rs.getString("USER_ID"), rs.getString("USERNAME"), rs.getString("EMAIL"));
                        resource.setDepartment(rs.getString("DEPARTMENT"));
                        resource.setTitle(rs.getString("TITLE"));
                        resource.setSkills(new SkillDAO().getResourceSkills(rs.getString("USER_ID")));
                        resource.setSystems(new SystemDAO().getResourceSystems(rs.getString("USER_ID")));
                        break;
                    }
        }catch(Exception ex){
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            LOGGER.error("Unable to get resources. Error: ", ex); 
        }finally{
            try{
                if(rs!=null)rs.close();
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}
        }
        return resource;
    }
}
