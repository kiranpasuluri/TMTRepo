package za.co.trudon.tmt.dal;

import java.sql.Connection;
import javax.naming.InitialContext;
import javax.sql.DataSource;

/**
 *
 * @author Tebogo
 */

public class DbConnection {

    private static Connection conn = null;

    public Connection openDB() throws Exception
    {
        //Create DB Connection
        InitialContext ctx = new InitialContext();
        DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/iauto");
        conn = ds.getConnection();
        return conn;
    }

}
