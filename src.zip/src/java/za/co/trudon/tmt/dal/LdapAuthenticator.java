package za.co.trudon.tmt.dal;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchResult;

public class LdapAuthenticator {

  static String ATTRIBUTE_FOR_USER = "sAMAccountName";
  
  LdapContext ctxGC;
  
  public LdapAuthenticator() {
     
  }

  private void initializeContext(String username, String host, String password, String _domain) {
    Hashtable environment = new Hashtable();
    environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
    environment.put(Context.PROVIDER_URL, "ldap://" + host + ":389");
    environment.put(Context.SECURITY_AUTHENTICATION, "simple");
    environment.put(Context.SECURITY_PRINCIPAL, username + "@" + _domain);
    environment.put(Context.SECURITY_CREDENTIALS, password);
    try {
      ctxGC = new InitialLdapContext(environment, null);
      } catch (NamingException e) {
        int k = 0;
    }
  }
  
  public User authenticateUser(String username, String password, String _domain, String host, String dn) {
    initializeContext(username, host, password, _domain);
    return getUserBasicAttributes(username, ctxGC);
  }
  
  public String[] authenticateBafUser(String username,String _domain,String host,String dn) {
    Hashtable environment = new Hashtable();
    environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
    environment.put(Context.PROVIDER_URL, "ldap://" + host + ":389");
    environment.put(Context.SECURITY_AUTHENTICATION, "simple");
    environment.put(Context.SECURITY_PRINCIPAL, "IBISAdmin" + "@" + _domain);
    environment.put(Context.SECURITY_CREDENTIALS, "s00317");
    try {
      ctxGC = new InitialLdapContext(environment, null);
//      return getUserBasicAttributes(username, ctxGC);
    } catch (NamingException e) {
    }
    return null;
  }
  
  private User getUserBasicAttributes(String username, LdapContext ctx) {
    
      User user = null;
    try {
        SearchControls constraints = new SearchControls();
        constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
        String[] attrIDs = { "distinguishedName",
                        "sn",
                        "givenname",
                        "mail",
                        "telephonenumber",
                        "name",
                        "department",
                        "title",
                        "memberOf"};
        constraints.setReturningAttributes(attrIDs);
        //First input parameter is search bas, it can be "CN=Users,DC=YourDomain,DC=com"
        //Second Attribute can be uid=username
        //"tds.co.za", "trudonjhbdc00", "DC=tds,DC=co,DC=za"
        NamingEnumeration answer = ctx.search("DC=tds,DC=co,DC=za", "sAMAccountName="
                        + username, constraints);
        if (answer.hasMore()) {
            
            
            Attributes attrs = ((SearchResult) answer.next()).getAttributes();
            user = new User(attrs.get("name").toString().substring(attrs.get("name").toString().indexOf(':')+1), 
                    attrs.get("givenname").toString().substring(attrs.get("givenname").toString().indexOf(':')+1), 
                    attrs.get("sn").toString().substring(attrs.get("sn").toString().indexOf(':')+1), 
                    attrs.get("department").toString().substring(attrs.get("department").toString().indexOf(':')+1),
                    attrs.get("telephonenumber").toString().substring(attrs.get("telephonenumber").toString().indexOf(':')+1),
                    attrs.get("mail").toString().substring(attrs.get("mail").toString().indexOf(':')+1), 
                    username, attrs.get("title").toString().substring(attrs.get("title").toString().indexOf(':')+1));

        }else{
                throw new Exception("Invalid User");
        }

    } catch (Exception ex) {
        return null;
    }
        return user;
    }
  
  public static void main(String args[]) {
      User user = new LdapAuthenticator().authenticateUser("maremam", "NewPass1001", "tds.co.za", "trudonjhbdc00.tds.co.za", "DC=tds,DC=co,DC=za");
      
  }
}