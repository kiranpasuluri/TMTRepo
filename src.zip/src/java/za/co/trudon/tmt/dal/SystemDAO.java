/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.data.type.response.Skill;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.mappers.SystemMapper;
import za.co.trudon.tmt.sql.SkillSQL;
import za.co.trudon.tmt.data.type.response.System;
import za.co.trudon.tmt.sql.SystemSQL;
import za.co.trudon.tmt.data.type.response.SystemAttributes;
import za.co.trudon.tmt.mappers.SkillMapper;

/**
 *
 * @author MangenaS
 */
public class SystemDAO {

    private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger(SystemDAO.class);

    public SystemDAO() {
    }

    //Return systems for a project without skills
    public ArrayList<System> getBasicSystems(int projectId) {
        PreparedStatement st = null, st2 = null;
        ResultSet rs = null, rs2 = null;
        ArrayList<System> systems = new ArrayList<System>();
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");

            st = conn.prepareStatement(SystemSQL.GetProjectSystems.toString());
            st.setInt(1, projectId);
            rs = st.executeQuery();
            systems = SystemMapper.mapSystems(rs, false);
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            LOGGER.error("Unable to get basic systems. Error: ", ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    //Get all systems and their skills for a project
    public ArrayList<System> getProjectSystems(int projectId) {
        PreparedStatement st = null, st2 = null;
        ResultSet rs = null, rs2 = null;
        ArrayList<System> systems = new ArrayList<System>();
        ArrayList<Skill> skills = new ArrayList<Skill>();
        SkillDAO skillDAO = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            //Get Systems
            st = conn.prepareStatement(SystemSQL.GetProjectSystems.toString());
            st.setInt(1, projectId);
            rs = st.executeQuery();
            systems = SystemMapper.mapSystems(rs, false);
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }

            //Get skills
            for (System system : systems) {
                skillDAO = new SkillDAO();
                skills = skillDAO.getSkillsForSystem(system.getId());
                system.setSkills(skills);
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (rs2 != null) {
                    rs2.close();
                }
                if (st != null) {
                    st.close();
                }
                if (st2 != null) {
                    st2.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get project systems. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (rs2 != null) {
                    rs2.close();
                }
                if (st != null) {
                    st.close();
                }
                if (st2 != null) {
                    st2.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    //Get all systems and the number of projects each system is involved in
    public ArrayList<System> getAllSystems() {
        ArrayList<System> systems = new ArrayList<System>();
        PreparedStatement st = null, st2 = null;
        ResultSet rs = null, rs2 = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(SystemSQL.GetAllSystems.toString());
            rs = st.executeQuery();
            systems = SystemMapper.mapSystems(rs, true);

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get all systems. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    public ArrayList<System> getSystemsProjectsMatrix() {
        ArrayList<System> systems = new ArrayList<System>();
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(SystemSQL.GetAllSystems.toString());
            rs = st.executeQuery();

            while (rs.next()) {
                System system = new System();
                system.setId(rs.getInt("id"));
                system.setName(rs.getString("name"));
                system.setProjects(getProjectSystemsMatrix(rs.getInt("id")));;
                systems.add(system);
            }

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get all systems. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    public ArrayList<Project> getProjectSystemsMatrix(int systemId) {
        ArrayList<Project> projects = new ArrayList<Project>();
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select p.ID,p.NAME from CH_PROJECT p inner join ch_project_system c on c.PROJECT_ID = p.ID where c.SYSTEM_ID =" + systemId);
            rs = st.executeQuery();

            while (rs.next()) {
                Project project = new Project();
                project.setId(rs.getInt("id"));
                project.setName(rs.getString("name"));
                projects.add(project);
            }

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get all projects. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return projects;
    }

    //return list of systemIds for associated user
    public ArrayList<Integer> getResourceSystem(String userId) {
        ArrayList<Integer> systems = new ArrayList<Integer>();
        PreparedStatement st = null, st2 = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(SystemSQL.GetUserSystems.toString());
            st.setString(1, userId.toLowerCase());
            rs = st.executeQuery();
            systems = SystemMapper.mapSystemIds(rs);

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get all systemIds for user. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }
    
        public ArrayList<System> getResourceSystems(String userId) {
        ArrayList<System> systems = new ArrayList<>();
        PreparedStatement st = null, st2 = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select * from CH_SYSTEM where ID in (select DISTINCT SYSTEM_ID from CH_USER_SYSTEM where LOWER(USER_ID)=? and system_id is not null)");
            st.setString(1, userId.toLowerCase());
            rs = st.executeQuery();
            systems = SystemMapper.mapSystems(rs, false);

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            LOGGER.error("Unable to get all systemIds for user. Error: ", ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    public ArrayList<System> getResourceSystemMatrix(int systemId) {
        ArrayList<System> systems = new ArrayList<System>();
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("select ID,Name from CH_SYSTEM where ID =" + systemId + "");
            rs = st.executeQuery();
            systems = SystemMapper.mapResourceSystemMatrix(rs);

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get all systemIds for user. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    //Get systems and the resources 
    public ArrayList<System> getSystemResourceMatrix(int projectId) {
        ArrayList<System> systems = new ArrayList<System>();
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");

            st = conn.prepareStatement(SystemSQL.GetSystemResourceMatrix.toString());
            st.setInt(1, projectId);
            rs = st.executeQuery();
            systems = SystemMapper.mapSystemResourceMatrix(rs);
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get system resource matrix. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    public ArrayList<SystemAttributes> getSystemsAttributes(int systemId) {

        PreparedStatement st = null;
        ResultSet rs = null;
        ArrayList<SystemAttributes> systemAttributesCollection = new ArrayList<SystemAttributes>();
        Connection conn = null;

        try {

            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("SELECT ID,nvl(SYSTEM_ID,0)SYSTEM_ID,nvl(SERVERNAME,' ')SERVERNAME,nvl(DATABASENAME,' ')DATABASENAME,nvl(DATABASESERVERNAME,' ')DATABASESERVERNAME,nvl(OPERATINGSYSTEM,' ')OPERATINGSYSTEM,nvl(HOSTINGSYSTEM,' ')HOSTINGSYSTEM,nvl(LANGUAGE,' ')LANGUAGE,nvl(APIDOCUMENTATION,' ')APIDOCUMENTATION,nvl(LICENSEREQUIRED,' ')LICENSEREQUIRED,nvl(THIRDPARTY,' ')THIRDPARTY,nvl(FREQUENCY,0)FREQUENCY,nvl(CAPEX,0)CAPEX,nvl(OPEX,0)OPEX FROM CH_SYSTEM_ATTRIBUTES WHERE SYSTEM_ID=" + systemId + " order by ROWNUM desc");
            rs = st.executeQuery();

            while (rs.next()) {

                SystemAttributes systemAttributes = new SystemAttributes();
                systemAttributes.setId(rs.getInt("id"));
                systemAttributes.setSystemId(rs.getInt("system_id"));
                systemAttributes.setServerName(rs.getString("servername"));
                systemAttributes.setDatabaseName(rs.getString("databasename"));
                systemAttributes.setDatabaseServerName(rs.getString("databaseservername"));
                systemAttributes.setOperatingSystem(rs.getString("operatingsystem"));
                systemAttributes.setHostingSystem(rs.getString("hostingsystem"));
                systemAttributes.setLanguage(rs.getString("language"));
                systemAttributes.setApiDocumentation(rs.getString("apidocumentation"));
                systemAttributes.setLicenseRequired(rs.getString("licenserequired"));
                systemAttributes.setThirdParty(rs.getString("thirdparty"));
                systemAttributes.setFrequency(rs.getInt("frequency"));
                systemAttributes.setCapex(rs.getDouble("capex"));
                systemAttributes.setOpex(rs.getDouble("opex"));

                systemAttributesCollection.add(systemAttributes);
            }

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }

        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get systems attribute. Error: " + ex.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systemAttributesCollection;
    }

    public boolean updateSystemAttributes(SystemAttributes systemAttributes) {
        boolean result = false;
        Connection conn = null;
        PreparedStatement st = null;
        try {
            conn = DBConnectionManager.getConnection("CH");

            if (systemAttributes.getId() > 0) {
                st = conn.prepareStatement("update CH_SYSTEM_ATTRIBUTES set SERVERNAME = '" + systemAttributes.getServerName() + "',DATABASENAME =  '" + systemAttributes.getDatabaseName() + "',DATABASESERVERNAME = '" + systemAttributes.getDatabaseServerName() + "',OPERATINGSYSTEM =  '" + systemAttributes.getOperatingSystem() + "',HOSTINGSYSTEM= '" + systemAttributes.getHostingSystem() + "',LANGUAGE= '" + systemAttributes.getLanguage() + "',APIDOCUMENTATION = '" + systemAttributes.getApiDocumentation() + "',LICENSEREQUIRED = '" + systemAttributes.getLicenseRequired() + "',THIRDPARTY = '" + systemAttributes.getThirdParty() + "',FREQUENCY = " + systemAttributes.getFrequency() + ",CAPEX=" + systemAttributes.getCapex() + ",OPEX=" + systemAttributes.getOpex() + " where ID = " + systemAttributes.getId());
            } else {
                st = conn.prepareStatement("insert INTO CH_SYSTEM_ATTRIBUTES(SYSTEM_ID,SERVERNAME,DATABASENAME,DATABASESERVERNAME,OPERATINGSYSTEM,HOSTINGSYSTEM,LANGUAGE,APIDOCUMENTATION,LICENSEREQUIRED,THIRDPARTY,FREQUENCY,CAPEX,OPEX)values(" + systemAttributes.getSystemId() + ",'" + systemAttributes.getServerName() + "','" + systemAttributes.getDatabaseName() + "','" + systemAttributes.getDatabaseServerName() + "','" + systemAttributes.getOperatingSystem() + "','" + systemAttributes.getHostingSystem() + "','" + systemAttributes.getLanguage() + "','" + systemAttributes.getApiDocumentation() + "','" + systemAttributes.getLicenseRequired() + "','" + systemAttributes.getThirdParty() + "'," + systemAttributes.getFrequency() + "," + systemAttributes.getCapex() + "," + systemAttributes.getOpex() + ")");
            }
            st.execute();
            result = true;
        } catch (Exception ex) {
            result = false;
            org.apache.log4j.Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get System Attributes. Error: ".concat(ex.getMessage()));
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return result;
    }

    public boolean deleteSystemAttributes(int id) {
        boolean result = false;
        Connection conn = null;
        PreparedStatement st = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("DELETE FROM CH_SYSTEM_ATTRIBUTES where ID=" + id);
            st.execute();
            result = true;
        } catch (Exception ex) {
            result = false;
            org.apache.log4j.Logger.getLogger(SystemDAO.class.getName()).log(Priority.ERROR, "Unable to get System Attributes. Error: ".concat(ex.getMessage()));
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return result;
    }

    //Get all systems including skills for each system
    public List<System> getSystems() {
        List<System> systems = new ArrayList<System>();
        PreparedStatement st = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement(SystemSQL.GetAllSystemUnconditionally.toString());
            rs = st.executeQuery();
            systems = SystemMapper.mapSystems(rs, false);
            if (rs != null) {
                rs.close();
            }
            st.close();

            for (System sys : systems) {
                List<Skill> systemSkills;
                st = conn.prepareStatement(SystemSQL.GetSystemSkill.toString());
                st.setInt(1, sys.getId());
                rs = st.executeQuery();
                systemSkills = SkillMapper.mapSkills(rs);
                sys.setSkills(systemSkills);
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
            }

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex2) {
            }
            LOGGER.error("Unable to get all systems. Error: ", ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
        return systems;
    }

    public void updateSkillsForSystem(List<Skill> skills, int systemId) {
        PreparedStatement st = null;
        Connection conn = null;
        try {
            removeAllSystemSkills(systemId); //Removing what exists first
            if (conn == null || conn.isClosed()) {
                conn = DBConnectionManager.getConnection("CH");
            }
            st = conn.prepareStatement("INSERT INTO CH_SYSTEM_SKILL (SYSTEM_ID, SKILL_ID) VALUES(?1,?2)");

            for (Skill skill : skills) {
                st.setInt(1, systemId);
                st.setInt(2, skill.getId());
                st.addBatch();
            }
            st.executeBatch();

            st.close();
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
            LOGGER.error("Unable to update skill. Error: ", ex);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }

    }

    public void removeAllSystemSkills(int systemId) {
        PreparedStatement st = null;
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("DELETE FROM CH_SYSTEM_SKILL WHERE SYSTEM_ID = ?");
            st.setInt(1, systemId);
            st.executeUpdate();

            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
            LOGGER.error("Unable to delete all skills. Error: ", ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
    }

    public void updateSystem(System system) {
        PreparedStatement st = null;
        Connection conn = null;
        try {

            conn = DBConnectionManager.getConnection("CH");

            st = conn.prepareStatement("UPDATE CH_SYSTEM SET NAME = ?, DESCRIPTION = ?  WHERE ID = ?");

            st.setString(1, system.getName());
            st.setString(2, system.getDescription());
            st.setInt(3, system.getId());
            
            st.executeUpdate();
            
            if(system.getAttributes() != null){
                saveOrUpdateAttributes(system.getAttributes());
            }

            st.close();
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
            LOGGER.error("Unable to update system. Error: ", ex);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }

    }
    
        public void addSystem(System system) {
        PreparedStatement st = null, st1 = null;
        ResultSet rs = null;
        Connection conn = null;
        int systemId = 0;
        try {

            conn = DBConnectionManager.getConnection("CH");
            String sqlSeq = "SELECT CH_SYSTEM_SEQ.NEXTVAL as seq_id FROM dual";
            st1 = conn.prepareStatement(sqlSeq);
            rs = st1.executeQuery();
            while(rs.next()){
                systemId = rs.getInt("seq_id");
            }
            rs.close();
            st1.close();
            
            st = conn.prepareStatement("INSERT INTO CH_SYSTEM VALUES(?,?,?)");
            st.setInt(1, systemId);
            st.setString(2, system.getName());
            st.setString(3, system.getDescription());
            
            st.executeUpdate();
            
            if(system.getAttributes() != null){
                system.getAttributes().setSystemId(Integer.parseInt(sqlSeq));
                saveOrUpdateAttributes(system.getAttributes());
            }

            st.close();
            if (conn != null) {
                conn.close();
            }
        } catch (Exception ex) {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
            LOGGER.error("Unable to update system. Error: ", ex);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }

    }

    private void saveOrUpdateAttributes(SystemAttributes systemAttributes) {
        PreparedStatement st = null;
        Connection conn = null;
        try {

            conn = DBConnectionManager.getConnection("CH");

            
            
        if(systemAttributes.getId() > 0){
            st = conn.prepareStatement("UPDATE CH_SYSTEM_ATTRIBUTES SET SERVERNAME = ?, DATABASENAME = ?, DATABASESERVERNAME = ?, OPERATINGSYSTEM = ?, HOSTINGSYSTEM =?,"
                    + " LANGUAGE = ?, APIDOCUMENTATION = ?, THIRDPARTY = ?, FREQUENCY = ?, CAPEX = ?, OPEX = ?  WHERE ID = ?");
            st.setString(1, systemAttributes.getServerName());
            st.setString(2, systemAttributes.getDatabaseName());
            st.setString(3, systemAttributes.getDatabaseServerName());
            st.setString(4, systemAttributes.getOperatingSystem());
            st.setString(5, systemAttributes.getHostingSystem());
            st.setString(6, systemAttributes.getLanguage());
            st.setString(7, systemAttributes.getApiDocumentation());
            st.setString(8, systemAttributes.getThirdParty());
            st.setDouble(9, systemAttributes.getFrequency());
            st.setDouble(10, systemAttributes.getCapex());
            st.setDouble(11, systemAttributes.getOpex());
            st.setInt(0, systemAttributes.getId());
        } else {
            String insertQuery = "INSERT INTO CH_SYSTEM_ATTRIBUTES (ID, SYSTEM_ID, SERVERNAME, DATABASENAME, DATABASESERVERNAME, OPERATINGSYSTEM, HOSTINGSYSTEM, "
                    + "LANGUAGE, APIDOCUMENTATION, THIRDPARTY, FREQUENCY, CAPEX, OPEX) "
                    + "VALUES(CH_SYSTEM_ATTRIBUTES_SEQ1.NEXTVAL, ?,?,?,?,?,?,?,?,?,?,?,?)";
            st = conn.prepareStatement(insertQuery);
            st.setInt(1, systemAttributes.getSystemId());
            st.setString(2, systemAttributes.getServerName());
            st.setString(3, systemAttributes.getDatabaseName());
            st.setString(4, systemAttributes.getDatabaseServerName());
            st.setString(5, systemAttributes.getOperatingSystem());
            st.setString(6, systemAttributes.getHostingSystem());
            st.setString(7, systemAttributes.getLanguage());
            st.setString(8, systemAttributes.getApiDocumentation());
            st.setString(9, systemAttributes.getThirdParty());
            st.setDouble(10, systemAttributes.getFrequency());
            st.setDouble(11, systemAttributes.getCapex() == null ? 0 : systemAttributes.getCapex());
            st.setDouble(12, systemAttributes.getOpex() == null ? 0 : systemAttributes.getOpex());
        }
        st.executeQuery();
        } catch (Exception ex) {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
            }
            LOGGER.error("Unable to update system. Error: ", ex);
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
            }
        }
    }
    
    public void addResourceSystem(String username, int systemId) {
        PreparedStatement st = null;
        Connection conn = null;
        try{
            conn = DBConnectionManager.getConnection("CH");
            st = conn.prepareStatement("INSERT INTO ch_user_system VALUES('"+username+"',"+systemId+")");
            st.executeUpdate();
            
            if(st!=null)st.close();
            
        }catch(Exception ex){
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception e){}
            java.util.logging.Logger.getLogger(ProjectDAO.class.getName()).log(Level.SEVERE, "Unable to update ch_user_system : ".concat(ex.getMessage()));
            
        }finally{
            try{
                if(st!=null)st.close();
                if(conn!=null)conn.close();
            }catch(Exception ex){}    
        }
        
    }
}
