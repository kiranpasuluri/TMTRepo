package za.co.trudon.tmt.dal;
/**
 *
 * @author ramekosit
 */

public class User {

    private String fullName;
    private String firstName;
    private String lastName;
    private String department;
    private String telephoneNumber;
    private String mail;
    private String userName;
    private String title;

    public User() {
        
    }
    
    public User(String fullName, String firstName, String lastName, String department, String telephoneNumber,
            String mail, String userName, String title) {
        this.fullName = fullName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
        this.mail = mail;
        this.userName = userName;
        this.telephoneNumber = telephoneNumber;
        this.title = title;
    }

        public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
   
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    @Override
    public String toString(){
        return "First name: " + firstName + "\nLast name: " + lastName + "\nemail: " + mail + "\nDepartment: " + department + "\nTitle: " + title;
    }
}
