/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import com.google.gson.Gson;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.SystemDAO;
import za.co.trudon.tmt.data.type.response.Skill;
import za.co.trudon.tmt.data.type.response.System;

/**
 *
 * @author MaremaM
 */
@Path("/systems")
public class SystemService {
        private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger(SystemService.class);

  @GET
  @Produces(MediaType.TEXT_HTML)
  public void getSystems(@Context HttpServletResponse response, @Context HttpServletRequest request) throws Exception {
      try{
          Gson gson = new Gson();
          SystemDAO systemDAO = new SystemDAO();
          List<System> systems = systemDAO.getSystems();
          
          request.setAttribute("systems", gson.toJson(systems));
          request.getRequestDispatcher("/systems.jsp").forward(request, response);
      }catch(Exception exception) {
           LOGGER.error("Unable to get connection. Error: ", exception);
      }
  }   

    @POST
    @Path("/skills/update/{systemId}")
    @Produces(MediaType.APPLICATION_JSON)
    public void updateSkills(List<Skill> skills,@Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("systemId") int systemId) throws ServletException,IOException,TrudoException_Exception,Exception {
        try{
            SystemDAO systemDAO = new SystemDAO();
            systemDAO.updateSkillsForSystem(skills, systemId);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
    }
    
    @POST
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
    public void updateSystem(System system,@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try{
            SystemDAO systemDAO = new SystemDAO();
            systemDAO.updateSystem(system);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
    }
    
    @POST
    @Path("/save")
    @Produces(MediaType.APPLICATION_JSON)
    public void addSystem(System system,@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try{
            SystemDAO systemDAO = new SystemDAO();
            systemDAO.addSystem(system);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
    }

}
