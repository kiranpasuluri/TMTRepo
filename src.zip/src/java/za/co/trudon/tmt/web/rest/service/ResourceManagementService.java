/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import com.google.gson.Gson;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.ResourceDAO;
import za.co.trudon.tmt.dal.TaskDAO;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.UserSuggestionResponseWrapper;
import za.co.trudon.tmt.enums.ResourceSearchEnum;

/**
 *
 * @author MaremaM
 */
@Path("/resource_management")
public class ResourceManagementService {
    
  private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger(ResourceManagementService.class);
  
  @GET
  @Produces(MediaType.TEXT_HTML)
  public void getResources(@Context HttpServletResponse response, @Context HttpServletRequest request) throws Exception {
      try{
          Gson gson = new Gson();
          request.setAttribute("searchTypes", gson.toJson(ResourceSearchEnum.values()));
          request.getRequestDispatcher("/resource_management.jsp").forward(request, response);
      }catch(Exception exception) {
           LOGGER.error("Unable to get connection. Error: ", exception);
      }
  } 
  
  @POST
  @Path("/resource_search")
  @Produces(MediaType.APPLICATION_JSON)
  public UserSuggestionResponseWrapper resourceAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query, @FormParam("searchType") String searchType) throws ServletException,IOException,TrudoException_Exception,Exception {
      ResourceDAO resourceDAO = new ResourceDAO();
      return resourceDAO.resourceAutocomplete(query, ResourceSearchEnum.valueOf(searchType));
  }
  
  @GET
  @Path("/search/{searchValue}/searchType/{searchType}")
  @Produces(MediaType.APPLICATION_JSON)
  public List<Resource> getResources(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("searchValue") String searchValue, @PathParam("searchType") String searchType) throws ServletException,IOException,TrudoException_Exception,Exception {
      ResourceDAO resourceDAO = new ResourceDAO();
      List<Resource> resources = resourceDAO.getResources(ResourceSearchEnum.valueOf(searchType), searchValue);
      return resources;
  }
  
  @GET
  @Path("/username/{username}")
  @Produces(MediaType.TEXT_HTML)
  public void getResourceDetails(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("username") String username) throws ServletException,IOException,TrudoException_Exception,Exception {
      ResourceDAO resourceDAO = new ResourceDAO();
      Resource resource = resourceDAO.getResourceDetails(username);
      TaskDAO taskDAO = new TaskDAO();
      request.setAttribute("resourceProfile",new Gson().toJson(resource));
      request.setAttribute("projects",taskDAO.getUserAssignedTasks(username));
     request.getRequestDispatcher("/resource_profile.jsp").forward(request, response);
  }
  
}
