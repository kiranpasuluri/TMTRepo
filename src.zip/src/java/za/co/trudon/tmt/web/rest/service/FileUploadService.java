package za.co.trudon.tmt.web.rest.service;

import com.idrsolutions.image.jpeg.JpegEncoder;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.output.DeferredFileOutputStream;
import za.co.trudon.tmt.dal.BirdsDao;
import za.co.trudon.tmt.helper.Helper;
import za.co.trudon.tmt.helper.image.ImageResizer;
import za.co.trudon.tmt.properties.AutoRefreshPropertiesReader;

@Path("/upload")
public class FileUploadService {

    @POST
    @Path("/project/{projectId}/{createdBy}")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response simpleUpload(@Context HttpServletRequest request, @PathParam("projectId") int projectId, @PathParam("createdBy") String createdBy) throws Exception {     
        String output = "";
        boolean fileUploadResults = false;
        try{
            File uploadFile = null;
            File alternateUploadFile = null;
            BufferedOutputStream bos = null;
            File tempDir = new File(AutoRefreshPropertiesReader.getInstance().getString("project.files.folder")+"\\"+projectId);
            //File tempDir = new File("C:\\tmt_files\\"+projectId);
            //File tempDir = new File(AutoRefreshPropertiesReader.getInstance().getString("project.files.folder")+projectId);
            if(!tempDir.exists()){
                tempDir.mkdir();
            }
            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setSizeThreshold(5);
            factory.setRepository(tempDir);
            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setSizeMax(31457280);
            List items = upload.parseRequest(request);

            FileItem fileItemToUpload = null;
            for (Iterator ie = items.iterator(); ie.hasNext();) {
                FileItem fi = (FileItem) ie.next();
                if (!fi.isFormField()) {
                     fileItemToUpload = fi;
                }
            }
            String fileName = fileItemToUpload.getName();
            //uploadFile = new File(AutoRefreshPropertiesReader.getInstance().getString("project.files.folder")+projectId+"/"+fileName);
            uploadFile = new File(AutoRefreshPropertiesReader.getInstance().getString("project.files.folder")+"\\"+projectId+"\\"+fileName);
            //uploadFile = new File("C:\\tmt_files\\"+projectId+"\\"+fileName);
            FileOutputStream fos = new FileOutputStream(uploadFile);            
            bos = new BufferedOutputStream(fos);
            bos.write(fileItemToUpload.get());
            bos.close();
            output = "Done";
            
            BirdsDao birdsDao = new BirdsDao();
            fileUploadResults = birdsDao.saveProjectAttachment(projectId,fileName,createdBy);
            
        }catch(Exception e){
            output = "Error";
            return Response.status(200).entity(output).build();
        }

        return Response.status(200).entity(output).build();

    }

    private int getNextFileIndex(String fileRepository) {
        boolean noFileInThisName = false;
        int fileIndex = 1;
        while (!noFileInThisName) {
            File f = new File(fileRepository + "m_" + fileIndex + ".jpg");
            if (f.exists()) {
                fileIndex++;
            } else {
                noFileInThisName = true;
                break;
            }
        }
        return fileIndex;
    }

}
