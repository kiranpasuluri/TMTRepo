/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.comm.webservice.CommsframeworkWebService;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.data.type.response.NotificationTemplate;
import za.co.trudon.tmt.webservicemanager.CommunicationServiceManager;

/**
 *
 * @author MaremaM
 */
@Path("/notifications")
public class EmailService {
    
    @Inject
    CommunicationServiceManager communicationServiceManager;
    
    private static final String SUBJECT = "Task Allocation";
    
    private static final String PROJECT_SUBJECT = "New Project";

    private static final String FROM_ADDRESS = "noreply@yellowprojects.co.za";
    
    private static final String FROM_DISPLAY_NAME = "Yellow Projects";
    
    @POST
    @Path("/task/email")
    @Consumes(MediaType.APPLICATION_JSON)
    public void sendEmail(NotificationTemplate notificationTemplate, @Context HttpServletResponse response, @Context HttpServletRequest request)  throws ServletException,IOException,TrudoException_Exception{
        String template = "NotificationManager\\\\AssignTaskv1.html";
        String replyToAddress = "";
        String replyToDisplayName = "";
        String embeddedAttachments = "";
        String textData = notificationTemplate.getTask().getAssignedTo().getFullNames() + "; " 
                + notificationTemplate.getProject().getName() + "; "
                + notificationTemplate.getProject().getBusinessOwner().getFullNames() + "; "
                + notificationTemplate.getProject().getCreatedDate() + "; "
                + notificationTemplate.getProject().getProjectOwner().getFullNames() + "; "
                + notificationTemplate.getProject().getProjectManager().getFullNames() + "; "
                + notificationTemplate.getProject().getExpectedDate();
        
        String result = sendEmail(notificationTemplate.getTask().getAssignedTo().getEmail(), SUBJECT, textData, template, replyToAddress, replyToDisplayName, embeddedAttachments);
    }
    
    @POST
    @Path("/project/email")
    @Consumes(MediaType.APPLICATION_JSON)
    public void sendProjectCreationEmail(NotificationTemplate notificationTemplate, @Context HttpServletResponse response, @Context HttpServletRequest request)  throws ServletException,IOException,TrudoException_Exception{
        String template = "NotificationManager\\\\NewProjectv1.html";
        String replyToAddress = "";
        String replyToDisplayName = "";
        String embeddedAttachments = "";
        List<String> recipients = new ArrayList<>();
        StringBuffer textData = new StringBuffer();
        textData.append("; ");
        textData.append(notificationTemplate.getProject().getName());
        textData.append("; ");
        textData.append(new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
        textData.append("; ");
        textData.append(notificationTemplate.getProject().getProjectOwner().getFullNames());
        textData.append("; ");
        textData.append(notificationTemplate.getProject().getProjectManager().getFullNames());
        textData.append("; ");
        textData.append(notificationTemplate.getProject().getExpectedDate());
        
        textData.insert(0, notificationTemplate.getProject().getBusinessOwner().getFullNames());
        sendEmail(notificationTemplate.getProject().getBusinessOwner().getEmail(), PROJECT_SUBJECT, textData.toString(), template, replyToAddress, replyToDisplayName, embeddedAttachments);
        
        textData.replace(0, notificationTemplate.getProject().getBusinessOwner().getFullNames().length(), notificationTemplate.getProject().getProjectManager().getFullNames());
        sendEmail(notificationTemplate.getProject().getProjectManager().getEmail(), PROJECT_SUBJECT, textData.toString(), template, replyToAddress, replyToDisplayName, embeddedAttachments);
        
        textData.replace(0, notificationTemplate.getProject().getProjectManager().getFullNames().length(), notificationTemplate.getProject().getProjectOwner().getFullNames());
        sendEmail(notificationTemplate.getProject().getProjectOwner().getEmail(), PROJECT_SUBJECT, textData.toString(), template, replyToAddress, replyToDisplayName, embeddedAttachments);
    
    }
    
    private String sendEmail(String recipient, String subject, String textData, String template, String replyToAddress, String replyToDisplayName, String embeddedAttachments) {
        return communicationServiceManager.sendEMAIL("", "", "", recipient, textData, template, subject, FROM_ADDRESS, FROM_DISPLAY_NAME, replyToAddress, 
                replyToDisplayName, "", embeddedAttachments, "", "");
    }
    
//    public static void main(String args[]){
//        CommsframeworkWebService cfws = new CommsframeworkWebService();
//        String result = cfws.getCommsframeworkWebServiceSoap().sendEMAIL("", "SDP", "Activiti", "maremam@trudon.co.za", "Margaret; SDP; Ndaba; 2017-09-07; Matshediso; Lucas; 2017-09-30", "NotificationManager\\\\AssignTask.html",
//                SUBJECT, FROM_ADDRESS, FROM_DISPLAY_NAME, "", "", "", "NotificationManager\\\\logo.png", "", "");
//        System.out.println(result);
//    }
    
}
