/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import com.google.gson.Gson;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.ReportDAO;
import za.co.trudon.tmt.dal.ResourceDAO;
import za.co.trudon.tmt.dal.TaskDAO;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.request.TimesheetSearchParams;
import za.co.trudon.tmt.data.type.response.Report;
import za.co.trudon.tmt.data.type.response.Timesheet;
import za.co.trudon.tmt.data.type.response.UserSuggestionResponseWrapper;
import za.co.trudon.tmt.enums.ResourceSearchEnum;

/**
 *
 * @author MaremaM
 */
@Path("/reports")
public class ReportService {
    
  private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger(ReportService.class);
  
  @GET
  @Path("/daily/report")
  @Produces(MediaType.TEXT_HTML)
  public void getDailyReports(@Context HttpServletResponse response, @Context HttpServletRequest request) throws Exception {
      try{
          Gson gson = new Gson();
          request.setAttribute("searchTypes", gson.toJson(ResourceSearchEnum.values()));
          request.getRequestDispatcher("/reports.jsp").forward(request, response);
      }catch(Exception exception) {
           LOGGER.error("Unable to get connection. Error: ", exception);
      }
  }
  
  @GET
  @Path("/monthly/report")
  @Produces(MediaType.TEXT_HTML)
  public void getMonthlyReports(@Context HttpServletResponse response, @Context HttpServletRequest request) throws Exception {
      try{
          Gson gson = new Gson();
          request.setAttribute("searchTypes", gson.toJson(ResourceSearchEnum.values()));
          request.getRequestDispatcher("/monthly_reports.jsp").forward(request, response);
      }catch(Exception exception) {
           LOGGER.error("Unable to get connection. Error: ", exception);
      }
  } 
  
  @GET
  @Path("/resources/timesheets")
  @Produces(MediaType.TEXT_HTML)
  public void getTimesheets(@Context HttpServletResponse response, @Context HttpServletRequest request) throws Exception {
      try{
          Gson gson = new Gson();
          request.getRequestDispatcher("/timesheets.jsp").forward(request, response);
      }catch(Exception exception) {
           LOGGER.error("Unable to get connection. Error: ", exception);
      }
  } 
  
  @POST
  @Path("/project")
  @Produces(MediaType.APPLICATION_JSON)
  public UserSuggestionResponseWrapper projectAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query) throws ServletException,IOException,TrudoException_Exception,Exception {
      ResourceDAO resourceDAO = new ResourceDAO();
      return resourceDAO.resourceAutocomplete(query, ResourceSearchEnum.valueOf("PROJECT"));
  }
  
  @POST
  @Path("/resource")
  @Produces(MediaType.APPLICATION_JSON)
  public UserSuggestionResponseWrapper resourceAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query) throws ServletException,IOException,TrudoException_Exception,Exception {
      ResourceDAO resourceDAO = new ResourceDAO();
      return resourceDAO.resourceAutocomplete(query, ResourceSearchEnum.valueOf("NAME"));
  }
  
  @POST
  @Path("/project/timesheet")
  @Produces(MediaType.APPLICATION_JSON)
  public Timesheet getWeeklyTimesheets(TimesheetSearchParams timeSheetParams, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
      return new ReportDAO().getTimesheets(timeSheetParams);
  }
  
  @POST
  @Path("/project/reports")
  @Produces(MediaType.APPLICATION_JSON)
  public Report getReports(TimesheetSearchParams timeSheetParams, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
      return new ReportDAO().getDailyReports(timeSheetParams);
  }
}
