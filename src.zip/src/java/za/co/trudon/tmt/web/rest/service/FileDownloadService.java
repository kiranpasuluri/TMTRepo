package za.co.trudon.tmt.web.rest.service;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import za.co.trudon.tmt.properties.AutoRefreshPropertiesReader;




/**
 *
 * @author ramekosit
 */
@Path("/download")
public class FileDownloadService {
  
  private static final Logger log = Logger.getLogger(FileDownloadService.class.getName());
  
    @GET
    @Path("/profileimage/{username}/size/{size}")
    @Produces("image/jpeg")
    public Response getFileInJPEGFormat(@PathParam("username") String username,@PathParam("size") String size)
    {
        //Put some validations here such as invalid file name or missing file name
        //Prepare a file object with file to return
        final String fileRepository = AutoRefreshPropertiesReader.getInstance().getString("profile.images.folder");
        File file = null;
        try{
            file = new File(fileRepository+size+"_"+username+".jpg");
            if(!file.exists()){
                file = new File(fileRepository+size+"_avatar.jpg");
            }
        }catch(Exception e_one){
          log.log(Level.SEVERE, "[FileDownloadService][getFileInJPEGFormat] ", "Error downloading file... "+size+"_"+username+".jpg");
        }
         
        Response.ResponseBuilder response = Response.ok((Object) file);
        response.header("Content-Disposition", "attachment; filename="+size+"_"+username+".jpg");
        return response.build();
    }
    
    @GET
    @Path("/{projectId}/{filename}")
    @Produces(MediaType.MEDIA_TYPE_WILDCARD)
    public Response getProjectFile(@PathParam("filename") String filename,@PathParam("projectId") String projectId)
    {
        //for Windows
        final String fileRepository = AutoRefreshPropertiesReader.getInstance().getString("project.files.folder")+"\\"+projectId+"\\";
        //final String fileRepository = "C:\\tmt_files\\"+projectId+"\\";
        //for Unix
        //final String fileRepository = AutoRefreshPropertiesReader.getInstance().getString("project.files.folder")+"/"+projectId+"/";
        File file = null;
        try{
            file = new File(fileRepository+filename);
        }catch(Exception e_one){
          log.log(Level.SEVERE, "[FileDownloadService][getProjectFile] ", "Error downloading file... "+filename);
        }
         
        Response.ResponseBuilder response = Response.ok((Object) file);
        response.header("Content-Disposition", "attachment; filename="+filename);
        return response.build();
    }
}
