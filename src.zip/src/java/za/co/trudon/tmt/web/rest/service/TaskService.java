/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import com.google.gson.Gson;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.TaskDAO;
import za.co.trudon.tmt.data.type.request.LoginData;
import za.co.trudon.tmt.data.type.request.TaskRequest;
import za.co.trudon.tmt.data.type.response.DailyTaskUpdate;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.TaskComment;
import za.co.trudon.tmt.enums.PriorityEnum;
import za.co.trudon.tmt.enums.ServerityEnum;
import za.co.trudon.tmt.enums.StatusEnum;
/**
 *
 * @author MangenaS
 */
@Path("/tasks")
public class TaskService {
    TaskDAO taskDAO = new TaskDAO();
    
    @GET    
    @Produces(MediaType.TEXT_HTML)
    public void showTasks(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        LoginData loginData =(LoginData)request.getSession().getAttribute("loginData");
                Gson gson = new Gson();
        request.setAttribute("projects", gson.toJson(taskDAO.getUserAssignedTasks(loginData.getUsername())));

        request.setAttribute("serverityValues", gson.toJson(ServerityEnum.values()));
        request.setAttribute("priorityValues", gson.toJson(PriorityEnum.values()));
        request.setAttribute("taskStatuses", gson.toJson(StatusEnum.values()));
        request.getRequestDispatcher("/tasks.jsp").forward(request, response);
    }
    
    
    @POST
    @Path("/close")
    @Consumes(MediaType.APPLICATION_JSON)
    public boolean closeTask(TaskRequest task){           
       return taskDAO.closeUserAssignedTask(task.getTaskId(), task.getComment());
    }
    
    @POST
    @Path("/estimate")
    @Consumes(MediaType.APPLICATION_JSON)
    public boolean assignTaskEstimate(TaskRequest task){
       return taskDAO.assignTaskEstimate(task.getTaskId(), task.getEstimate());
    }
    
    @POST
    @Path("/subtask")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addSubTask(ProjectTask task){
       taskDAO.addTask(task);
    }
    
    @POST
    @Path("/subtask/update")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateSubTask(ProjectTask task, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception {
       taskDAO.updateProjectTask(task);
    }

    @POST
    @Path("/comment")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addComment(TaskComment comment, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
       taskDAO.saveComment(comment);
    }
    
    @POST
    @Path("/subtask/daily/update/{username}/{comment}")
    @Produces(MediaType.APPLICATION_JSON)
    public void dailyTaskUpdate(DailyTaskUpdate dailyTaskUpdate, @Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("username") String username, @PathParam("comment") String comment) throws ServletException,IOException,TrudoException_Exception{
       taskDAO.dailyTaskUpdate(username, comment, dailyTaskUpdate);
    }
    
    public static void main(String args []) {
        String fromDate = "2017-10-01";
        String toDate = "2017-10-31";
        boolean cond = true;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try{
            Calendar cal = new GregorianCalendar();
            cal.setTime(df.parse(fromDate));
            System.out.print("Date is " + df.format(cal.getTime())); 
            System.out.print(" - Week number " + cal.get(Calendar.WEEK_OF_YEAR));
            System.out.print(" Day " + cal.get(Calendar.DAY_OF_WEEK));
            System.out.println(" and was a " + new SimpleDateFormat("EEEE").format(cal.getTime()).toUpperCase());
            while(cond){
                cal.add(Calendar.DATE, 1);
                if(df.format(cal.getTime()).equals(toDate)){
                    cond = false;
                }
                System.out.print("Date is " + df.format(cal.getTime())); 
                System.out.print(" - Week number " + cal.get(Calendar.WEEK_OF_YEAR));
                System.out.println(" and was a " + new SimpleDateFormat("EEEE").format(cal.getTime()).toUpperCase());
            }

        } catch(ParseException exception){
            exception.printStackTrace();
        }
    }
}
