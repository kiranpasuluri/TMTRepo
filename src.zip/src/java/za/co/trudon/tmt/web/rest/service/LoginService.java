/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import java.io.IOException;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import za.co.trudon.tmt.data.type.request.LoginData;
import za.co.trudon.tmt.data.type.request.LoginRequest;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.BirdsDao;
import za.co.trudon.tmt.dal.LdapAuthenticator;
import za.co.trudon.tmt.dal.RoleDAO;
import za.co.trudon.tmt.dal.User;
import za.co.trudon.tmt.dal.UserDAL;
import za.co.trudon.tmt.schedulers.ADHelper;

/**
 *
 * @author ramekosit
 */
@Stateless
@Path("/auth")
public class LoginService {
    
    private static final Logger LOGGER = org.apache.log4j.Logger.getLogger(LoginService.class);
    
    private HttpSession session = null;
    
    @Inject
     ADHelper adHelper;
    
    @GET    
    @Produces(MediaType.TEXT_HTML)
    public void getloginPage(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }
    
    @POST    
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/logoff")
    public boolean logoffUser(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        session = request.getSession();
        session.setAttribute("loginData", null);
        session.invalidate();
        return true;
    }
    
    @POST    
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/login")
    public LoginData loginUser(@Context HttpServletResponse response, @Context HttpServletRequest request,LoginRequest loginRequest) throws ServletException,IOException,TrudoException_Exception{
        session = request.getSession();
        LoginData loginData = null;
        try{
//        request.login(loginRequest.getUserName().trim().toLowerCase(), loginRequest.getPassword());
//        User user = new UserDAL().getUser(loginRequest.getUserName().toLowerCase());
        LdapAuthenticator ldapAuth = new LdapAuthenticator();     
        User user = ldapAuth.authenticateUser(loginRequest.getUserName().trim().toLowerCase(), loginRequest.getPassword(), "tds.co.za", "trudonjhbdc00.tds.co.za", "DC=tds,DC=co,DC=za");
        loginData = new LoginData();
        if(user!=null) {
            loginData.setSuccess(true);
            loginData.setMessage("Login Successful");
            loginData.setUsername(loginRequest.getUserName());
            loginData.setUser(user);
            loginData.setRole(new RoleDAO().getRole(loginRequest.getUserName()));
//            new Thread(() -> {          
//            adHelper.validateUser();
//            }).start();
            //record the login
            try{
                BirdsDao bd = new BirdsDao();
                bd.recordUserLoginActivity(loginRequest.getUserName().toLowerCase());
            }catch(Exception error){
                //no need to do anything this is for stats purposes only
            }
        } else {
            loginData.setSuccess(false);
            loginData.setMessage("Authentication failed, Username or Password is invalid");
        }
        
        session.setAttribute("loginData", loginData);
        } catch(Exception exception) {
            LOGGER.error("Login failure: ", exception);
        }
        return loginData;
    }
    
}
