/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;


import com.google.gson.Gson;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.ResourceDAO;
import za.co.trudon.tmt.dal.SkillDAO;
import za.co.trudon.tmt.dal.SystemDAO;
import za.co.trudon.tmt.data.type.request.LoginData;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.Skill;


/**
 *
 * @author ic
 */
@Path("/profile")
public class ProfileService {
    
    private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger(ProfileService.class);

  @GET
  @Produces(MediaType.TEXT_HTML)
  public void getUserProfile(@Context HttpServletResponse response, @Context HttpServletRequest request) throws Exception {
      ResourceDAO resourceDAO = new ResourceDAO();
      Resource resource = resourceDAO.getResourceDetails(((LoginData)request.getSession().getAttribute("loginData")).getUsername());
      request.setAttribute("resource",new Gson().toJson(resource));
      request.getRequestDispatcher("/profile.jsp").forward(request, response);
  }   

    @GET
    @Path("/resource/skills/{username}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Skill> getResourceSkills(@Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("username") String username) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Skill> skills = null;
        try{
            SkillDAO skillDAO = new SkillDAO();
            skills = skillDAO.getResourceSkills(username);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
        return  skills;
    }
    
    @GET
    @Path("/resource/skills")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Skill> getAllSkills(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Skill> skills = null;
        try{
            SkillDAO skillDAO = new SkillDAO();
            skills = skillDAO.getAllSkills();
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
        return  skills;
    }
    
    @POST
    @Path("/resource/skills/update/{username}")
    @Produces(MediaType.APPLICATION_JSON)
    public void updateSkills(List<Skill> skills,@Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("username") String username) throws ServletException,IOException,TrudoException_Exception,Exception {
        try{
            SkillDAO skillDAO = new SkillDAO();
            skillDAO.updateSkillsForUser(skills, username);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
    }
    
    @POST
    @Path("/resource/skills/save")
    @Produces(MediaType.APPLICATION_JSON)
    public void AddNewSkill(Skill skill,@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try{
            SkillDAO skillDAO = new SkillDAO();
            skillDAO.addNewSkill(skill);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
    }
    
    @POST
    @Path("/resource/{username}/system/{systemId}/")
    @Produces(MediaType.APPLICATION_JSON)
    public void AddResourceSystem(@Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("username") String username, @PathParam("systemId") int systemId) throws ServletException,IOException,TrudoException_Exception,Exception {
        try{
            SystemDAO systemDAO = new SystemDAO();
            systemDAO.addResourceSystem(username, systemId);
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
    }
}
