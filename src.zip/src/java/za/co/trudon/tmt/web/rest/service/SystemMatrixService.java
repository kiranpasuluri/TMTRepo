/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.ProjectDAO;
import za.co.trudon.tmt.dal.SystemDAO;
import za.co.trudon.tmt.data.type.response.System;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.System;
import za.co.trudon.tmt.data.type.response.SystemAttributes;
import za.co.trudon.tmt.data.type.response.SystemProjectMatrix;
/**
 *
 * @author MangenaS
 */
@Path("/systems_matrix")
public class SystemMatrixService {
    @GET    
    @Produces(MediaType.TEXT_HTML)
    public void showResourceMatrix(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        SystemDAO systemDAO = new SystemDAO();
        ProjectDAO projectDAO = new ProjectDAO();
        request.setAttribute("systems", systemDAO.getAllSystems());
        request.setAttribute("projects", projectDAO.getProjectResourceMatrix());
        request.setAttribute("init", "started");
        request.getRequestDispatcher("/systems_matrix.jsp").forward(request, response);
    }
    
    
    @GET
    @Path("/systemprojectmatrix")
    @Produces(MediaType.APPLICATION_JSON)
    public SystemProjectMatrix getSystemProjectMatrix(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        
        SystemDAO systemDAO = new SystemDAO();
        ProjectDAO projectDAO = new ProjectDAO();
        
        SystemProjectMatrix systemprojectmatrix = new SystemProjectMatrix();
        systemprojectmatrix.setSystems(systemDAO.getAllSystems());
        systemprojectmatrix.setProjects(projectDAO.getProjectResourceMatrix());
        
       return systemprojectmatrix;
    }
    
    @GET
    @Path("/systems")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<System> getSystems(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        SystemDAO systemDAO = new SystemDAO();
        ArrayList<System> systems =  systemDAO.getAllSystems();
       return systems;
    }
    
    @GET
    @Path("/projects")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Project> getProjects(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        ProjectDAO projectDAO = new ProjectDAO();
        ArrayList<Project> projects =  projectDAO.getProjectResourceMatrix();
       return projects;
    }
    
    @GET
    @Path("/systemattributes/{systemId}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<SystemAttributes> getSystemsAttributes(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("systemId") int systemId) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<SystemAttributes> SystemAttributesCollection = null;
        try{
            SystemDAO systemDAO = new SystemDAO();
            SystemAttributesCollection = systemDAO.getSystemsAttributes(systemId);
        }catch(Exception ex){
            Logger.getLogger(SystemMatrixService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return  SystemAttributesCollection;
    }
    
    @POST
    @Path("/save")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean saveSystemAttributes(SystemAttributes  systemAttributes,@Context HttpServletResponse response, @Context HttpServletRequest request ) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
           SystemDAO systemDAO = new SystemDAO();
           return systemDAO.updateSystemAttributes(systemAttributes);
        }catch(Exception e){
            return false;
        }
    }
    @POST
    @Path("/delete/{Id}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean deleteSystemAttributes(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("Id") int Id ) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
           SystemDAO systemDAO = new SystemDAO();
           return systemDAO.deleteSystemAttributes(Id);
        }catch(Exception e){
            return false;
        }
    }

    
}

    
