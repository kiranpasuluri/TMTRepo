/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import za.co.trudon.tmt.connectionpool.DBConnectionManager;
import za.co.trudon.tmt.dal.SkillDAO;
import za.co.trudon.tmt.dal.SystemDAO;
import za.co.trudon.tmt.dal.ProjectDAO;
import za.co.trudon.tmt.data.type.response.Skill;
import za.co.trudon.tmt.data.type.response.System;
import za.co.trudon.tmt.data.type.response.Project;
/**
 *
 * @author MangenaS
 */
@Path("/admin")
public class AdminService {
    
    private SkillDAO skillDAO;
    private SystemDAO systemDAO;
    private ProjectDAO projectDAO;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/projects")
    public ArrayList<Project> getProjects(){
        ArrayList<Project> projects=null;       
        try{
            projectDAO = new ProjectDAO();
            projects = projectDAO.getAllProjects(false);
        }catch(Exception ex){
            Logger.getLogger(AdminService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return projects;
    }
}
