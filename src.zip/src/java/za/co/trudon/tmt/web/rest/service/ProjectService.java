/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.BirdsDao;
import za.co.trudon.tmt.dal.ProjectDAO;
import za.co.trudon.tmt.dal.ResourceDAO;
import za.co.trudon.tmt.dal.TaskDAO;
import za.co.trudon.tmt.data.type.response.CapUser;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.ProjectPillar;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.ResourceProjectMatrix;
import za.co.trudon.tmt.data.type.response.Role;
import za.co.trudon.tmt.data.type.response.Skill;
import za.co.trudon.tmt.data.type.response.UserSuggestionResponseWrapper;
import za.co.trudon.tmt.enums.PriorityEnum;
import za.co.trudon.tmt.enums.ServerityEnum;
import za.co.trudon.tmt.enums.StatusEnum;


/**
 *
 * @author ramekosit
 */
@Path("/projects")
public class ProjectService {
    
    private static final org.apache.log4j.Logger LOGGER = org.apache.log4j.Logger.getLogger(ProjectService.class);
    
    @GET    
    @Produces(MediaType.TEXT_HTML)
    public void showProjects(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        ArrayList<Project> projects=null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            projects = projectDAO.getAllProjects(true);
        }catch(Exception ex){
//            Logger.getLogger(AdminService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
            LOGGER.error("Unable to get connection. Error: ", ex);
        }
        request.setAttribute("projects",projects);
        request.getRequestDispatcher("/projects.jsp").forward(request, response);
    }
    
    @POST
    @Path("/search")
    @Produces(MediaType.APPLICATION_JSON)
    public UserSuggestionResponseWrapper getUserAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            BirdsDao birdsDao = new BirdsDao();
            return birdsDao.getUserAutoComplete(query,"");
        }catch(Exception e){
             LOGGER.error("Error: ", e);
            return null;
        }
    }
    
    @POST
    @Path("/search_manager")
    @Produces(MediaType.APPLICATION_JSON)
    public UserSuggestionResponseWrapper getManagerAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            BirdsDao birdsDao = new BirdsDao();
            return birdsDao.getUserAutoComplete(query,"manager");
        }catch(Exception e){
             LOGGER.error("Error: ", e);
            return null;
        }
    }
    
    @POST
    @Path("/search_owner")
    @Produces(MediaType.APPLICATION_JSON)
    public UserSuggestionResponseWrapper getOwnerAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            BirdsDao birdsDao = new BirdsDao();
            return birdsDao.getUserAutoComplete(query,"owner");
        }catch(Exception e){
             LOGGER.error("Error: ", e);
            return null;
        }
    }
    
    @POST
    @Path("/search_resource")
    @Produces(MediaType.APPLICATION_JSON)
    public UserSuggestionResponseWrapper getResourceAutocomplete(@Context HttpServletResponse response, @Context HttpServletRequest request,@FormParam("query") String query) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            BirdsDao birdsDao = new BirdsDao();
            return birdsDao.getUserAutoComplete(query,"resource");
        }catch(Exception e){
             LOGGER.error("Error: ", e);
            return null;
        }
    }
    
    @POST
    @Path("/save")
    @Produces(MediaType.APPLICATION_JSON)
    public Project saveProject(Project project, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            BirdsDao birdsDao = new BirdsDao();
            return birdsDao.saveProject(project);
        }catch(Exception e){
             LOGGER.error("Error: ", e);
            return null;
        }
    }
    
    @POST
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
    public Project updateProject(Project project, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            BirdsDao birdsDao = new BirdsDao();
            return birdsDao.updateProject(project);
        }catch(Exception e){
             LOGGER.error("Error: ", e);
            return null;
        }
    }
    
    @GET
     @Path("/searchprojects/{name}/{projectPriority}/{status}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Project> searchProjects(@Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("name") String name,@PathParam("projectPriority") String projectPriority,@PathParam("status") String status) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Project> projects = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            projects = projectDAO.searchProjects(name, projectPriority,status);
        }catch(Exception ex){
//            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
             LOGGER.error("Unable to get connection. Error: ", ex);
        }
        return  projects;
    }
    
    @POST
    @Path("/activate/{projectId}")
    @Produces(MediaType.APPLICATION_JSON)
     public boolean activateProject(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("projectId") int projectId) throws ServletException,IOException,TrudoException_Exception,Exception {
         boolean Result;
         try{
            ProjectDAO projectDAO = new ProjectDAO();
          Result =  projectDAO.activateProject(projectId);
        }catch(Exception ex){
            Result = false;
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return Result;
     }
    
    @POST
    @Path("/deactivate/{projectId}")
    @Produces(MediaType.APPLICATION_JSON)
     public boolean deactivateProject(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("projectId") int projectId) throws ServletException,IOException,TrudoException_Exception,Exception {
         boolean Result;
         try{
            ProjectDAO projectDAO = new ProjectDAO();
          Result =  projectDAO.deactivateProject(projectId);
        }catch(Exception ex){
            Result = false;
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return Result;
     }
     
    @GET
    @Path("/id/{projectId}")
    @Produces(MediaType.TEXT_HTML)
    public void getProject(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("projectId") int projectId) throws ServletException,IOException,TrudoException_Exception,Exception {
        Project project = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            project = projectDAO.getProject(projectId);
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        
        
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("yyy-MM-dd'T'HH:mm:ss.SSS'Z'");//ISO8601 UTC
        Gson gson = gsonBuilder.create();

        String jsProject = gson.toJson(project);
        
        request.setAttribute("jsProject", jsProject);
        request.setAttribute("project",project);
        request.setAttribute("serverityValues", gson.toJson(ServerityEnum.values()));
        request.setAttribute("priorityValues", gson.toJson(PriorityEnum.values()));
        request.setAttribute("taskStatuses", gson.toJson(StatusEnum.values()));
        request.getRequestDispatcher("/project_details.jsp").forward(request, response);
    }
    
    @GET
    @Path("/projectparents")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Project> getProjectParents(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Project> projects = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO(); 
            projects = projectDAO.getProjectParents();
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return  projects;
    }
    
    @GET
    @Path("/treeviewprojects")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Project> getTreeViewProjects(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Project> projects = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            projects = projectDAO.getTreeViewProjects(true);
            
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return  projects;
    }
    @GET
    @Path("/treeviewprojectchildren/{projectId}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Project> getTreeViewProjectChildren(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("projectId") int projectId) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Project> projects = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            projects = projectDAO.getTreeViewProjectChildren(projectId);
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return  projects;
    }
    
    @GET
    @Path("/singleproject/{projectId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Project getSingleProject(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("projectId") int projectId) throws ServletException,IOException,TrudoException_Exception,Exception {
        Project project = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            project = projectDAO.getProject(projectId);
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return  project;
    }
  
    @POST
    @Path("/id/{projectId}/resources")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Resource> getProjectResources(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("projectId") int projectId) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Resource> projectResources = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            projectResources = projectDAO.getProjectResources(projectId);
        }catch(Exception ex){
            LOGGER.error("Unable to get Project Resources. Error: ", ex);
        }
        
        return projectResources;
    }
    
    @POST
    @Path("/pillars")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<ProjectPillar> getProjectPillars(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<ProjectPillar> projectPillars = null;
        try{
            ProjectDAO projectDAO = new ProjectDAO();
            projectPillars = projectDAO.getProjectPillars();
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get Project Resources. Error: "+ex.getMessage());
        }
        return projectPillars;
    }
    
    @POST
    @Path("/resources")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<za.co.trudon.tmt.data.type.response.Resource> getAllResources(List<Skill> skills, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.getAllResources(skills);
        }catch(Exception e){
            LOGGER.error("resource error: ", e);
            return null;
        }
    }
    
    @POST
    @Path("/systems")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<za.co.trudon.tmt.data.type.response.System> getAllSystems(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.getAllSystems();
        }catch(Exception e){
            return null;
        }
    }
    
    @POST
    @Path("/add/system/{projectId}/{systemId}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean addSystemToProject(@PathParam("projectId") int projectId, @PathParam("systemId") int systemId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.addSystemToProject(projectId,systemId);
        }catch(Exception e){
            return false;
        }
    }
    
    @POST
    @Path("/add/resource/{projectId}/{resourceId}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean addResourceToProject(@PathParam("projectId") int projectId, @PathParam("resourceId") String resourceId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.addResourceToProject(projectId,resourceId);
        }catch(Exception e){
            return false;
        }
    }
    
    @POST
    @Path("/add/task")
    @Produces(MediaType.APPLICATION_JSON)
    public void addResourceToProject(ProjectTask projectTask, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            TaskDAO taskDAO = new TaskDAO();
            taskDAO.addTask(projectTask);
        }catch(Exception e){
            LOGGER.error("Couldn't add task",e);
        }
    }
    
    @POST
    @Path("/remove/{projectId}/{taskId}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean removeTaskFromProject(@Context HttpServletResponse response, @Context HttpServletRequest request, @PathParam("projectId") int projectId, @PathParam("taskId") int taskId) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.removeTaskFromProject(projectId,taskId);
        }catch(Exception e){
            return false;
        }
    }
    
    @POST
    @Path("/remove/resource/{projectId}/{resourceId}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean removeResourceFromProject(@PathParam("projectId") int projectId, @PathParam("resourceId") String resourceId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.removeResourceFromProject(projectId,resourceId);
        }catch(Exception e){
            return false;
        }
    }
    
    @POST
    @Path("/remove/system/{projectId}/{systemId}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean removeSystemFromProject(@PathParam("projectId") int projectId, @PathParam("systemId") int systemId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.removeSystemFromProject(projectId,systemId);
        }catch(Exception e){
            return false;
        }
    }
    
    
    @POST
    @Path("/id/{projectId}/resourcesystems")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Resource> getProjectResourceSystem(@PathParam("projectId") int projectId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.getProjectResourceSystem(projectId);
        }catch(Exception e){
            return null;
        }
    }
    
    @POST
    @Path("/id/{projectId}/resource/{resourceId}/system/{systemId}/insert")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean insertProjectResourceSystem(@PathParam("projectId") int projectId,@PathParam("resourceId") String resourceId,@PathParam("systemId") int systemId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.insertProjectResourceSystem(projectId,resourceId,systemId);
        }catch(Exception e){
            return false;
        }
    }
    
    @POST
    @Path("/id/{projectId}/resource/{resourceId}/system/{systemId}/update")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean updateProjectResourceSystem(@PathParam("projectId") int projectId,@PathParam("resourceId") String resourceId,@PathParam("systemId") int systemId, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            ProjectDAO projectDao = new ProjectDAO();
            return projectDao.updateProjectResourceSystem(projectId,resourceId,systemId);
        }catch(Exception e){
            return false;
        }
    }
    
     @GET
    @Path("/resourcematrix")
    @Produces(MediaType.APPLICATION_JSON)
    public ResourceProjectMatrix getMatrix(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        ProjectDAO projectDAO = new ProjectDAO();
        ResourceDAO resourceDAO = new ResourceDAO();
        ResourceProjectMatrix resourceProjectMatrix = new ResourceProjectMatrix();
        
        resourceProjectMatrix.setProjects(projectDAO.getProjectSystemMatrix());
        resourceProjectMatrix.setResources(resourceDAO.getResourceMatrix());
        
        return resourceProjectMatrix;
    } 
    
    @GET
    @Path("/projectmatrix")
    @Produces(MediaType.APPLICATION_JSON)
    public ResourceProjectMatrix getResourceProjects(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        ProjectDAO projectDAO = new ProjectDAO();
        ResourceProjectMatrix resourceProjectMatrix = new ResourceProjectMatrix();
        resourceProjectMatrix.setProjects(projectDAO.getAllProjects(true));
        resourceProjectMatrix.setResources(projectDAO.getResourceMatrix());
        resourceProjectMatrix.setSystems(projectDAO.getAllSystems());
        return resourceProjectMatrix;
    } 
    
    @GET
    @Path("/resources/{projectId}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Resource> getProjectResource(@PathParam("projectId") int projectId,@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        ResourceDAO resourceDAO = new ResourceDAO();
        ArrayList<Resource> Resources = new ArrayList<Resource>();
        Resources =  resourceDAO.getProjectResource(projectId);
        return Resources;
    }
    
    @GET
    @Path("/projectroles")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Role> getProjectRoles(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        ArrayList<Role> roles = null;
        try{
            ResourceDAO resourceDAO = new ResourceDAO();
            roles = resourceDAO.getAllProjectRoles();
        }catch(Exception ex){
            Logger.getLogger(ProjectService.class.getName()).log(Level.SEVERE, "Unable to get connection. Error: "+ex.getMessage());
        }
        return  roles;
    }

    @GET
    @Path("/task/{taskId}")
    @Produces(MediaType.TEXT_HTML)
    public void getProjectTask(@Context HttpServletResponse response, @Context HttpServletRequest request,@PathParam("taskId") int taskId) throws ServletException,IOException,TrudoException_Exception,Exception {
        ProjectTask task = null;
        Project project = null;
        try{
            TaskDAO taskDAO = new TaskDAO();
            task = taskDAO.getProjectTask(taskId);
            
            ProjectDAO projectDAO = new ProjectDAO();
            project = projectDAO.getProject(task.getProjectId());
        }catch(Exception ex){
            LOGGER.error("Unable to get connection. Error: ", ex);
        }

        Gson gson = new Gson();

        String jsonTask = gson.toJson(task);
        String jsonProject = gson.toJson(project);
        
        request.setAttribute("projectTask", jsonTask);
        request.setAttribute("resourceProject", jsonProject);
        request.setAttribute("taskStatuses", gson.toJson(StatusEnum.values()));
        request.setAttribute("severities", gson.toJson(ServerityEnum.values()));
        request.setAttribute("priorities", gson.toJson(PriorityEnum.values()));
        request.getRequestDispatcher("/project_task.jsp").forward(request, response);
    }
    
    @POST
    @Path("/task/update")
    @Produces(MediaType.APPLICATION_JSON)
    public void updateTask(ProjectTask task, @Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        try
        {
            TaskDAO taskDAO = new TaskDAO();
            taskDAO.updateTask(task);
//            getProjectTask(response, request, task.getId());
        }catch(Exception e){
             LOGGER.error("Error: ", e);
        }
    }

    @GET
    @Path("/project_managers")
    @Produces(MediaType.APPLICATION_JSON)
    public List<CapUser> getProjectManagers(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        List<CapUser> users = null;
        try{
            BirdsDao birdsDao = new BirdsDao();
            users = birdsDao.getProjectManagers();
        }catch(Exception ex){
             LOGGER.error("Unable to get connection. Error: ", ex);
        }
        return  users;
    }
    
    @GET
    @Path("/business_owners")
    @Produces(MediaType.APPLICATION_JSON)
    public List<CapUser> getBusinessOwners(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception,Exception {
        List<CapUser> users = null;
        try{
            BirdsDao birdsDao = new BirdsDao();
            users = birdsDao.getBusinessOwners();
        }catch(Exception ex){
             LOGGER.error("Unable to get connection. Error: ", ex);
        }
        return  users;
    }
}
