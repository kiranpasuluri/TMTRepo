/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.web.rest.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;
import za.co.trudon.tmt.dal.ProjectDAO;
import za.co.trudon.tmt.dal.ResourceDAO;
import za.co.trudon.tmt.dal.SystemDAO;
import za.co.trudon.tmt.data.type.response.System;
import za.co.trudon.tmt.data.type.response.ResourceProjectMatrix;

/**
 * @author ramekosit
 */
@Path("/resources_matrix")
public class ResourceMatrixService {
    
    @GET    
    @Produces(MediaType.TEXT_HTML)
    public void showResourceMatrix(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        ProjectDAO projectDAO = new ProjectDAO();
        ResourceDAO resourceDAO = new ResourceDAO();
        request.setAttribute("projects", projectDAO.getProjectSystemMatrix());
        request.setAttribute("resources", resourceDAO.getResourceMatrix());
        request.getRequestDispatcher("/resources_matrix.jsp").forward(request, response);
    } 
    
    @GET
    @Path("/resourcematrix")
    @Produces(MediaType.APPLICATION_JSON)
    public ResourceProjectMatrix getResourceMatrix(@Context HttpServletResponse response, @Context HttpServletRequest request) throws ServletException,IOException,TrudoException_Exception{
        
        ResourceDAO resourceDAO = new ResourceDAO();
        SystemDAO systemDAO = new SystemDAO();
        ResourceProjectMatrix resourceProjectMatrix = new ResourceProjectMatrix();
        
        resourceProjectMatrix.setResources(resourceDAO.getResourceSystemMatrix());
        resourceProjectMatrix.setSystems(systemDAO.getSystemsProjectsMatrix());
                
        return resourceProjectMatrix;
    } 
    
}
