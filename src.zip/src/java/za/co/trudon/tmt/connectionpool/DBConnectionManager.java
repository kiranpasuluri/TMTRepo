/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.connectionpool;

/**
 *
 * @author KarsasN
 */
import java.sql.Connection;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBConnectionManager {

     public static Connection getConnection(String name) throws Exception {
        try {
            return getConn("java:/".concat(name));
        } catch (Exception e) {
            return null;
        }
    }

    private static Connection getConn(String name) throws Exception {
        Context initContext = new InitialContext();
        DataSource ds = (DataSource) initContext.lookup(name);
        return ds.getConnection();
    }
}
