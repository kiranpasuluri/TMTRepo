/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.enums;

/**
 *
 * @author MaremaM
 */
public enum PriorityEnum {
    LOW(1),
    MEDIUM(2),
    HIGH(3);
    
    private int priority;
    
    private PriorityEnum(int priority){
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
