/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.enums;

/**
 *
 * @author MaremaM
 */
public enum StatusEnum {
    NEW(0),
    IN_PROGRESS(1),
    COMPLETED(2);

    private int status;
    
    private StatusEnum(int status) {
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
    
}
