/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.enums;

/**
 *
 * @author MaremaM
 */
public enum ServerityEnum {
    
    MAJOR(3),
    MEDIUM(2),
    SMALL(1),
    NOT_APPLICABLE(0);
    
    private int serverity;

    private ServerityEnum(int serverity) {
        this.serverity = serverity;
    }

    public int getServerity() {
        return serverity;
    }

    public void setServerity(int serverity) {
        this.serverity = serverity;
    }
    
}
