/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.webservicemanager;

import java.io.Serializable;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.xml.ws.WebServiceRef;
import za.co.trudon.comm.webservice.CommsframeworkWebService;
import za.co.trudon.comm.webservice.CommsframeworkWebServiceSoap;

/**
 *
 * @author MaremaM
 */
@Stateless(name = "communicationServiceManager")
public class CommunicationServiceManager implements Serializable {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/trudontlkypdev_8050/CommsframeworkWebService.asmx.wsdl")
    private CommsframeworkWebService service;
    
    private static final Logger LOGGER = Logger.getLogger(CommunicationServiceManager.class.getName());

    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public String sendEMAIL(String sourceKey, String sourceUser, String sourceName, String recipient, String textData, String template, String subject, 
            String fromAddress, String fromDisplayName, String replyToAddress, String replyToDisplayName, String attachments, String embeddedAttachments, 
            String cc, String bcc) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        CommsframeworkWebServiceSoap port = service.getCommsframeworkWebServiceSoap();
        
        return port.sendEMAIL(sourceKey, sourceUser, sourceName, recipient, textData, template, subject, fromAddress, fromDisplayName, replyToAddress, 
                replyToDisplayName, attachments, embeddedAttachments, cc, bcc);
    }
}
