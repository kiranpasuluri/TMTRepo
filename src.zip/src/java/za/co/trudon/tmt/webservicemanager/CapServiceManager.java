package za.co.trudon.tmt.webservicemanager;

import java.io.Serializable;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import za.co.trudon.cap.webservice.BusinessLocationFix;
import za.co.trudon.cap.webservice.CapService_Service;
import za.co.trudon.cap.webservice.SubscriberEish;
import za.co.trudon.cap.webservice.SubscriberEishes;
import za.co.trudon.cap.webservice.TrudonDepartment;
import za.co.trudon.cap.webservice.TrudonEmployee;
import za.co.trudon.tmt.properties.AutoRefreshPropertiesReader;
import za.co.trudon.salesworx.webservice.TrudoException_Exception;

@Stateless(name = "capServiceManager")
public class CapServiceManager implements Serializable {

  private static final Logger log = Logger.getLogger(CapServiceManager.class.getName());
  private CapService_Service capService;
  private List<SubscriberEishes> subscriberQueries;
  private long subscrId;

  public void load(int subscrId) throws TrudoException_Exception {
    if (subscrId != this.subscrId) {
      subscriberQueries = getSubscrInfo(subscrId);
      this.subscrId = subscrId;
    }
  }
  
  public List<SubscriberEish> getSubEishes(int subscrId,int eishReasonId) throws TrudoException_Exception {
    checkService();
    return capService.getCapServicePort().getSubscriberQueriesBySubId(subscrId,eishReasonId);
  }

  private List<SubscriberEishes> getSubscrInfo(int subscrId) throws TrudoException_Exception {
    checkService();
    return capService.getCapServicePort().getSubscriberGroupedQueriesBySubId(subscrId);
  }
  
  public BusinessLocationFix createEish(BusinessLocationFix eishObj) throws TrudoException_Exception {
    checkService();
    return capService.getCapServicePort().createEish(eishObj);
  }

  public List<TrudonEmployee> getAllTrudonEmployeesByDepartment(String department) throws TrudoException_Exception {
      checkService();
      return capService.getCapServicePort().getTrudonEmployees(department);
  }
  
  public List<TrudonDepartment> getAllTrudonDepartments() throws TrudoException_Exception {
      checkService();
      return capService.getCapServicePort().getTrudonDepartments();
  }
  
  private void checkService() {
    if (capService == null) {
      try {
        capService = new CapService_Service();
      } catch (Exception e) {
          e.printStackTrace();
        log.log(Level.SEVERE, "Failed to connect to CAP Service", e);
      }
    }
  }
  
  public List<SubscriberEishes> getSubscriberQueries() {
    return subscriberQueries;
  }
}
