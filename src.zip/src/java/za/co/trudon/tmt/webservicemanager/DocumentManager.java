package za.co.trudon.tmt.webservicemanager;

import java.io.Serializable;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.co.trudon.tmt.properties.AutoRefreshPropertiesReader;
import za.co.trudon.salesworx.documents.DocuShare_Service;
import za.co.trudon.salesworx.documents.Exception_Exception;



public class DocumentManager implements Serializable {

  private static final Logger log = Logger.getLogger(DocumentManager.class.getName());
  private DocuShare_Service service;
  private List<za.co.trudon.salesworx.documents.VoiceRecording> recordings;
  private List<za.co.trudon.salesworx.documents.StoredDocument> documents;
  private long subscrId;

  public void load(long subscrId) {
    if (subscrId != this.subscrId) {
      try {
        documents = getDocuShareDocuments(subscrId);
      } catch (Exception_Exception ex) {
        Logger.getLogger(DocumentManager.class.getName()).log(Level.SEVERE, null, ex);
      }
      this.subscrId = subscrId;
    }
  }
  
  public void loadVoice(long subscrId) {
    if (subscrId != this.subscrId) {
      try {
        recordings = getDocuShareVoiceRecordings(subscrId);
      } catch (Exception_Exception ex) {
        Logger.getLogger(DocumentManager.class.getName()).log(Level.SEVERE, null, ex);
      }
      this.subscrId = subscrId;
    }
  }

  private List<za.co.trudon.salesworx.documents.StoredDocument> getDocuShareDocuments(long subscrId) throws Exception_Exception {
    checkService();
    za.co.trudon.salesworx.documents.DocuShare port = service.getDocuSharePort();
    return port.getDocuments(subscrId);
  }

  private List<za.co.trudon.salesworx.documents.VoiceRecording> getDocuShareVoiceRecordings(long subscrId) throws Exception_Exception {
    checkService();
    za.co.trudon.salesworx.documents.DocuShare port = service.getDocuSharePort();
    return port.getVoiceRecordings(subscrId);
  }

  private void checkService() {
    if (service == null) {
      try {
        service = new DocuShare_Service(new URL(AutoRefreshPropertiesReader.getInstance().getString("docs.wsdl.location")));
      } catch (Exception e) {
        log.log(Level.SEVERE, "Failed to connect to docushare service", e);
      }
    }
  }

  public List<za.co.trudon.salesworx.documents.VoiceRecording> getRecordings() {
    return recordings;
  }

  public void setRecordings(List<za.co.trudon.salesworx.documents.VoiceRecording> recordings) {
    this.recordings = recordings;
  }

  public List<za.co.trudon.salesworx.documents.StoredDocument> getDocuments() {
    return documents;
  }

  public void setDocuments(List<za.co.trudon.salesworx.documents.StoredDocument> documents) {
    this.documents = documents;
  }

}
