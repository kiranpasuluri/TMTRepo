/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MangenaS
 */
public class System {
    
    private int id;
    private String name;
    private String description;
    private List<Skill> skills;
    private ArrayList<String> userIds;
    ArrayList<Project> projects;
    private SystemAttributes attributes;
    
    int projectCount;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    public ArrayList<String> getResources() {
        return userIds;
    }

    public void setResources(ArrayList<String> userIds) {
        this.userIds = userIds;
    }

    public int getProjectCount() {
        return projectCount;
    }

    public void setProjectCount(int projectCount) {
        this.projectCount = projectCount;
    }
    
    public void setProjects(ArrayList<Project> projects) {
        this.projects = projects;
    }

    public ArrayList<Project> getProjects() {
        return projects;
    }

    public SystemAttributes getAttributes() {
        return attributes;
    }

    public void setAttributes(SystemAttributes attributes) {
        this.attributes = attributes;
    }
    
    
}
