/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;

/**
 *
 * @author MangenaS
 */
public class Project {
    
    private int id;
    private String name;
    private String description;
    private String startDate;
    private int status;
    private int priority;
    private String endDate;
    private String createdBy;
    private String createdDate;
    private String expectedDate;
    private Double revenueImpact;
    private Integer usageImpact;
    private Resource projectOwner;
    private Resource projectManager;
    private ArrayList<System> systems;
    private ArrayList<Resource> resources;
    private ArrayList<ProjectTask> tasks;
    private ArrayList<Attachment> attachments;
    private String updatedBy;
    private String updatedDate;
    private int project_pillar_id;
    private int parent;
    private int deactivate;
    private Double opex;
    private Double capex;
    private int children;
    private Resource businessOwner;
    
    public Project(){
        tasks = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getExpectedDate() {
        return expectedDate;
    }

    public void setExpectedDate(String expectedDate) {
        this.expectedDate = expectedDate;
    }

    public Double getRevenueImpact() {
        return revenueImpact;
    }

    public Integer getUsageImpact() {
        return usageImpact;
    }

    public void setUsageImpact(Integer usageImpact) {
        this.usageImpact = usageImpact;
    }
    public void setRevenueImpact(Double revenueImpact) {
        this.revenueImpact = revenueImpact;
    }

    public Resource getProjectOwner() {
        return projectOwner;
    }

    public void setProjectOwner(Resource projectOwner) {
        this.projectOwner = projectOwner;
    }

    public Resource getProjectManager() {
        return projectManager;
    }

    public void setProjectManager(Resource projectManager) {
        this.projectManager = projectManager;
    }

    public ArrayList<System> getSystems() {
        return systems;
    }

    public void setSystems(ArrayList<System> systems) {
        this.systems = systems;
    }

    public ArrayList<Resource> getResources() {
        return resources;
    }

    public void setResources(ArrayList<Resource> resources) {
        this.resources = resources;
    }

    public ArrayList<ProjectTask> getTasks() {
        return tasks;
    }

    public void setTasks(ArrayList<ProjectTask> tasks) {
        this.tasks = tasks;
    }

    /**
     * @return the priority
     */
    public int getPriority() {
        return priority;
    }

    /**
     * @param priority the priority to set
     */
    public void setPriority(int priority) {
        this.priority = priority;
    }

    /**
     * @return the attachments
     */
    public ArrayList<Attachment> getAttachments() {
        return attachments;
    }

    /**
     * @param attachments the attachments to set
     */
    public void setAttachments(ArrayList<Attachment> attachments) {
        this.attachments = attachments;
    }

    /**
     * @return the updatedBy
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * @param updatedBy the updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the updatedDate
     */
    public String getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate the updatedDate to set
     */
    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }
    
    public int getProject_pillar_id(){
        return project_pillar_id;
    }
    
    public  void setProject_pillar_id(int project_pillar_id){
        this.project_pillar_id = project_pillar_id;
    }
    
    public int getParent(){
        return parent;
    }
    
    public void setParent(int parent){
        this.parent = parent;
    }
    
    public int getDeactivate(){
        return deactivate;
    }
    public void setDeactivate(int deactivate){
        this.deactivate = deactivate;
    }
    
     public void setOpex(double opex) {
        this.opex = opex;
    }

    public Double getOpex() {
        return opex;
    }
    
    public void setCapex(double capex) {
        this.capex = capex;
    }

    public Double getCapex() {
        return capex;
    }

    public void setChildren(int children) {
        this.children = children;
    }

    public int getChildren() {
        return children;
    }

    public Resource getBusinessOwner() {
        return businessOwner;
    }

    public void setBusinessOwner(Resource businessOwner) {
        this.businessOwner = businessOwner;
    }

    @Override
    public String toString() {
        return "project name: " + getName() + "\nResources: " + getResources(); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
