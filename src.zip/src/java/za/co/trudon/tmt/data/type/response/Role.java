/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

/**
 *
 * @author MangenaS
 */
public class Role {
    private int id;
    private String role;

    public Role(int id,String role){
        this.id = id;
        this.role = role;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRole() {
        if(role==null){
            role = "Resource";
        }
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
