/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MaremaM
 */
public class TimesheetProject {
    
    private String name;
    
    private long financialYearHours;
    
    private List<TimesheetResource> resources;
    
    public TimesheetProject() {
        resources = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getFinancialYearHours() {
        return financialYearHours;
    }

    public void setFinancialYearHours(long financialYearHours) {
        this.financialYearHours = financialYearHours;
    }
    
    public List<TimesheetResource> getResources() {
        return resources;
    }
    
    public void addResource(TimesheetResource resource) {
        resources.add(resource);
    }

    public void setResources(List<TimesheetResource> resources) {
        this.resources = resources;
    } 
    
}
