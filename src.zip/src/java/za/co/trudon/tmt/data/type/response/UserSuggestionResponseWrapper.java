/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.List;

/**
 *
 * @author ramekosit
 */
public class UserSuggestionResponseWrapper {
    
    private List<CapUser> suggestions;

    /**
     * @return the suggestions
     */
    public List<CapUser> getSuggestions() {
        return suggestions;
    }

    /**
     * @param suggestions the suggestions to set
     */
    public void setSuggestions(List<CapUser> suggestions) {
        this.suggestions = suggestions;
    }
    
}
