/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;

/**
 *
 * @author UdohK
 */
public class ResourceProjectMatrix {
    
     ArrayList<Resource> resources;
     ArrayList<Project> projects;
     ArrayList<System> systems;

    public ArrayList<System> getSystems() {
        return systems;
    }

    public void setSystems(ArrayList<System> systems) {
        this.systems = systems;
    }

    public void setProjects(ArrayList<Project> projects) {
        this.projects = projects;
    }

    public ArrayList<Project> getProjects() {
        return projects;
    }
     
    public void setResources(ArrayList<Resource> resources) {
        this.resources = resources;
    }

    public ArrayList<Resource> getResources() {
        return resources;
    }
     
}
