/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.request;

/**
 *
 * @author ramekosit
 */
public class ProjectSystem {
    private int projectId;
    private int systemId;
    
    public void ProjectSystem(int projectId,int systemId){
        this.setProjectId(projectId);
        this.setSystemId(systemId);
    }

    /**
     * @return the projectId
     */
    public int getProjectId() {
        return projectId;
    }

    /**
     * @param projectId the projectId to set
     */
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    /**
     * @return the systemId
     */
    public int getSystemId() {
        return systemId;
    }

    /**
     * @param systemId the systemId to set
     */
    public void setSystemId(int systemId) {
        this.systemId = systemId;
    }
}
