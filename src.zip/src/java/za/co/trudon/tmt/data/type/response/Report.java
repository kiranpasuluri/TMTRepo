/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author maremam
 */
public class Report {
    List<MainProject> mainProjects;
    
    public Report(){
        mainProjects = new ArrayList<>();
    }

    public List<MainProject> getMainProjects() {
        return mainProjects;
    }

    public void setMainProjects(List<MainProject> mainProjects) {
        this.mainProjects = mainProjects;
    }
    
}
