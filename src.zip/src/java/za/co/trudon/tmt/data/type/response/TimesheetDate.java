/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.List;

/**
 *
 * @author Maremam
 */
public class TimesheetDate {

    private int weekNumber;
    
    private boolean firstDaySunday;
    
    private List<WeeklyTimesheet> weeklyTimesheets;
    
    public TimesheetDate() {
        
    }

    public int getWeekNumber() {
        return weekNumber;
    }

    public void setWeekNumber(int weekNumber) {
        this.weekNumber = weekNumber;
    }

    public boolean isFirstDaySunday() {
        return firstDaySunday;
    }

    public void setFirstDaySunday(boolean firstDaySunday) {
        this.firstDaySunday = firstDaySunday;
    }

    public List<WeeklyTimesheet> getWeeklyTimesheets() {
        return weeklyTimesheets;
    }

    public void setWeeklyTimesheets(List<WeeklyTimesheet> weeklyTimesheets) {
        this.weeklyTimesheets = weeklyTimesheets;
    }

    @Override
    public String toString() {
        return "Week " + String.valueOf(getWeekNumber()) + ":\n" + getWeeklyTimesheets();
    }
    
    
}
