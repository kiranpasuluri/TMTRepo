/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author ramekosit
 */
public class ProjectTask {
    private int id;
    private int projectId;
    private int parentId;
    private String name;
    private double estimateDays;
    private double estimateHours;
    private double timeSpent;
    private String description;
    private Resource updateBy;
    private Date updatedDate;
    private String createdby;
    private Date createdDate;
    private Resource assignedTo;
    private int status;
    private int priority;
    private int severity;
    private List<TaskComment> comments;
    private List<DailyTaskUpdate> dailyUpdates;

    public ProjectTask() {
        comments = new ArrayList<>();
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getEstimateDays() {
        return estimateDays;
    }

    public void setEstimateDays(double estimateDays) {
        this.estimateDays = estimateDays;
    }

    public double getEstimateHours() {
        return estimateHours;
    }

    public void setEstimateHours(double estimateHours) {
        this.estimateHours = estimateHours;
    }

    public double getTimeSpent() {
        return timeSpent;
    }

    public void setTimeSpent(double timeSpent) {
        this.timeSpent = timeSpent;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Resource getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Resource updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Resource getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(Resource assignedTo) {
        this.assignedTo = assignedTo;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getSeverity() {
        return severity;
    }

    public void setSeverity(int severity) {
        this.severity = severity;
    }

    public List<TaskComment> getComments() {
        return comments;
    }

    public void setComments(List<TaskComment> comments) {
        this.comments = comments;
    }

    public List<DailyTaskUpdate> getDailyUpdates() {
        return dailyUpdates;
    }

    public void setDailyUpdates(List<DailyTaskUpdate> dailyUpdates) {
        this.dailyUpdates = dailyUpdates;
    }
 
}
