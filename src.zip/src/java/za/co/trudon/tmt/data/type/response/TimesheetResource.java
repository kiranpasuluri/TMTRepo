/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Maremam
 */
public class TimesheetResource {
    
    private String username;
    
    private String fullnames;
    
    private List<DailyTaskUpdate> updates;
    
    public TimesheetResource(){
        updates = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullnames() {
        return fullnames;
    }

    public void setFullnames(String fullnames) {
        this.fullnames = fullnames;
    }

    public List<DailyTaskUpdate> getUpdates() {
        return updates;
    }

    public void setUpdates(List<DailyTaskUpdate> updates) {
        this.updates = updates;
    }
    
    public void addUpdate(DailyTaskUpdate update){
        updates.add(update);
    }
}
