/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.List;
import za.co.trudon.salesworx.documents.StoredDocument;

/**
 *
 * @author ramekosit
 */
public class DocuShareDocs {
    private List<StoredDocument> documents = new ArrayList<StoredDocument>();
    private List<StoredDocument> email = new ArrayList<StoredDocument>();

    /**
     * @return the documents
     */
    public List<StoredDocument> getDocuments() {
        return documents;
    }

    /**
     * @param documents the documents to set
     */
    public void setDocuments(List<StoredDocument> documents) {
        this.documents = documents;
    }

    /**
     * @return the email
     */
    public List<StoredDocument> getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(List<StoredDocument> email) {
        this.email = email;
    }
}
