/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Maremam
 */
public class Timesheet {
    
    private List<TimesheetProject> projects;
    
    private List<TimesheetDate> dates;

    public Timesheet() {
        projects = new ArrayList<>();
    }

    public List<TimesheetProject> getProjects() {
        return projects;
    }

    public void setProjects(List<TimesheetProject> projects) {
        this.projects = projects;
    }

    public void addProject(TimesheetProject project) {
        projects.add(project);
    }
    
    public List<TimesheetDate> getDates() {
        return dates;
    }

    public void setDates(List<TimesheetDate> dates) {
        this.dates = dates;
    }

    @Override
    public String toString() {
        return "projects: " + getProjects();
    }
    
    
}
