/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

/**
 *
 * @author UdohK
 */
public class SystemAttributes {
    private int id;
    private int systemId;
    private String serverName;
    private String databaseName;
    private String databaseServerName;
    private String operatingSystem;
    private String hostingSystem;
    private String language;
    private String apiDocumentation;
    private String licenseRequired;
    private String thirdParty;
    private int frequency;
    private Double opex;
    private Double capex;

    public void setId(int id) {
        this.id = id;
    }

    public void setSystemId(int systemId) {
        this.systemId = systemId;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public void setDatabaseServerName(String databaseServerName) {
        this.databaseServerName = databaseServerName;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public void setHostingSystem(String hostingSystem) {
        this.hostingSystem = hostingSystem;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setApiDocumentation(String apiDocumentation) {
        this.apiDocumentation = apiDocumentation;
    }

    public void setLicenseRequired(String licenseRequired) {
        this.licenseRequired = licenseRequired;
    }

    public void setThirdParty(String thirdParty) {
        this.thirdParty = thirdParty;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public int getId() {
        return id;
    }

    public int getSystemId() {
        return systemId;
    }

    public String getServerName() {
        return serverName;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public String getDatabaseServerName() {
        return databaseServerName;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public String getHostingSystem() {
        return hostingSystem;
    }

    public String getLanguage() {
        return language;
    }

    public String getApiDocumentation() {
        return apiDocumentation;
    }

    public String getLicenseRequired() {
        return licenseRequired;
    }

    public String getThirdParty() {
        return thirdParty;
    }

    public int getFrequency() {
        return frequency;
    }
    
     public void setOpex(double opex) {
        this.opex = opex;
    }

    public Double getOpex() {
        return opex;
    }
    
    public void setCapex(double capex) {
        this.capex = capex;
    }

    public Double getCapex() {
        return capex;
    }
   
}


