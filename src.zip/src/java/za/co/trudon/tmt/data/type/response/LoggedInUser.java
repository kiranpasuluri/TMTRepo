/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import za.co.trudon.tmt.dal.User;

/**
 *
 * @author ramekosit
 */
public class LoggedInUser {
    private String fullName;
    private String firstName;
    private String lastName;
    private String department;
    private String telephoneNumber;
    private String mail;
    private String profilePic;
    private String userName;

    public void populateUserDetails(User userDetails) {

        firstName = userDetails.getFirstName();

        lastName = userDetails.getLastName();

        mail = userDetails.getMail();
        userName = userDetails.getUserName();

        telephoneNumber = userDetails.getTelephoneNumber();

        fullName = userDetails.getFullName();

        department = userDetails.getDepartment();

    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
   
}
