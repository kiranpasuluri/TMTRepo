/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

/**
 *
 * @author MangenaS
 */
public class ResultWrapper {
    private boolean result;
    private String message;

    public ResultWrapper(boolean result,String message){
        this.result = result;
        this.message = message;
    }
    
    public boolean getResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }   
}
