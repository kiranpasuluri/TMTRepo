/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

/**
 *
 * @author Maremam
 */
public class WeeklyTimesheet {
    private String date;
    
    private String day;
    
    public WeeklyTimesheet(){
        
    }
    
    
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    @Override
    public String toString() {
        return getDate() + " | " + getDay() + "\n";
    }
}
