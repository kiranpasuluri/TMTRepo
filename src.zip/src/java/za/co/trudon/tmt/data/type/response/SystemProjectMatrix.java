/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.response;

import java.util.ArrayList;

/**
 *
 * @author UdohK
 */
public class SystemProjectMatrix {
    
     ArrayList<System> systems;
     ArrayList<Project> projects;

    public void setProjects(ArrayList<Project> projects) {
        this.projects = projects;
    }

    public ArrayList<Project> getProjects() {
        return projects;
    }
     
    public void setSystems(ArrayList<System> systems) {
        this.systems = systems;
    }

    public ArrayList<System> getSystems() {
        return systems;
    }
     
     
    
}
