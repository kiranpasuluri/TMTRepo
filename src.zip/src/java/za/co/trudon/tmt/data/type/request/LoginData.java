/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.data.type.request;

import za.co.trudon.tmt.dal.User;
import za.co.trudon.tmt.data.type.response.Role;

/**
 *
 * @author ramekosit
 */
public class LoginData
{
    private String message;

    private String username;

    private User user;
    
    private Role role;

    private boolean success;

    public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    public String getUsername ()
    {
        return username;
    }

    public void setUsername (String username)
    {
        this.username = username;
    }

    public User getUser ()
    {
        return user;
    }

    public void setUser (User user)
    {
        this.user = user;
    }

    public boolean getSuccess ()
    {
        return success;
    }

    public void setSuccess (boolean success)
    {
        this.success = success;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [message = "+message+", username = "+username+", user = "+user+", success = "+success+"]";
    }
}