package za.co.trudon.tmt.properties;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;


public class AutoRefreshPropertiesReader {

  private PropertiesConfiguration propertiesConfiguration;
  private static final Logger log = Logger.getLogger(AutoRefreshPropertiesReader.class.getName());
  private static final int PROPERTIES_RELOAD_TIME_IN_MILLISECONDS = 10 * 1000; //10 seconds
  private static AutoRefreshPropertiesReader instance;

  static {
    instance = new AutoRefreshPropertiesReader();
    instance.loadProperties();
  }

  /**
   * Disallow construction from outside.
   */
  public AutoRefreshPropertiesReader() {
    loadProperties();
  }

  /**
   * Gets a property value from customerView.properties using propertyName as key.
   *
   * @param propertyName
   * @return propertyValue
   * @deprecated
   */
  public String getProperty(final String propertyName) {
    return propertiesConfiguration.getString(propertyName);
  }

  /**
   * Gets a property value from customerView.properties using propertyName as key.
   *
   * @param propertyName
   * @return propertyValue
   * @deprecated
   */
  public String getProperty(final String propertyName, final String defaultValue) {
    return propertiesConfiguration.getString(propertyName, defaultValue);
  }

  /**
   * Gets a String property value from customerView.properties using propertyName as
   * key.
   *
   * @param propertyName
   * @return propertyValue
   */
  public String getString(final String propertyName, final String defaultValue) {
    return propertiesConfiguration.getString(propertyName, defaultValue);
  }

  /**
   * Gets a property value from customerView.properties using propertyName as key.
   *
   * @param propertyName
   * @return propertyValue
   */
  public String getString(final String propertyName) {
    return propertiesConfiguration.getString(propertyName);
  }

  // set a property
  public void setString(String propertyName, String val) throws ConfigurationException {
    propertiesConfiguration.setProperty(propertyName, val);
    propertiesConfiguration.save();
  }

  /**
   * Gets a property value from customerView.properties using propertyName as key.
   *
   * @param propertyName
   * @return propertyValue
   */
  public Boolean getBoolean(final String propertyName) {
    return propertiesConfiguration.getBoolean(propertyName);
  }

  /**
   * Gets the singleton instance.
   *
   * @return the instance
   */
  public static AutoRefreshPropertiesReader getInstance() {
    return instance;
  }

  /**
   * Loads the customerView.properties file into memory with a reloading strategy.
   */
  private void loadProperties() {

    File infile = new File("C:/tdsconfig/tmt.properties");
    //File infile = new File("//tdsconfig/tmt.properties");
    
    try {
      FileChangedReloadingStrategy reloadingStrategy = new FileChangedReloadingStrategy();
      reloadingStrategy.setRefreshDelay(PROPERTIES_RELOAD_TIME_IN_MILLISECONDS);
      propertiesConfiguration = new PropertiesConfiguration(infile);
      propertiesConfiguration.setReloadingStrategy(reloadingStrategy);
    } catch (ConfigurationException e) {
      log.log(Level.SEVERE, "[loadProperties] Could not load tmt.properties ", e);
    }
  }
}
