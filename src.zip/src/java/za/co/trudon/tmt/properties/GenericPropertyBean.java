package za.co.trudon.tmt.properties;

/**
 * Convenience class to read properties that have been initialised by AutoRefreshVenioAppConfigPropertiesReader. This is used from jsp's using jsp:useBean
 *
 * @author Tebogo Ramekosi
 *
 */
public class GenericPropertyBean {

    char[] ourAlphabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

    @Deprecated
    public String getProperty(String property_name) {
        return AutoRefreshPropertiesReader.getInstance().getProperty(property_name);
    }

    @Deprecated
    public String getProperty(String property_name, String defaultvalue) {
        return AutoRefreshPropertiesReader.getInstance().getProperty(property_name, defaultvalue);
    }

    public String getString(String property_name, String defaultValue) {
        return AutoRefreshPropertiesReader.getInstance().getString(property_name, defaultValue);
    }

    public String getString(String property_name) {
        return AutoRefreshPropertiesReader.getInstance().getString(property_name);
    }

    public boolean getBoolean(String property_name) {
        return AutoRefreshPropertiesReader.getInstance().getBoolean(property_name);
    }

    public char getAlphaChar(int index) {
        return ourAlphabet[index];

        //this may throw array index out of bounds exception if returning more than 26 results per page
    }
}
