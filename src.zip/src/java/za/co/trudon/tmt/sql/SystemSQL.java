/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.sql;

/**
 *
 * @author MangenaS
 */
public enum SystemSQL {
    
    GetSystemById("select * from CH_SYSTEM where id=?"),
    GetSystemSkill("select sl.SKILL_ID,sl.SKILL_NAME from CH_SKILLS_LIST sl, ch_system_skill ss where ss.system_id=? and sl.skill_id=ss.skill_id"),
    GetProjectSystems("select s.ID,s.name,s.DESCRIPTION from ch_project_system ps,ch_system s where project_id=? and ps.system_id = s.id"),
    GetAllSystems("select a.id, a.name,a.DESCRIPTION, b.projectCount from ch_system a left join ( select system_id, count(1) as projectCount from ch_project_system group by system_id ) b on a.id = b.system_id"),
    GetUserSystems("select DISTINCT SYSTEM_ID from CH_PROJECT_USER_SYSTEM where LOWER(USER_ID)=? and system_id is not null"),
    GetSystemResourceMatrix("select a.SYSTEM_ID id,b.name ,a.USER_ID from CH_PROJECT_USER_SYSTEM a,ch_system b,CH_CAP_USER c where a.PROJECT_ID=? and b.ID=a.SYSTEM_ID and upper(c.USER_ID)=upper(a.USER_ID)"),
    GetAllSystemUnconditionally("select * from ch_system");
    
    private final String query;
    
    SystemSQL(String query ){
        this.query = query;
    }
    
    @Override
    public String toString(){
        return query;
    }
}
