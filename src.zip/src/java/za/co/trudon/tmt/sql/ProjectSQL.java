/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.sql;

/**
 *
 * @author MangenaS
 */
public enum ProjectSQL {
    GetAllProjects("SELECT ID, NAME,START_DATE,STATUS,END_DATE,CREATED_BY,CREATED_DATE,EXPECTED_DATE,REVENUE_IMPACT,USAGE_IMPACT,PROJECT_OWNER,PROJECT_MANAGER,DESCRIPTION,PRIORITY,UPDATE_DATE,UPDATED_BY,PILLAR,DEACTIVATE,PARENT,CAPEX,OPEX,(select count(1) from CH_PROJECT where PARENT=p.ID)SUBPROJECTS from CH_PROJECT p where NVL(DEACTIVATE,0) != 1 and NVL(STATUS,0) != 2 order by CREATED_DATE desc,UPDATE_DATE desc"),
    GetProjectMatrix("select distinct p.id,p.name from ch_project p, CH_PROJECT_SYSTEM s where p.id=s.PROJECT_ID");
    
    private final String query;

    private ProjectSQL(String query) {
        this.query = query;
    }
    
    @Override
    public String toString(){
        return query;
    }
}
