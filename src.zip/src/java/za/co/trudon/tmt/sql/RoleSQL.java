/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.sql;

/**
 *
 * @author MangenaS
 */
public enum RoleSQL {
    GetRoleById("select role_id,role_name  from ch_project_role where role_id=?"),
    GetProjectResourceRoleId("select role_id from ch_project_team where lower(user_id)=lower(?) and project_id=?");
    
    private String query;
    
    RoleSQL(String query){
        this.query = query;
    }
    
    @Override
    public String toString(){
        return query;
    }
}
