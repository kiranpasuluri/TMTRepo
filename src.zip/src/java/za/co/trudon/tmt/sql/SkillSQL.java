/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.sql;

/**
 *
 * @author MangenaS
 */
public enum SkillSQL {
    GetSkills("select sl.SKILL_ID,sl.SKILL_NAME from CH_SKILLS_LIST sl, ch_system_skill ss  where ss.system_id=? and sl.skill_id=ss.skill_id");
  
    
    private final String query;
    
    SkillSQL(String query ){
        this.query = query;
    }
    
    @Override
    public String toString(){
        return query;
    }
}
