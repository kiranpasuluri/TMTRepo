/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.sql;

/**
 *
 * @author MangenaS
 */
public enum ResourceSQL {
    GetResourceDetails("select cp.USER_ID,cp.USERNAME, cp.EMAIL,cp.title,cp.DEPARTMENT,pr.ROLE_ID,pr.ROLE_NAME from CH_PROJECT_TEAM pt,ch_cap_user cp,CH_PROJECT_ROLE pr where pt.PROJECT_ID=? and cp.USER_ID=pt.USER_ID and pt.ROLE_ID=pr.ROLE_ID"),
    GetResourceMatrix("select a.PROJECT_ID,b.USER_ID,b.USERNAME,a.SYSTEM_ID from CH_PROJECT_USER_SYSTEM a,CH_CAP_USER b,ch_project p where a.PROJECT_ID=? and upper(a.user_id) = upper(b.user_id) and p.id=a.PROJECT_ID and nvl(System_ID,0) != 0"),    
    GetResourceProjectMatrix("select a.user_id,b.USERNAME,a.PROJECT_ID from ch_project_team a,CH_CAP_USER b where upper(b.USER_ID) = upper(a.USER_ID)"),
    getAllResources("select a.*,c.role_name,b.username from ch_user_role a, ch_cap_user b, ch_project_role c where a.role_id=c.role_id and a.user_id=b.user_id"),
    getAllNewResources("SELECT cs.*, ur.ROLE_ID, pr.ROLE_NAME FROM CH_CAP_USER cs LEFT JOIN CH_USER_ROLE ur ON cs.USER_ID = ur.USER_ID LEFT JOIN CH_PROJECT_ROLE pr ON pr.ROLE_ID = ur.ROLE_ID");
    //select a.USER_ID,b.USERNAME,a.PROJECT_ID from CH_PROJECT_USER_SYSTEM a,CH_CAP_USER b where upper(a.USER_ID) in (select DISTINCT upper(USER_ID) from ch_project_team) and upper(a.USER_ID)=upper(b.USER_ID)
    private final String query;
    
    ResourceSQL(String query){
        this.query = query;
    }
    
    @Override
    public String toString(){
        return query;
    }
}
