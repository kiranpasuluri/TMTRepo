/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.sql;

/**
 *
 * @author MangenaS
 */
public enum TaskSQL {
    
    GetUserAssignedTasks("select a.*,b.NAME project_name from CH_PROJECT_TASK a, ch_project b where upper(a.ASSIGNED_TO)=upper(?) and a.PROJECT_ID = b.id and a.status in (0,1)"),
    CloseAssignedTasks("update CH_PROJECT_TASK set status=2, update_date=sysdate where task_id=?"),
    AssignTaskEstimate("update CH_PROJECT_TASK set estimate_days=?,status=1 where task_id=?");
    
    final String query;
    
    TaskSQL(String query){
        this.query = query;
    }
    
    @Override
    public String toString(){
        return query;
    }
}
