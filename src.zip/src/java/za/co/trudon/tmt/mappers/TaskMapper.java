/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.mappers;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.ProjectTask;
import za.co.trudon.tmt.data.type.response.Resource;

/**
 *
 * @author MangenaS
 */
public class TaskMapper {
    
    public static ArrayList<Project> mapAssignedUserTask(ResultSet rs){
        ArrayList<Project> userAssingedTasks = new ArrayList<Project>();
        
        try{
            while(rs.next()){
                int projectId = rs.getInt("project_id");
                ProjectTask task = new ProjectTask();
                task.setId(rs.getInt("task_id"));
                task.setProjectId(projectId);
                task.setName(rs.getString("name"));
                task.setStatus(rs.getInt("status"));
                task.setUpdateBy(new Resource(rs.getString("update_by"), "", ""));
                task.setDescription(rs.getString("description"));
                task.setEstimateDays(rs.getDouble("estimate_days"));
                task.setEstimateHours(rs.getDouble("estimate_hours"));
                task.setTimeSpent(rs.getDouble("time_spent"));
                task.setCreatedby(rs.getString("created_by"));
                task.setCreatedDate(rs.getDate("creation_date"));
                task.setUpdatedDate(rs.getDate("update_date"));
                task.setPriority(rs.getInt("priority"));
                task.setSeverity(rs.getInt("severity"));
                task.setParentId(rs.getInt("parent_id"));
                task.setAssignedTo(new Resource(rs.getString("assigned_to"), "", ""));
                
                int index = getIndex(userAssingedTasks, projectId);
                if(index<0){
                    Project project = new Project();
                    ArrayList<ProjectTask> tasks = new ArrayList<ProjectTask>();
                    project.setId(projectId);
                    project.setName(rs.getString("project_name"));
                    tasks.add(task);
                    project.setTasks(tasks);
                    userAssingedTasks.add(project);
                }else{
                    
                    //Append tasks to projects that have already been added
                    userAssingedTasks.get(index).getTasks().add(task);
                }
            }
        }catch(Exception ex){
            Logger.getLogger(TaskMapper.class.getName()).log(Level.SEVERE, "Unable to map user assinged tasks. Error: {0}", ex.getMessage());
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }
        return userAssingedTasks;
    }
    
    //Check if project has already been added
    public static int getIndex(ArrayList<Project> projects, int projectId){
        int index=-1;
        for(int x=0;x<projects.size();x++){
            if(projects.get(x).getId()==projectId){
                index = x;
                break;
            }
        }
        return index;
    }
}


