/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.mappers;

import java.sql.ResultSet;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.dal.SkillDAO;
import za.co.trudon.tmt.data.type.response.Skill;

/**
 *
 * @author MangenaS
 */
public class SkillMapper {
    
    public static ArrayList<Skill> mapSkills(ResultSet rs){
        ArrayList<Skill> skills = new ArrayList<Skill>();
        
        try{
            while(rs.next()){
                Skill skill = new Skill();
                skill.setId(rs.getInt("skill_id"));
                skill.setName(rs.getString("skill_name"));            
                skills.add(skill);
            } 
        }catch(Exception ex){
            Logger.getLogger(SkillMapper.class.getName()).log(Priority.ERROR,"Enable to map skills. Error: "+ex.getMessage());
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }  
        return skills;
    }
}
