/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.mappers;

import java.sql.ResultSet;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.Role;
import za.co.trudon.tmt.dal.SystemDAO;
import za.co.trudon.tmt.data.type.response.System;
/**
 *
 * @author MangenaS
 */
public class ResourceMapper {
    private static final Logger LOGGER = org.apache.log4j.Logger.getLogger(ResourceMapper.class);
    
    public static ArrayList<Resource> mapResource(ResultSet rs){        
        ArrayList<Resource> resources = new ArrayList<Resource>();
        try{
            while(rs.next()){
                Resource resource = new Resource(rs.getString("user_id"), rs.getString("username"), rs.getString("email"));
                resource.setTitle(rs.getString("title"));
                resource.setDepartment(rs.getString("department"));
                Role role = new Role(rs.getInt("role_id"), rs.getString("role_name"));
                resource.setRole(role);
                resources.add(resource);
            }
        }catch(Exception ex){
            LOGGER.error("Unable to map resource details. Error: ", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }
        return resources;
    }
    
    public static ArrayList<Resource> mapResourceMatrix(ResultSet rs){        
        ArrayList<Resource> resources = new ArrayList<Resource>();
        try{
            while(rs.next()){
                String userId = rs.getString("user_id");               
                ArrayList<System> systems = new ArrayList<System>();
                //Find matching resource
                int index = getUser(resources, userId);
                if(index>-1){
                    int systemId = rs.getInt("system_id");
                    //Append systemId
                    resources.get(index).getSystemId().add(systemId);
                    systems = new SystemDAO().getResourceSystemMatrix(systemId);
                    resources.get(index).getSystems().addAll(systems);
                    resources.get(index).getProjectId().add(rs.getInt("project_id"));
                    
                }else{
                    //Add a new resource matrix
                    
                    ArrayList<Integer> systemIds = new ArrayList<Integer>();
                    ArrayList<Integer> projectIds = new ArrayList<>();

                    String username = rs.getString("username");
                    int systemId = rs.getInt("system_id");
                    projectIds.add(rs.getInt("project_id"));
                    Resource resource = new Resource(userId, username, "");
                    systemIds.add(systemId);
                    systems = new SystemDAO().getResourceSystemMatrix(systemId);
                    resource.setSystems(systems);
                    resource.setSystemId(systemIds);
                    resource.setProjectId(projectIds);
                    resources.add(resource);
                }
            }
        }catch(Exception ex){
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex2){}
            LOGGER.error("Unable to map resource matrix. Error: ", ex);
        }finally{
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex){}
        }
        return resources;
    }
    
    public static ArrayList<Resource> mapResourceProjectMatrix(ResultSet rs){        
        ArrayList<Resource> resources = new ArrayList<Resource>();
        try{
            while(rs.next()){
                String userId = rs.getString("user_id");               
                //Find matching resource
                int index = getUser(resources, userId);
                if(index>-1){
                    int projectId = rs.getInt("project_id");
                    //Append projectId
                    resources.get(index).getProjectId().add(projectId);
                }else{
                    //Add a new resource matrix
                    Resource resource;
                    ArrayList<Integer> projectIds = new ArrayList<Integer>();
                    
                    String username = rs.getString("username");
                    int projectId = rs.getInt("project_id");
                    
                    resource = new Resource(userId, username, "");
                    projectIds.add(projectId);
                    resource.setProjectId(projectIds);
                    resources.add(resource);
                }
            }
        }catch(Exception ex){
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex2){}
            LOGGER.error("Unable to map resource projects. Error: ", ex);
        }finally{
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex){}
        }
        return resources;
    }
    
    //Check if user has already been added
    private static int getUser(ArrayList<Resource> resources,String userId){       
        int result=-1;
        for(int x=0;x<resources.size();x++){
            if(resources.get(x).getUserName().equalsIgnoreCase(userId)){
                result = x;
                break;
            }
        }
        return result;
    }
}
