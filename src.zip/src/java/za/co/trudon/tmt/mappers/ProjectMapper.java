/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.mappers;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.dal.SkillDAO;
import za.co.trudon.tmt.data.type.response.Project;
import za.co.trudon.tmt.data.type.response.Resource;

/**
 *
 * @author MangenaS
 */
public class ProjectMapper {
    
    public static ArrayList<Project> mapProjects(ResultSet rs){
         ArrayList<Project> projects = new ArrayList<Project>();
        try{
            while(rs.next()){
                Project project = new Project();
                project.setId(rs.getInt("id"));
                project.setName(rs.getString("name"));
                project.setDescription(rs.getString("description"));
                project.setStartDate(rs.getString("start_date"));
                project.setStatus(rs.getInt("status"));
                project.setEndDate(rs.getString("end_date"));
                project.setCreatedBy(rs.getString("created_by"));
                project.setCreatedDate(rs.getString("created_date"));
                project.setExpectedDate(rs.getString("expected_date"));
                project.setRevenueImpact(rs.getDouble("revenue_impact"));
                project.setUsageImpact(rs.getInt("usage_impact"));
                project.setProjectOwner(new Resource(rs.getString("project_owner"), "", ""));
                project.setProjectManager(new Resource(rs.getString("project_manager"), "", ""));
                project.setProject_pillar_id(rs.getInt("pillar"));
                project.setParent(rs.getInt("parent"));
                project.setDeactivate(rs.getInt("deactivate"));
                project.setCapex(rs.getDouble("capex"));
                project.setOpex(rs.getDouble("opex"));
                project.setChildren(rs.getInt("subprojects"));
                projects.add(project);
            }
        }catch(Exception ex){
            Logger.getLogger(ProjectMapper.class.getName()).log(Priority.ERROR,"Unable to map projects. Error: ".concat(ex.getMessage()));
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }
        return projects;
    }
    
    public static ArrayList<Project> mapProjectMatrix(ResultSet rs){
        ArrayList<Project> projects = new ArrayList<Project>();
        try{
            while(rs.next()){
                Project project = new Project();
                project.setId(rs.getInt("id"));
                project.setName(rs.getString("name"));
                projects.add(project);
            }
        }catch(Exception ex){
            java.util.logging.Logger.getLogger(ProjectMapper.class.getName()).log(Level.SEVERE, "Unable to map project matrix. Error: "+ex.getMessage());      
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }
        return projects;
    }
}
