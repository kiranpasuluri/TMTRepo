/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.co.trudon.tmt.mappers;

import java.sql.ResultSet;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import za.co.trudon.tmt.data.type.response.Resource;
import za.co.trudon.tmt.data.type.response.System;
/**
 *
 * @author MangenaS
 */
public class SystemMapper {
    private static final Logger LOGGER = org.apache.log4j.Logger.getLogger(SystemMapper.class);
    public  static ArrayList<System> mapSystems(ResultSet rs,boolean countProjects){
        ArrayList<System> systems = new ArrayList<System>();
        try{
            while(rs.next()){
                System system = new System();
                system.setId(rs.getInt("id"));
                system.setName(rs.getString("name"));
                system.setDescription(rs.getString("DESCRIPTION"));
                if(countProjects){
                system.setProjectCount(rs.getInt("projectCount"));
                }
                systems.add(system);
            }
        }catch(Exception ex){
            LOGGER.error("Unable to map systems. Error: ", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }
        return systems;
    }
    
    public static ArrayList<Integer> mapSystemIds(ResultSet rs){
        ArrayList<Integer> systemIds = new ArrayList<Integer>();
        try{
            while(rs.next()){
                systemIds.add(rs.getInt("system_id"));
            }
        }catch(Exception ex){
           LOGGER.error("Unable to map system ids. Error: ", ex);
        }finally{
            try{
                if(rs!=null)rs.close();
            }catch(Exception ex){}
        }
        return systemIds;
    }
    
    public static ArrayList<System> mapResourceSystemMatrix(ResultSet rs){        
        ArrayList<System> systems = new ArrayList<System>();
        try{
            while(rs.next()){   
                     System system = new System();
                     system.setId(rs.getInt("id"));
                     system.setName(rs.getString("name"));
                     systems.add(system);
            }
        }catch(Exception ex){
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex2){}
            LOGGER.error("Unable to map resource projects. Error: ", ex);
        }finally{
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex){}
        }
        return systems;
    }
    
    public static ArrayList<System> mapSystemResourceMatrix(ResultSet rs){        
        ArrayList<System> systems = new ArrayList<System>();
        try{
            while(rs.next()){   
                int systemId = rs.getInt("id");
                int index = getSystem(systems,systemId);
                String userId = rs.getString("user_id");
                
                if(index==-1){
                     System system = new System();
                     ArrayList<String> userIds = new ArrayList<String>();
                     userIds.add(userId);
                     system.setId(systemId);
                     system.setName(rs.getString("name"));
                     system.setResources(userIds);
                     systems.add(system);
                }else{
                    //Append user_id to a system that has already been captured
                    systems.get(index).getResources().add(userId);
                }
            }
        }catch(Exception ex){
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex2){}
            LOGGER.error("Unable to map resource projects. Error: ", ex);
        }finally{
            try{
               if(rs!=null)rs.close(); 
            }catch(Exception ex){}
        }
        return systems;
    }
    
    //Check if system has already been added
    private static int getSystem(ArrayList<System> systems,int systemId){       
        int result=-1;
        for(int x=0;x<systems.size();x++){
            if(systems.get(x).getId()==systemId){
                return x;
            }
        }
        return result;
    }
}
