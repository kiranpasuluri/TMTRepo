/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



function fnFormatDetails (oTableQuery, nTrQuery, data )
{
    var aDataQuery = oTableQuery.fnGetData( nTrQuery );
  //  var rowIndexQuery =  parseInt(aDataQuery[1])-1;//get the index of the clicked row from index-column text value - which is 1 based
    return loadSubTasks(data);
}

function Active(indicator){
    return indicator > 0? 'No':'Yes';
}

function loadTasksContentData(data){
   var contentBody = document.getElementById("allTasksContentBody");
   contentBody.innerHTML = loadParentTasks(JSON.stringify(data));
   sessionStorage.setItem('projects', JSON.stringify(data));
   RunTableBuilder(); 
}
      
 function loadParentTasks(data) {
            var queryTblRows = '';
            $.each(JSON.parse(data), function(idx, proj) {
                var taskCount = '';
                if (proj.tasks !== null && proj.tasks.length > 0){
                    queryTblRows +=  "<tr style='background:#CDF1FE'>";
                    for(i = 0; i < proj.tasks.length; i++){
                        if(proj.tasks[i].parentId === 0){
                            taskCount++;
                        }
                    }
                } else{
                    queryTblRows +=  "<tr>";
                    taskCount = 0;
                }
                        
                queryTblRows += "<td>#</td>" +
                                "<td>"+ idx +"</td>"+
                                "<td>" +
                                "<a style=\"cursor:pointer\" href=\"projects/id/"+ proj.id +"\"><b>"+ proj.name +"</b></a>" +
                                "</td>";
                queryTblRows += "<td>" + taskCount + "</td>";      
                queryTblRows += "<td></td>";
                queryTblRows += "<td></td>"; 
                queryTblRows += "</tr>";
            });      
           return queryTblRows; 
        }
       

 function loadSubTasks(data){
    var queryTblRows = ''; 
    sessionStorage.setItem('selectedProject', JSON.stringify(data));
    var str ="<table  cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"display table table-bordered\">" +
             "<thead>" +
             "<tr>" +
             "<th style=\"width: 1%\">#</th>" +
             "<th style=\"width: 20%\">Name</th>" +
             "<th style=\"width: 20%\">Description</th>" +
             "<th style=\"width: 20%\">Progress</th>" +
             "<th style=\"width: 20%\">Status</th>" +
             "<th style=\"width: 20%\">Time Spent</th>" +
             "</tr>" +
             "</thead>" +
             "<tbody class=\"selects\">";    
    
    $.each(data.tasks, function(idx, task) {
        if(task.parentId === 0){
        queryTblRows += "<tr style='background:#D3F7DE'>"
                        +"<td>#</td>"
                        +"<td>"
                        +"<a style=\"cursor:pointer\" href=\"projects/task/"+ task.id +"\"><b>"+ task.name +"</b></a>"
                        +"</td>"
                        +"<td>" + task.description
                        +"</td>"
                        +"<td>"
                        +"</td>"
                        +"<td>" + statusAsString(task.status)
                        +"</td>"
                        +"<td>"
                        +"</td>";
        queryTblRows += "</tr>";  
    }
    });            

        var returnString =  str + queryTblRows + '</tbody></table>';
                  
        return   returnString;
}

            function statusAsString(status) {
                var val;
                switch (status) {
                    case 0:
                        val = 'New';
                        break;
                    case 1:
                        val = 'In Progress';
                        break;
                    case 2:
                        val = 'Completed';
                        break;
                    default:
                        val = 'N/A';
                        break;
                }
                return val;
            }

function RunTableBuilder(){
     /*
    * Insert a 'details' column to the table
    */
   var nCloneThQuery = document.createElement('th');   
   var nCloneTdQuery = document.createElement('td');
    nCloneTdQuery.innerHTML = '<img src="../plugins/advanced-datatable/images/details_open.png">';
    nCloneTdQuery.className = "center";
    

   $('#allTasksTable thead tr').each( function () {
        this.insertBefore(nCloneThQuery, this.childNodes[0] );
    });

   $('#allTasksTable tbody tr').each(function () {
       this.insertBefore(nCloneTdQuery.cloneNode( true ), this.childNodes[0]);
    } );

    /*
     * Initialse DataTables, with no sorting on the 'details' column
     */ 
    
   var oTableQuery = $('#allTasksTable').dataTable({"paging": true,"searching": true,
        "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 0 ] },
            { "width": "2%", "targets": 0 }
        ],
        "aaSorting": [[1, 'asc']] //asc
    });

    /* Add event listener for opening and closing details
     * Note that the indicator for showing which row is open is not controlled by DataTables,
     * rather it is done here
     */
    $('#allTasksTable').on("click", ".center",function () {
        var nTrQuery = $(this).parents('tr')[0];
        if ( oTableQuery.fnIsOpen(nTrQuery) )
        {
            /* This row is already open - close it */
            this.children[0].src = "../plugins/advanced-datatable/images/details_open.png";
            oTableQuery.fnClose( nTrQuery );
        }
        else
        {
            /* Open this row */
            this.children[0].src = "../plugins/advanced-datatable/images/details_close.png";
            var aDataQuery = oTableQuery.fnGetData(nTrQuery);
            var rowIndexQuery =  parseInt(aDataQuery[2]);//get the index of the clicked row from index-column text value - which is 1 based
            var project = JSON.parse(sessionStorage.getItem('projects'));

                var dynClass = 'details_odd';
                if(rowIndexQuery%2 !== 0)
                    dynClass = 'details';
               oTableQuery.fnOpen( nTrQuery, fnFormatDetails(oTableQuery, nTrQuery,project[rowIndexQuery]), dynClass );


        }
    } );
}

function onUpdateResourceSkill(resource) {
    loadAllSkills(JSON.stringify(resource));
    $('#resourceSkillDialog').dialog({
        height: 600,
        width: 700,
        modal: true,
        resizable: false,
        dialogClass: 'no-close success-dialog',
        create: function (event, ui) {
            var widget = $(this).dialog("widget");
            $(".ui-dialog-titlebar-close span", widget)
                    .removeClass("ui-icon-closethick")
                    .removeClass("ui-icon")
                    .addClass("ui-icon-closedia");
        }

    });
    $('#cancelResourceSkillBtn').click(function (event) {
        //clear the form
        $('#resourceSkillDialog').dialog("close");
    });
}

function loadAllSkills(sys) {
    var val = JSON.parse(sys);
    console.log(val);
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        Accept: "application/json",
        contentType: "application/json",
        method: "GET",
        url: "../../profile/resource/skills",
        dataType: 'json',
        success: function (data) {
            for (i = 0; i < data.length; i++) {
                var flag = false;
                for (x = 0; x < val.skills.length; x++) {
                    if (val.skills[x].id === data[i].id) {
                        $("#resourceSkillSearch_to").append("<option value=\"" + data[i].id + "\">" + data[i].name + "</option>");
                        flag = true;
                    }
                }
                if (!flag) {
                    $("#resourceSkillSearch").append("<option value=\"" + data[i].id + "\">" + data[i].name + "</option>");
                }
            }
        },
        error: function (data) {
            alert("An error occured trying to get skills: \n" + JSON.parse(data));
            $.loader.close(true);
        }
    });

    $('#resourceSkillSearch').multiselect({
        search: {
            left: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
            right: '<input type="text" name="q" class="form-control" placeholder="Search..." />'
        },
        fireSearch: function (value) {
            return value.length > 1;
        },
        right: '#resourceSkillSearch_to',
        rightAll: '#res_right_All_1',
        rightSelected: '#res_right_Selected_1',
        leftSelected: '#res_left_Selected_1',
        leftAll: '#res_left_All_1'
    });
}

function onUpdateSystem(systemId, systemName, systemDescription) {
    $('#updateSystemId').val(systemId);
    $('#updateSystemName').val(systemName);
    $('#updateDescription').val(systemDescription);
    $('#updateSystemDialog').dialog({
        height: 400,
        width: 700,
        modal: true,
        resizable: false,
        dialogClass: 'no-close success-dialog',
        create: function (event, ui) {
            var widget = $(this).dialog("widget");
            $(".ui-dialog-titlebar-close span", widget)
                    .removeClass("ui-icon-closethick")
                    .removeClass("ui-icon")
                    .addClass("ui-icon-closedia");
        }
    });

    $('#cancelUpdateSystemBtn').click(function (event) {
        $('#updateSystemDialog').dialog("close");
    });
}