function buildSystemAttributesContent(data){
            var queryTblRows = '<table  cellpadding="0" cellspacing="0" border="0" class="display table table-bordered">' +
                               '<thead>' +
                               '<tr style="white-space: nowrap">' +
                               '<th>#</th>'+
                               '<th>Server Name</th>' +
                               '<th>Database Name</th>' +
                               '<th>Database Server Name</th>' +
                               '<th>Operating System</th>'+
                               '<th>Hosting System</th>' +
                               '<th>Language</th>' +
                               '<th>API Documentation</th>' +
                               '<th>License Required</th>' +
                               '<th>Third Party</th>' +
                               '<th>Frequency</th>' +
                               '<th>Capex</th>' +
                               '<th>Opex</th>' +
                               '<th>#Edit</th>' +
                               '</tr>' +
                               '</thead>' +
                               '<tbody class="selects">';
                       
                         queryTblRows += "<tr style='white-space: nowrap'>"
                                        +"<td>"
                                        +"</td>"
                                        +"<td>"
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td>" 
                                        +"</td>" 
                                        +"<td><a href='#' onclick='loadSystemAttributesData(-1);' class=\"btn btn-danger btn-xs\"><i class=\"fa fa-plus\"></i>Add</a></td>";
                                        queryTblRows += "</tr>";  
             
                  for(i = 0; i < data.length; i++){
                      
                     var systemAttributes =  data[i];
                     
                      queryTblRows += "<tr>"+
                                                  "<td>"+ i +"</td>"+
                                                   "<td>"+ systemAttributes.serverName +"</td>";
                                                  queryTblRows += "<td>" +
                                                                   systemAttributes.databaseName
                                                                   +"</td>"+
                                                                   "<td>" +
                                                                   systemAttributes.databaseServerName
                                                                   +"</td>" 
                                                                   + "<td>"+
                                                                   systemAttributes.operatingSystem
                                                                   +"</td>" 
                                                                   + "<td>"+ 
                                                                   systemAttributes.hostingSystem
                                                                   +"</td>" 
                                                                   +"<td>"+
                                                                   systemAttributes.language
                                                                   +"</td>" 
                                                                   +"<td>" +
                                                                   systemAttributes.apiDocumentation
                                                                   +"</td>" 
                                                                   +"<td>" +
                                                                   (systemAttributes.licenseRequired == 1 ? "Yes": "No" )
                                                                   +"</td>" 
                                                                   + "<td>" +
                                                                   systemAttributes.thirdParty
                                                                   +"</td>" 
                                                                   + "<td>" +
                                                                   systemAttributes.frequency
                                                                    +"</td>" 
                                                                    + "<td>" +
                                                                    systemAttributes.capex
                                                                    +"</td>" 
                                                                    + "<td>" +
                                                                    systemAttributes.opex
                                                                    +"</td>" 
                                                                    +"<td><a href='#' onclick='loadSystemAttributesData("+ i +");' class=\"btn btn-danger btn-xs\"><i class=\"fa fa-plus\"></i>Edit</a></td>"
                                                                    +"<td><a href='#' onclick='deleteSystemAttributes("+ i +");' class=\"btn btn-danger btn-xs\"><i class=\"fa fa-trash-o\"></i>Delete</a></td>";
                                                                   queryTblRows +=   "</tr>";  
                 }
                  
                  queryTblRows += '</tbody></table>';
                  
                  $("#bodyDiv").html(queryTblRows);
        }
        
      
         function loadSystemAttributes(systemId, systemName){
             
           $('#confirmModal').dialog({
            height:$(document).height(),
            width: $(document).width(),
            modal: true,
            resizable: true,
            //dialogClass: 'no-close success-dialog',
            create: function(event, ui) { 
                var widget = $(this).dialog("widget");
                //$(".ui-dialog-titlebar-close span", widget)
                 // .addClass("ui-icon-closedia")
                 // .addClass("disabledWindows");
            }
            }); 
            
           $('#okBtn').click(function(event) {
                clearItems();
                $('#confirmModal').dialog("close");
            });
        
          $('#cancelBtn').click(function(event) {
              clearItems();
             $('#confirmModal').dialog("close");
          });
           $('#closeSpan').click(function(event) {
               clearItems();
             $('#confirmModal').dialog("close");
          });
          
          $('#lblHeader').text(systemName);
          
          $("#MainContent").css("width", "1600px");
          //$("#MainContent").css("height", "400px");
          
           getSystemAttributes(systemId);
        }
        
        function getSystemAttributes(systemId){
            $.ajax({               
              headers: { 
                  'Accept': 'application/json',
                   'Content-Type': 'application/json' 
                 },
               Accept : "application/json",
               contentType: "application/json",
                method: "GET",
                url: "systems_matrix/systemattributes/"+ systemId,
                dataType:'json',
                 success: function(data) {
                   $("#txtSystemId").val(systemId); 
                   sessionStorage.setItem('systemAttributesCollection',JSON.stringify(data)); 
                   buildSystemAttributesContent(data);
                  },
                  error: function(xhr,err,thrownError){
                       alert("Error: "+err +
                               "\nResponse Text: "+xhr.responseText +
                               "\nMessage: "+thrownError +
                                "\nready State: "+xhr.readyState +
                               "\nStatus: "+xhr.status);
                  }
            });       
        }
        
        
        function clearItems(){
            sessionStorage.removeItem("systemAttributes");
            sessionStorage.removeItem("systemAttributesCollection");
            $("#txtId").val(0);
            $("#txtSystemId").val(0)
        }
        
        
        function loadSystemAttributesData(i){
            
            var systemAttributesCollection = JSON.parse(sessionStorage.getItem('systemAttributesCollection'));
            
            if ((systemAttributesCollection !== null) && (i !== -1)){
               sessionStorage.setItem('systemAttributes', JSON.stringify(systemAttributesCollection[i])); 
            }
            
           $('#addSystemAttributes').dialog({
            height:1400,
            width: 1000,
            modal: true,
            resizable: true,
            //dialogClass: 'no-close success-dialog',
            create: function(event, ui) { 
                var widget = $(this).dialog("widget");
                //$(".ui-dialog-titlebar-close span", widget)
                 // .addClass("ui-icon-closedia")
                //  .addClass("disabledWindows");
           }
           }); 
             setSystemAtrributes();
        }
        
        function setSystemAtrributes(){

         var systemAttributes = {id:"",systemId:"",serverName:"", databaseName:"",databaseServerName:"",operatingSystem:"",hostingSystem:"",language:"",apiDocumentation:"",licenseRequired:"",thirdParty:"",frequency:"0",capex:"0",opex:"0",status:""};
         
         var jsonSystemAttributes = JSON.parse(sessionStorage.getItem('systemAttributes'));
         
            if (jsonSystemAttributes != null){
               systemAttributes = jsonSystemAttributes;
            }
            else{
                systemAttributes  = null;
                $("#txtId").val("");
                $("#txtServerName").val("");
                $("#txtDatabaseName").val("");
                $("#txtDatabaseServerName").val("");
                $("#txtOPeratingSystem").val("");
                $("#txtHostingSystem").val("");
                $("#txtLanguage").val("");
                $("#txtAPIDocumentation").val("");
                $("#chLicenseRequired").prop("checked", false);
                $("#txtThirdParty").val("");
                $("#txtFrequency").val("0"); 
                $("#txtCapex").val("0"); 
                $("#txtOpex").val("0"); 
            }
            
            if (systemAttributes != null){
                
            $("#txtId").val(systemAttributes.id);
            $("#txtSystemId").val(systemAttributes.systemId);
            $("#txtServerName").val(systemAttributes.serverName);
            $("#txtDatabaseName").val(systemAttributes.databaseName);
            $("#txtDatabaseServerName").val(systemAttributes.databaseServerName);
            $("#txtOPeratingSystem").val(systemAttributes.operatingSystem);
            $("#txtHostingSystem").val(systemAttributes.hostingSystem);
            $("#txtLanguage").val(systemAttributes.language);
            $("#txtAPIDocumentation").val(systemAttributes.apiDocumentation);
            $("#chLicenseRequired").prop("checked", (systemAttributes.licenseRequired == 1 ? true:false));
            $("#txtThirdParty").val(systemAttributes.thirdParty);
            $("#txtFrequency").val(systemAttributes.frequency);
            $("#txtCapex").val(systemAttributes.capex); 
            $("#txtOpex").val(systemAttributes.opex); 
        }
        
    }
        
        function saveSystemAttributes(){
            
             var jsonSystemAttributes = JSON.parse(sessionStorage.getItem('systemAttributes'));
            
             var systemAttributes = {id:"",systemId:"",serverName:"", databaseName:"",databaseServerName:"",operatingSystem:"",hostingSystem:"",language:"",apiDocumentation:"",licenseRequired:"",thirdParty:"",frequency:0,capex:0,opex:0};
             
            if (jsonSystemAttributes != null){
               systemAttributes = jsonSystemAttributes;
            }
            
              systemAttributes.id =  $("#txtId").val();
              systemAttributes.systemId = $("#txtSystemId").val();
              systemAttributes.serverName = $("#txtServerName").val();
              systemAttributes.databaseName = $("#txtDatabaseName").val();
              systemAttributes.databaseServerName = $("#txtDatabaseServerName").val();
              systemAttributes.operatingSystem = $("#txtOPeratingSystem").val();
              systemAttributes.hostingSystem =  $("#txtHostingSystem").val();
              systemAttributes.language = $("#txtLanguage").val();
              systemAttributes.apiDocumentation = $("#txtAPIDocumentation").val();
              systemAttributes.licenseRequired = ($('#chLicenseRequired').is(':checked') ? 1:0);
              systemAttributes.thirdParty = $("#txtThirdParty").val();
              systemAttributes.frequency = $("#txtFrequency").val();
              systemAttributes.capex = $("#txtCapex").val();
              systemAttributes.opex = $("#txtOpex").val();
            
           $.ajax({
                headers: { 
                    'Accept': 'application/json',
                    'Content-Type': 'application/json' 
                },
                Accept : "application/json",
                contentType: "application/json",
                method: "POST",
                url: "systems_matrix/save",
                data: JSON.stringify(systemAttributes),
                dataType:'json',
                  success: function(data) {
                      if (data){
                           getSystemAttributes(systemAttributes.systemId);
                           clearItems();
                           $('#addSystemAttributes').dialog("close");
                      }
                  },
                  error: function(xhr,err,thrownError){
                       alert("Error: "+err +
                               "\nResponse Text: "+xhr.responseText +
                               "\nMessage: "+thrownError +
                                "\nready State: "+xhr.readyState +
                               "\nStatus: "+xhr.status);
                  }
            });  
        
    }
    
    
    function deleteSystemAttributes(i){
        
         var systemAttributesCollection = JSON.parse(sessionStorage.getItem('systemAttributesCollection'));

         var jsonSystemAttributes = systemAttributesCollection[i];
            
         var systemAttributes = {id:"",systemId:"",serverName:"", databaseName:"",databaseServerName:"",operatingSystem:"",hostingSystem:"",language:"",apiDocumentation:"",licenseRequired:"",thirdParty:"",frequency:0};
             
            if (jsonSystemAttributes != null){
                
               systemAttributes = jsonSystemAttributes;
               
              $.ajax({
                headers: { 
                    'Accept': 'application/json',
                    'Content-Type': 'application/json' 
                },
                Accept : "application/json",
                contentType: "application/json",
                method: "POST",
                url: "systems_matrix/delete/"+ systemAttributes.id,
                dataType:'json',
                  success: function(data) {
                      if (data){
                           getSystemAttributes(systemAttributes.systemId);
                           clearItems();
                      }
                  },
                  error: function(xhr,err,thrownError){
                       alert("Error: "+err +
                               "\nResponse Text: "+xhr.responseText +
                               "\nMessage: "+thrownError +
                                "\nready State: "+xhr.readyState +
                               "\nStatus: "+xhr.status);
                  }
            });   
        }else{
            alert('Invalid System Attribute');
        }
        
    }
    
  $(document).ready(function() {
         $('#cancelAttributesBtn').click( function(event){
                  sessionStorage.removeItem("systemAttributes");
                 $('#addSystemAttributes').dialog("close");
            });
           
            $('#saveAttributesBtn').click(function(event) {
              saveSystemAttributes();
             });
        
      });  
    
        
        