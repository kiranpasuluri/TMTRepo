function loadSystemProjectMatrix(){
            $.ajax({               
              headers: { 
                  'Accept': 'application/json',
                   'Content-Type': 'application/json' 
                 },
               Accept : "application/json",
               contentType: "application/json",
                method: "GET",
                url:"systems_matrix/systemprojectmatrix" ,
                dataType:'json',
                 success: function(data) {
                    sessionStorage.setItem('systemprojectmatrix',JSON.stringify(data));
                    buildMatrix();
                    sessionStorage.setItem("matrixId", "systemMatrix");
                  },
                  error: function(xhr,err,thrownError){
                       alert("Error: "+err +
                               "\nResponse Text: "+xhr.responseText +
                               "\nMessage: "+thrownError +
                                "\nready State: "+xhr.readyState +
                               "\nStatus: "+xhr.status);
                   $.loader.close(true);
                  }
            });       
        }
        
        
     function loadResourcesMatrix(){
          $.ajax({               
              headers: { 
                  'Accept': 'application/json',
                   'Content-Type': 'application/json' 
                 },
               Accept : "application/json",
               contentType: "application/json",
                method: "GET",
                url:"resources_matrix/resourcematrix" ,
                dataType:'json',
                 success: function(data) {
                    sessionStorage.setItem('resourcematrix',JSON.stringify(data));
                    buildResourceMatrix();
                  },
                  error: function(xhr,err,thrownError){
                       alert("Error: "+err +
                               "\nResponse Text: "+xhr.responseText +
                               "\nMessage: "+thrownError +
                                "\nready State: "+xhr.readyState +
                               "\nStatus: "+xhr.status);
                   $.loader.close(true);
                  }
            });       
     }   
     
      function loadProjectMatrix(){
          $.ajax({               
              headers: { 
                  'Accept': 'application/json',
                   'Content-Type': 'application/json' 
                 },
               Accept : "application/json",
               contentType: "application/json",
                method: "GET",
                url:"projects/projectmatrix" ,
                dataType:'json',
                 success: function(data) {
                    sessionStorage.setItem('projectmatrix',JSON.stringify(data));
                   buildProjectMatrix();
                  },
                  error: function(xhr,err,thrownError){
                       alert("Error: "+err +
                               "\nResponse Text: "+xhr.responseText +
                               "\nMessage: "+thrownError +
                                "\nready State: "+xhr.readyState +
                               "\nStatus: "+xhr.status);
                   $.loader.close(true);
                  }
            });       
     }   
        

function buildMatrix(){
    
    var systemprojectmatrix = JSON.parse(sessionStorage.getItem('systemprojectmatrix')); 
    var systems = systemprojectmatrix.systems;
    var projects = systemprojectmatrix.projects;
    
       var queryTbl =  "<table id=\"systemMatrix\" border=\"1\">";  
           
                       queryTbl += "<tr style=\"white-space: nowrap\">"
                                   +"<td colspan=\"2\"></td>";
                            
                         for (i=0; i< systems.length; i++){
                             var system = systems[i];
                             queryTbl += "<td class=\"verticalText\" width=\"30\" height=\"200\"><a style=\"cursor:pointer\" href=\"#\"  onclick=\"loadSystemAttributes("+system.id+",\'"+system.name.trim()+"\');\">"+system.name.trim()+"</a></td>";
                         }
                         queryTbl += "</tr>"
                                     +"<tr height=\"30\">"
                                     +"<td colspan=\"2\"></td>";
                            
                            for (i=0; i< systems.length; i++){
                                 var system = systems[i];
                                 queryTbl += "<td class=\"verticalText\" width=\"30\" height=\"30\" style=\"text-align:center\">"+system.projectCount+"</td>";
                            }
                            
                            queryTbl += "</tr>"
                                       +"<tr>";
                            
                             for (i=0; i< projects.length; i++){
                                
                                   var project =  projects[i];
                                
                                   queryTbl += "<td width=\"100\" ><a style=\"cursor:pointer\" href=\"#\"  onclick=\"loadProjectPage("+project.id+",\'"+project.name.trim()+"\')\">"+project.name+"</a></td>"
                                               +"<td style=\"padding: 0; height:30%\">"
                                               +"<table border=\"1\" style=\"height:30%\">";
                                       

                                       for (j = 0; j< project.resources.length ; j++){
                                            var resource = project.resources[j];
                                            var space = resource.fullNames.indexOf(" ");
                                            var firstName = resource.fullNames;
                                             if(space>0){
                                                   firstName = firstName.substring(0, space);
                                              }
                                              
                                            queryTbl += "<tr><td width=\"100\">"+firstName+"</td></tr>";
                                       }
                                       
                               var users = project.resources.length;
                                //Insert blank rows to fill up project row.
                                if(users<7){
                                   for (x = users; x < 7; x++){
                                            queryTbl += "<tr><td width=\"100\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>";
                                        }
                                    }
                                queryTbl += "</table>"
                                           +"</td>"
                                           +"<td style=\"padding: 0; height:30%\">"
                                           +"<table border=\"1\" style=\"height:30%\">";
                                   
                                   for (k = 0; k < project.resources.length; k++){
                                       var resource = project.resources[k];
                                       var firstName = resource.userName;

                                    queryTbl += "<tr>";
                                    
                                     for(c = 0; c < systems.length; c++){
                                        var system = systems[c];
                                        var  arrsystem = [];
                                        for(f =0; f<resource.systems.length; f++){
                                        if(resource.systems[f].id == system.id){
                                            arrsystem.push(resource.systems[f].id);
                                        }
                                    }
                                     if(arrsystem.includes(system.id)){
                                        queryTbl += "<td width=\"30\" style=\"text-align:center\" data-toggle=\"tooltip\" title=\""+firstName+": "+system.name+" \" ><i class=\"fa fa-circle\"></i></td>";
                                        }else{
                                            queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                        }
                                    }
                                    queryTbl += "</tr>";
                                   }
                                //Team member system cells
                                for(r = 0; r < project.resources.length; r++){
                                      var resource = project.resources[r];
                                      for(s = 0; s< system.length; s++){
                                          var arrsystem = [];
                                          var system = systems[c];
                                           for(f =0; f<resource.systems.length; f++){
                                        if(resource.systems[f].id == system.id){
                                             arrsystem.push(resource.systems[f].id);
                                         }
                                    }
                                    if(arrsystem.includes(system.id)){
                                          queryTbl += "<td width=\"30\" style=\"text-align:center\" data-toggle=\"tooltip\" title=\""+firstName+": "+system.name+" \" ><i class=\"fa fa-circle\"></i></td>";
                                        }else{
                                            queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                        }
                                      }
                                       queryTbl += "</tr>";
                                }
                                 //Insert blank rows to fill up project row.
                                    if(users<7){
                                        for (x=users; x<7 ;x++){
                                              queryTbl +="<tr>";
                                              for(y=0;y<systems.length;y++){
                                                  queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                              }
                                               queryTbl += "</tr>";
                                        }
                                    }
                                queryTbl += "</table>"
                                            +"</td>"
                                            +"</tr>";                     
                            }
                            
        queryTbl +="</table>";
                    
   $("#systemsProjectsDiv").html(queryTbl);
}  


function buildResourceMatrix(){
    
    var resourceprojectmatrix = JSON.parse(sessionStorage.getItem('resourcematrix')); 
    var resources = resourceprojectmatrix.resources;
    var systems = resourceprojectmatrix.systems;
    
     var queryTbl =  "<table border=\"1\">";  
           
                       queryTbl += "<tr style=\"white-space: nowrap\">"
                                   +"<td colspan=\"2\"></td>";
                            
                         for (i=0; i< resources.length; i++){
                             var resource = resources[i];
                             queryTbl += "<td class=\"verticalText\" width=\"30\" height=\"200\"><a style=\"cursor:pointer\" href=\"#\">"+resource.fullNames.trim()+"</a></td>";
                         }
                         queryTbl += "</tr>"
                                     +"<tr height=\"30\">"
                                     +"<td colspan=\"2\"></td>";
                            
                            for (i=0; i< resources.length; i++){
                                 var resource = resources[i];
                                 var systemCount = [];
                                 for(e = 0; e < resource.systemId.length; e++) {
                                     if(!systemCount.includes(resource.systemId[e]))
                                     {
                                          systemCount.push(resource.systemId[e]);
                                     }
                                     
                                 }
                                 queryTbl += "<td class=\"verticalText\" width=\"30\" height=\"30\" style=\"text-align:center\">"+systemCount.length+"</td>";
                            }
                            
                            queryTbl += "</tr>"
                                       +"<tr>";
                            
                             for (i=0; i< systems.length; i++){
                                
                                   var system =  systems[i];
                                
                                   queryTbl += "<td style=\"padding-left:5px\" width=\"30\" ><a style=\"cursor:pointer\" href=\"#\"  onclick=\"loadSystemAttributes("+system.id+",\'"+system.name.trim()+"\');\">"+system.name.trim()+"</a></td>"
                                               +"<td>"
                                               +"<table border=\"1\">";
                                       
                                       
                                       for (j = 0; j< system.projects.length ; j++){
                                            var project = system.projects[j];
                                            queryTbl += "<tr><td width=\"200\"><a style=\"padding-left:5px\" href=\"#\"  onclick=\"loadProjectPage("+project.id+",\'"+project.name.trim()+"\')\">"+project.name+"</a></td></tr>";
                                       }
                               var projectCount = system.projects.length;
                                //Insert blank rows to fill up project row.
                                if(projectCount<7){
                                   for (x = projectCount; x < 7; x++){
                                            queryTbl += "<tr><td width=\"200\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>";
                                        }
                                    }
                                queryTbl += "</table>"
                                           +"</td>"
                                           +"<td>"
                                           +"<table border=\"1\">";
                                   
                                   
                                   for (k = 0; k < system.projects.length; k++){
                                       var project = system.projects[k];
                                       
                                    queryTbl += "<tr>";
                                    
                                     for(c = 0; c < resources.length; c++){
                                        var resource = resources[c];
                                        var arrsystem = [];
                                        for (u = 0; u < resource.systemId.length; u++){
                                            for(f=0; f<resource.projectId.length; f++) {
                                                if(resource.projectId[f] === project.id){
                                                    if(resource.systemId[u] === system.id) {
                                                          arrsystem.push(system.id);
                                                }
                                            }
                                         }
                                          }
                                        
                                        if(arrsystem.includes(system.id)){
                                            queryTbl += "<td width=\"30\" style=\"text-align:center\" data-toggle=\"tooltip\" title=\""+ project.name +": "+ resource.fullNames +" \" ><i class=\"fa fa-circle\"></i></td>";
                                        }else{
                                            queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                        }
                                    }
                                    queryTbl += "</tr>";
                                   }
                                    if(projectCount<7){
                                        for (x=projectCount; x<7 ;x++){
                                              queryTbl +="<tr>";
                                              for(y=0;y<resources.length;y++){
                                                  queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                              }
                                               queryTbl += "</tr>";
                                        }
                                    }
                                queryTbl += "</table>"
                                            +"</td>"
                                            +"</tr>";                     
                            }
                            
        queryTbl +="</table>";
    
   $("#resourcesDiv").html(queryTbl);
}  


function buildProjectMatrix(){
    
    var resourceprojectmatrix = JSON.parse(sessionStorage.getItem('projectmatrix')); 
    var resources = resourceprojectmatrix.resources;
    var projects = resourceprojectmatrix.projects;
    var matrixSystems = resourceprojectmatrix.systems;
    var queryTbl =  "<table class=\"table-responsive\" border=\"1\">";  
           
                       queryTbl += "<tr style=\"white-space: nowrap\">"
                                   +"<td colspan=\"2\"></td>";
                            
                         for (a=0; a< projects.length; a++){
                             var project = projects[a];
                             queryTbl += "<td class=\"verticalText\" width=\"30\" height=\"200\"><a style=\"cursor:pointer\" href=\"#\"  onclick=\"loadProjectPage("+project.id+",\'"+project.name.trim()+"\')\">"+project.name+"</a></td>";
                         }
                         queryTbl += "</tr>"
                                     +"<tr>"
                                     +"<td colspan=\"2\"></td>";
                            
                            for (b=0; b< projects.length; b++){
                                 var project = projects[b];
                                 queryTbl += "<td class=\"verticalText\" width=\"30\" height=\"30\" style=\"text-align:center\">"+project.resources.length+"</td>";
                            }
                            
                            queryTbl += "</tr>"
                                       +"<tr>";
                            
                             for (t=0; t< resources.length; t++){
                                
                                   var resource =  resources[t];
                                
                                   queryTbl += "<td style=\"padding-left:5px\" width=\"100\" ><a style=\"cursor:pointer\" href=\"#\">"+resource.fullNames.trim()+"</a></td>"
                                               +"<td>"
                                               +"<table class=\"table-responsive\" border=\"1\">";
                                       
                                       var systemCount = 0;
                                       for (m = 0; m< matrixSystems.length ; m++){
                                            var system = matrixSystems[m];
                                            for(x = 0; x < resource.systems.length; x++) {
                                                if(system.id === resource.systems[x].id){
                                                    systemCount++;
                                                    queryTbl += "<tr><td width=\"200\"><a style=\"white-space: nowrap\" href=\"#\"  onclick=\"loadSystemAttributes("+system.id+",\'"+system.name.trim()+"\');\">"+system.name.trim()+"</a></td></tr>";
                                                    break;
                                                }
                                            }
                                       }
                                       
                               //Insert blank rows to fill up project row.
                                if(systemCount<7){
                                   for (n = systemCount; n < 7; n++){
                                            queryTbl += "<tr><td width=\"200\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>";
                                        }
                                    }
                                queryTbl += "</table>"
                                           +"</td>"
                                           +"<td>"
                                           +"<table class=\"table-responsive\" border=\"1\" style=\"padding-left:5px\">";
                                   
                                 
                                       
                                       var firstName = resource.fullNames;
                                      
                                       
                                    for (r=0; r < matrixSystems.length; r++){
                                        
                                        
                                     
                                       var system = matrixSystems[r];
                                       for(x = 0; x < resource.systems.length; x++) {
                                            if(system.id === resource.systems[x].id){
                                            queryTbl += "<tr>";
                                            for(d = 0; d < projects.length; d++) {
                                             var  project = projects[d];
                                             var arrsystem = [];
                                             for (u=0; u<resource.projectId.length;u++){
                                                 if(resource.projectId[u] === project.id){
                                                     for(f=0; f<project.systems.length; f++){
                                                         if(project.systems[f].id === system.id){
                                                            arrsystem.push(system.id);
                                                        }
                                                    }
                                                }
                                             }
                                            if(arrsystem.includes(system.id)){
                                            queryTbl += "<td width=\"30\" style=\"text-align:center\" data-toggle=\"tooltip\" title=\""+ project.name +": "+ firstName +" \" ><i class=\"fa fa-circle\"></i></td>";
                                        }else{
                                            queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                        }
                                           } 
                                                 queryTbl += "</tr>";
                                                 break;
                                            }
                                       }

                                            
                                         } 

                                    if(systemCount<7){
                                        for (x=systemCount; x<7 ;x++){
                                              queryTbl +="<tr>";
                                              for(y=0;y<projects.length;y++){
                                                  queryTbl += "<td width=\"30\" style=\"text-align:center\">&nbsp;</td>";
                                              }
                                               queryTbl += "</tr>";
                                        }
                                    }
                                queryTbl += "</table>"
                                            +"</td>"
                                            +"</tr>";                     
                            
                        }  
        queryTbl +="</table>";
   $("#projectsDiv").html(queryTbl);
}  


 function loadProjectPage(projectId,projectName){
         $('#confirmModal').dialog({
            height:$(document).height(),
            width: $(document).width(),
            modal: true,
            resizable: true,
            //dialogClass: 'no-close success-dialog',
            create: function(event, ui) { 
                var widget = $(this).dialog("widget");
                $(".ui-dialog-titlebar-close span", widget)
                  .addClass("ui-icon-closedia")
                  .addClass("disabledWindows");
            }
            });
            
           $('#okBtn').click(function(event) {
                $("#bodyDiv").empty();
                $('#confirmModal').dialog("close");
            });
        
          $('#cancelBtn').click(function(event) {
             $("#bodyDiv").empty();
             $('#confirmModal').dialog("close");
          });
           $('#closeSpan').click(function(event) {
             $("#bodyDiv").empty();
             $('#confirmModal').dialog("close");
          });
          
          $('#lblHeader').text(projectName);
          $("#MainContent").css("width", "1300px");
          //$("#MainContent").css("height", "400px");
          
         // loadContent(null, projectId);
          setIframe(document.getElementById('bodyDiv'),'projects/id/'+ projectId);
        }
        
        function setIframe(element,location){
            var theIframe = document.createElement("iframe");
            theIframe.src = location;
            theIframe.setAttribute("weight", "500");
            theIframe.setAttribute("width", "1280");
            theIframe.setAttribute("height", "860");
            theIframe.setAttribute("scrolling", "yes");
            element.appendChild(theIframe);
   }
        
        function loadContent(e,projectId){
            (e || window.event).preventDefault();
            var con = document.getElementById('bodyDiv'),xhr = new XMLHttpRequest();

           xhr.onreadystatechange = function (e) { 
           if (xhr.readyState == 4 && xhr.status == 200) {
           con.innerHTML = xhr.responseText;
           }
         }

        xhr.open("GET", "projects/id/"+ projectId , true);
        xhr.setRequestHeader('Content-type', 'text/html');
        xhr.send();
        }