//function loadResources(projectId){
//          $.ajax({               
//              headers: { 
//                  'Accept': 'application/json',
//                   'Content-Type': 'application/json' 
//                 },
//               Accept : "application/json",
//               contentType: "application/json",
//                method: "GET",
//                url:"../../projects/resources/"+ projectId ,
//                dataType:'json',
//                 success: function(data) {
//                    sessionStorage.setItem('projectresources',JSON.stringify(data));
//                   buildProjectResources();
//                  },
//                  error: function(xhr,err,thrownError){
//                       alert("Error: "+err +
//                               "\nResponse Text: "+xhr.responseText +
//                               "\nMessage: "+thrownError +
//                                "\nready State: "+xhr.readyState +
//                               "\nStatus: "+xhr.status);
//                   $.loader.close(true);
//                  }
//            });       
//     }
function onChangeRemoveResource(projectId, username) {
    $.ajax({
        url: '../../projects/remove/resource/' + projectId + '/' + username,
        type: 'POST',
        success: function (returndata) {
            //alert("user added")
            location.reload();
        },
        error: function (data) {
            alert("An error occured to remove a resource: \n" + JSON.parse(data));
            $.loader.close(true);
        }
    });
}




