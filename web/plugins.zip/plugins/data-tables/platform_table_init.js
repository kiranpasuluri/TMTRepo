$(document).ready(function() {
        $('#printPlatformTable').dataTable();  
        $('#onlinePlatformTable').dataTable();  
});
