function fnFormatDetails ( oTableQuery, nTrQuery, dataResultsQuery )
{
    alert("test1: "+dataResultsQuery.length);
    var aDataQuery = oTableQuery.fnGetData( nTrQuery );
    var rowIndexQuery =  parseInt(aDataQuery[1])-1;//get the index of the clicked row from index-column text value - which is 1 based
    //var eishReason = jsSubQueries[rowIndexQuery].eishReasonId;
    var sOutQuery = '';
    
    sOutQuery = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;" width="80%">';
    sOutQuery += '<thead><tr><th width="60%">Task</th><th width="20%">Start Date</th><th width="20%">Status</th></tr></thead>';
    for(i=0;i<dataResultsQuery.length;i++){
        var statusFlag = '<span class="label label-success">Completed</span>';
        if(dataResultsQuery[i].status===1)         
            statusFlag = '<span class="label label-info">In Progress</span>';
        else if(dataResultsQuery[i].status===0)
            statusFlag = '<span class="label label-warning">Not Started</span>';
        else if(dataResultsQuery[i].status===-3)
            statusFlag = '<span class="label label-danger">Rejected</span>';
        var taskOwner = dataResultsQuery[i].updatedBy;
        if(taskOwner===null)
            taskOwner = '<span style="color:red">Unassigned</span>';
        sOutQuery += '<tr><td><a href="http://trudonchweb1:8080/ContentApplicationPlatform/client/index.html?taskid='+dataResultsQuery[i].taskId+'" target="_blank">'+dataResultsQuery[i].eishDescription+'</a></td><td>'+dataResultsQuery[i].updateDate+'</td><td>'+statusFlag+'</td></tr>';
    }
    sOutQuery += '</table>';
    alert("sOutQuery: "+sOutQuery);
    return sOutQuery;

    /*"createdBy",
    "createdDate",
    "eishDescription",
    "status",
    "updateDate",
    "updatedBy"*/
    
    /*var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
    
    for(i=0;i<jsSub.printProgrammes[rowIndex].entries.length;i++){
        entry = jsSub.printProgrammes[rowIndex].entries[i];
        sOut += '<tr><td>'+entry.bookShortName+'/'+entry.bookEdition+'-'+entry.sectionName+' '+entry.itemCode+' - R '+entry.enteredPrice+'</td><td><a href="#">View Advert</a></td></tr>';
    }
    sOut += '</table>';

    return sOut;
    */
   
}

$(document).ready(function() {

    /*
     * Insert a 'details' column to the table
     */
    var nCloneThQuery = document.createElement( 'th' );
    var nCloneTdQuery = document.createElement( 'td' );
    nCloneTdQuery.innerHTML = '<img src="../plugins/advanced-datatable/images/details_open.png">';
    nCloneTdQuery.className = "center";

    $('#queriesTable thead tr').each( function () {
        this.insertBefore( nCloneThQuery, this.childNodes[0] );
    } );

    $('#queriesTable tbody tr').each( function () {
        this.insertBefore(  nCloneTdQuery.cloneNode( true ), this.childNodes[0] );
    } );

    /*
     * Initialse DataTables, with no sorting on the 'details' column
     */
    var oTableQuery = $('#queriesTable').dataTable( {
        "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 0 ] },
            { "width": "2%", "targets": 0 }
        ],
        "aaSorting": [[1, 'asc']],
        "paging":   false,
        "ordering": false,
        "info":     false,
        "searching": false
    });

    /* Add event listener for opening and closing details
     * Note that the indicator for showing which row is open is not controlled by DataTables,
     * rather it is done here
     */
    $('#queriesTable').on("click", ".center",function () {
        var nTrQuery = $(this).parents('tr')[0];
        if ( oTableQuery.fnIsOpen(nTrQuery) )
        {
            /* This row is already open - close it */
            this.children[0].src = "../plugins/advanced-datatable/images/details_open.png";
            oTableQuery.fnClose( nTrQuery );
        }
        else
        {
            /* Open this row */
            this.children[0].src = "../plugins/advanced-datatable/images/details_close.png";
            var aDataQuery = oTableQuery.fnGetData( nTrQuery );
            var rowIndexQuery =  parseInt(aDataQuery[1])-1;//get the index of the clicked row from index-column text value - which is 1 based
            var eishReason = 1;
            var dynClass = 'odd';
            oTableQuery.fnOpen( nTrQuery, fnFormatDetails(oTableQuery, nTrQuery,[{"createdBy":"SS","createdDate":"2014-02-07 00:00:00.0","eishDescription":"Basic data changed","status":2,"taskId":536221,"updateDate":"2014-02-24 09:10:31.0","updatedBy":"RAMEKOSIT"},{"createdBy":"ramekosit","createdDate":"2013-03-15 11:18:00.0","eishDescription":"Basic data changed","status":2,"taskId":51300,"updateDate":"2013-03-15 14:06:37.0","updatedBy":"BOSCHR"},{"createdBy":"ramekosit","createdDate":"2013-04-04 10:41:14.0","eishDescription":"Basic data changed","status":2,"taskId":55254,"updateDate":"2013-04-04 11:08:17.0","updatedBy":"BOSCHR"},{"createdBy":"ramekosit","createdDate":"2013-01-15 10:17:27.0","eishDescription":"Basic data changed","status":2,"taskId":30679,"updateDate":"2013-01-25 09:26:53.0","updatedBy":"RAMEKOSIT"}]), dynClass );
        }
    } );
} );