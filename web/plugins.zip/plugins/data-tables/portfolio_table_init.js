$(document).ready(function() {
        $('#portfoliosTable').dataTable();  
        
        $('#portfolioSubsTable').dataTable();  
});
