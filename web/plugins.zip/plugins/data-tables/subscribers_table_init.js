$(document).ready(function() {

    $('#subscribersTable').dataTable( {
        "aaSorting": [[ 1, "desc" ]]
    } );

} );