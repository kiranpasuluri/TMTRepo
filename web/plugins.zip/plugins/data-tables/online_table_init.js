function fnFormatDetailsOnline ( oTableOnline, nTrOnline )
{
    var aDataOnline = oTableOnline.fnGetData( nTrOnline );
    var rowIndexOnline =  parseInt(aDataOnline[1])-1;//get the index of the clicked row from index-column text value - which is 1 based
    var sOutOnline = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;" width="100%">';
    for(i=0;i<jsSub.onlineProgrammes[rowIndexOnline].entries.length;i++){
        entryOnline = jsSub.onlineProgrammes[rowIndexOnline].entries[i];
        sOutOnline += '<tr><td>'+entryOnline.bookShortName+'/'+entryOnline.bookEdition+'-'+entryOnline.sectionName+' '+entryOnline.itemCode+' - R '+entryOnline.enteredPrice+'</td>'
                     +'<td><a href="#">View Advert</a></td></tr>';
        /*
        sOutOnline += '<tr><td>'+entryOnline.bookShortName+'/'+entryOnline.bookEdition+'-'+entryOnline.sectionName+' '+entryOnline.itemCode+' - R '+entryOnline.enteredPrice+'</td>'
                     +'<td><a href="#">View Advert</a></td><td><button class="btn btn-primary timeline-button" type="button" data-bookCode="'+entryOnline.bookCode.toString().trim()+'" data-desc="'+entryOnline.bookShortName+'-'+entryOnline.sectionName+' '+entryOnline.itemCode+'"><i class="fa fa-sort-alpha-asc"></i> View Timeline</button></td></tr>';
        */
    }
    sOutOnline += '</table>';
    
    

    return sOutOnline;
}

$(document).ready(function() {

    /*
     * Insert a 'details' column to the table
     */
    var nCloneThOnline = document.createElement( 'th' );
    var nCloneTdOnline = document.createElement( 'td' );
    nCloneTdOnline.innerHTML = '<img src="../../plugins/advanced-datatable/images/details_open.png">';
    nCloneTdOnline.className = "center";
    nCloneTdOnline.id = "onlineDetailsCol";

    $('#onlineProductsTable thead tr').each( function () {
        this.insertBefore( nCloneThOnline, this.childNodes[0] );
    } );

    $('#onlineProductsTable tbody tr').each( function () {
        this.insertBefore(  nCloneTdOnline.cloneNode( true ), this.childNodes[0] );
        $('#onlineDetailsCol').css("width", "2%"); 
    } );

    /*
     * Initialse DataTables, with no sorting on the 'details' column
     */
    var oTableOnline = $('#onlineProductsTable').dataTable( {
        "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 0 ] },
            { "width": "2%", "targets": 0 }
        ],
        "aaSorting": [[1, 'asc']]
    });

    /* Add event listener for opening and closing details
     * Note that the indicator for showing which row is open is not controlled by DataTables,
     * rather it is done here
     */
    $('#onlineProductsTable tbody td img').click(function () {
        var nTrOnline = $(this).parents('tr')[0];
        if ( oTableOnline.fnIsOpen(nTrOnline) )
        {
            /* This row is already open - close it */
            this.src = "../../plugins/advanced-datatable/images/details_open.png";
            oTableOnline.fnClose( nTrOnline );
        }
        else
        {
            /* Open this row */
            this.src = "../../plugins/advanced-datatable/images/details_close.png";
            oTableOnline.fnOpen( nTrOnline, fnFormatDetailsOnline(oTableOnline, nTrOnline), 'details' );
            
            $('.timeline-button').click(function(event) {
                    window.location.href = +jsSub.subscrId+'/timeline/online/'+$(this).attr("data-bookCode")+"?desc="+$(this).attr("data-desc");
            });
            
        }
    } );
} );