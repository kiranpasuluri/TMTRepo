function fnFormatDetailsPrint ( oTablePrint, nTrPrint )
{
    var aDataPrint = oTablePrint.fnGetData( nTrPrint );
    var rowIndexPrint =  parseInt(aDataPrint[1])-1;//get the index of the clicked row from index-column text value - which is 1 based
    var sOutPrint = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
    for(i=0;i<jsSub.printProgrammes[rowIndexPrint].entries.length;i++){
        entryPrint = jsSub.printProgrammes[rowIndexPrint].entries[i];
        sOutPrint += '<tr><td>'+entryPrint.bookShortName+'/'+entryPrint.bookEdition+'-'+entryPrint.sectionName+' '+entryPrint.itemCode+' - R '+entryPrint.enteredPrice+'</td>'
        +'<td><a href="#">View Advert</a></td></tr>';
    }
    sOutPrint += '</table>';

    return sOutPrint;
}

$(document).ready(function() {

    $('#dynamic-table').dataTable( {
        "aaSorting": [[ 4, "desc" ]]
    } );

    /*
     * Insert a 'details' column to the table
     */
    var nCloneThPrint = document.createElement( 'th' );
    var nCloneTdPrint = document.createElement( 'td' );
    nCloneTdPrint.innerHTML = '<img src="../../plugins/advanced-datatable/images/details_open.png">';
    nCloneTdPrint.className = "center detailWidthCol";

    $('#hidden-table-info thead tr').each( function () {
        this.insertBefore( nCloneThPrint, this.childNodes[0] );
    } );

    $('#hidden-table-info tbody tr').each( function () {
        this.insertBefore(  nCloneTdPrint.cloneNode( true ), this.childNodes[0] );
    } );

    /*
     * Initialse DataTables, with no sorting on the 'details' column
     */
    var oTablePrint = $('#hidden-table-info').dataTable( {
        "aoColumnDefs": [
            { "bSortable": false, "aTargets": [ 0 ] },
            { "width": "2%", "targets": 0 }
        ],
        "aaSorting": [[1, 'asc']]
    });

    /* Add event listener for opening and closing details
     * Note that the indicator for showing which row is open is not controlled by DataTables,
     * rather it is done here
     */
    $('#hidden-table-info tbody td img').click(function () {
        var nTrPrint = $(this).parents('tr')[0];
        if ( oTablePrint.fnIsOpen(nTrPrint) )
        {
            /* This row is already open - close it */
            this.src = "../../plugins/advanced-datatable/images/details_open.png";
            oTablePrint.fnClose( nTrPrint );
        }
        else
        {
            /* Open this row */
            this.src = "../../plugins/advanced-datatable/images/details_close.png";
            oTablePrint.fnOpen( nTrPrint, fnFormatDetailsPrint(oTablePrint, nTrPrint), 'details' );
        }
    } );
} );