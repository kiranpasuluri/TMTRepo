$(document).ready(function() {
    var tableDocuments = $('#documentsTable').dataTable( {
        "processing": false,
        "serverSide": false,
        "ajax": {
            "url": jsSub.subscrId+"/docushare/documents",
            "dataSrc": function(json) {
                //Make your callback here.
                //alert("Done!");
                buildEmailTable(json.email);
                return json.documents;
            }       ,
            "type": "GET"
        },
        "columns": [
            { "data": "title" },
            { "data": "type"},
            { "data": "url" }
        ],
        "columnDefs": [
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    return '<a href=\''+row.url+'\'>'+data+'</a>';
                },
                "targets": 0
                
            },
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    if(row.url.indexOf('.pdf')>-1)
                        return '<img src=\'../../images/icons/pdf.png\' alt=\'PDF\' height=\'16\' width=\'16\' title=\'PDF File\'>';
                    else if(row.url.indexOf('.doc')>-1)
                        return '<img src=\'../../images/icons/pdf.png\' alt=\'DOC\' height=\'16\' width=\'16\' title=\'MS Word File\'>';
                    else
                        return '<img src=\'../../images/icons/file.png\' alt=\'UNKWN\' height=\'16\' width=\'16\' title=\'Unknown File Type\'>';
                },
                "targets": 1
                
            },
            { "visible": false,  "targets": [ 2 ] }
        ],
        "drawCallback": function(settings){
            //alert( 'DataTables has redrawn the table' );
        }
        
        
    } );
    
    var paySourceLists = $('#paySourceTable').dataTable( {
        "processing": false,
        "serverSide": false,
        "ajax": {
            "url": jsSub.subscrId+"/paysource",
            "dataSrc": "",
            "type": "GET"
        },
        "columns": [
            { "data": "book" },
            { "data": "bookEdition"},
            { "data": "paySourceName" }
        ],
        "drawCallback": function(settings){
            //alert( 'DataTables has redrawn the table' );
        }
    } );
    
    var crmItemsLists = $('#crmItemsTable').dataTable( {
        "processing": false,
        "serverSide": false,
        "ajax": {
            "url": jsSub.subscrId+"/selligentQueries",
            "dataSrc": "",
            "type": "GET"
        },
        "columns": [
            { "data": "ref" },
            { "data": "createDate" },
            { "data": "creator" },
            { "data": "customerName"},
            { "data": "status" },
            { "data": "type" }
        ],
        "drawCallback": function(settings){
            //alert( 'DataTables has redrawn the table' );
        }
    } );
    

    
    
    var tableRecordings = $('#recordingsTable').dataTable( {
        "processing": false,
        "serverSide": false,
        "ajax": {
            "url": jsSub.subscrId+"/docushare/recordings",
            "dataSrc": "",
            "type": "GET"
        },
        "columns": [
            { "data": "title" },
            { "data": "type"},
            { "data": "url" }
        ],
        "columnDefs": [
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    return '<a href=\''+row.url+'\'>'+data+'</a>';
                },
                "targets": 0
                
            },
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    if(row.url.indexOf('.vox')>-1)
                        return '<img src=\'../../images/icons/sound.png\' alt=\'VOX\' height=\'16\' width=\'16\' title=\'VOX File\'>';
                    else
                        return '<img src=\'../../images/icons/file.png\' alt=\'UNKWN\' height=\'16\' width=\'16\' title=\'Unknown File Type\'>';
                },
                "targets": 1
                
            },
            { "visible": false,  "targets": [ 2 ] }
        ],
        "drawCallback": function(settings){
            //alert( 'DataTables has redrawn the table' );
        }
        
        
    } );
    
    
    var tableLmProducts = $('#lmProductsTable').dataTable( {
        "processing": false,
        "serverSide": false,
        "ajax": {
            "url": "../magnetic/projects/"+jsSub.subscrId,
            "dataSrc": "",
            "type": "GET"
        },
        "columns": [
            { "data": "name" },
            { "data": "amount"},
            { "data": "id"}
        ],
        "columnDefs": [
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    for(var fieldsIndex=0;fieldsIndex<row.customFields.length;fieldsIndex++){
                        if(row.customFields[fieldsIndex].customFieldDefinition.fieldLabel==='UDACS'){
                            return '<span>'+row.customFields[fieldsIndex].value+'</span>';
                        }
                    }
                    return '<span>Unspecified</span>';
                },
                "targets": 0
                
            },
            {
                // The `data` parameter refers to the data for the cell (defined by the
                // `data` option, which defaults to the column being worked with, in
                // this case `data: 0`.
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    return '<span>'+row.amount+'</span>';
                },
                "targets": 1
                
            },
            {
                "render": function ( data, type, row ) {
                    //return data +' ('+ row[3]+')';
                    return '<button class="btn btn-primary" type="button" onclick="goToTimeline('+row.id+')" dataGroupId="'+row.id+'"><i class="fa fa-sort-alpha-asc"></i>Timeline</button>';
                },
                "targets": 2
                
            }
        ],
        "drawCallback": function(settings){
            //alert( 'DataTables has redrawn the table' );
        }
        
        
    } );
    
} );

function goToTimeline(currGroupId){
    window.location.href = jsSub.subscrId+'/timeline/3rdparty/'+currGroupId;
}

function buildEmailTable(emailList){
    var emailTblRow = "";      
    for (var m=0;m<emailList.length;m++){
        //out.print("<div>index before "+m+"</div>");
        var dateTitle = "";
        var alteredTitle = "";
        var emailLink = "";
        var emailSummary = "";
        if(emailList[m].type.toLowerCase()==="cust_emails"){
            try{
                dateTitle = emailList[m].summary.substring(emailList[m].summary.indexOf("on ")+3, emailList[m].summary.length);
                alteredTitle = emailList[m].title.replace("Email: ", "");
                emailLink = emailList[m].url;
                emailSummary = emailList[m].summary;

            }catch(error){
                dateTitle = "";
                alteredTitle = emailList[m].title;
                emailLink = "#";
                emailSummary = emailList[m].summary;
            }
            emailTblRow = emailTblRow + "<div class=\"alert alert-info clearfix\"> <span class=\"alert-icon\"><i class=\"fa fa-envelope-o\"></i></span>"
                        +"<div class=\"notification-info\">"
                        +"<ul class=\"clearfix notification-meta\">"
                        +"<li class=\"pull-left notification-sender\"><span><a href=\""+emailLink+"\" target=\"_blank\">"+alteredTitle+"</a></span></li>"
                        +"<li class=\"pull-right notification-time\">"+dateTitle+"</li>"
                        +"</ul>"
                        +"<p>"+emailSummary+"</p></div></div>";

        }
    }
    if(emailTblRow===""){
        emailTblRow = "<h5>No emails found</h5>";
    } 
    $('#emailContainer').html(emailTblRow);
}
